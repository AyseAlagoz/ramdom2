const { defineConfig } = require('@vue/cli-service');
const Components = require('unplugin-vue-components/webpack').default;
const { BootstrapVueNextResolver } = require('unplugin-vue-components/resolvers');

module.exports = defineConfig({
  transpileDependencies: true,
  devServer: {
    proxy: {
      '/api': {
        target: 'http://roroapi.tr20.yph.inc',
        changeOrigin: true,
        pathRewrite: { '^/api': '' },
        secure: false,
      },
    },
  },
  configureWebpack: {
    plugins: [
      Components({
        dirs: ['src/components'], // Automatically register components from this folder
        extensions: ['vue'],
        resolvers: [BootstrapVueNextResolver()], // Auto-register BootstrapVueNext components
      }),
    ],
  },

  productionSourceMap: false,

  pluginOptions: {
    vuetify: {},
  },

  pwa: {
    name: 'Portera',
    short_name: 'Portera',
    themeColor: '#2196F3',
    workboxPluginMode: 'GenerateSW',
    workboxOptions: {
      exclude: ["web.config"],
      clientsClaim: true,
      skipWaiting: true,
      navigateFallback: '/index.html',
      cleanupOutdatedCaches: true,
      runtimeCaching: [
        {
          // Örneğin; tüm HTTPS isteklerine network-first yaklaşımı
          urlPattern: new RegExp('^https://'),
          handler: 'NetworkFirst',
          options: {
            // Ağın belirli bir süre yanıt vermemesi durumunda cache’e geçiş
            networkTimeoutSeconds: 3,
            cacheName: 'runtime-cache',
            expiration: {
              maxEntries: 50,
              maxAgeSeconds: 60 * 60 * 24 // 1 gün
            },
            cacheableResponse: {
              statuses: [0, 200]
            }
          }
        }
      ],
    },
    backgroundColor: '#ffffff',
    start_url: '/',
    display: 'standalone',
    icons: [
      {
        src: 'img/icons/favicon-16x16.png',
        sizes: '16x16',
        type: 'image/png',
      },
      {
        src: 'img/icons/favicon-32x32.png',
        sizes: '32x32',
        type: 'image/png',
      },
    ],

  },
});
