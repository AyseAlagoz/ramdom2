<template>
  <v-img rounded max-height="110" class="shrink" :src="imageSrc"></v-img>
  <v-form>
    <div class="mt-2">
      <label for="email" class="left-aligned"><b>KULLANICI ADI</b></label>
      <v-text-field v-model="user.username" variant="solo"></v-text-field>
    </div>
    <div class="mt-2">
      <label for="password" class="left-aligned"><b>PAROLA</b></label>
      <v-text-field v-model="user.password" :append-inner-icon="showPassword ? 'mdi-eye-off' : 'mdi-eye'"
        :type="showPassword ? 'text' : 'password'" prepend-inner-icon="mdi-lock-outline" variant="solo"
        @click:append-inner="showPassword = !showPassword" @keydown.enter="logIn"></v-text-field>
    </div>
    <v-card elevation="0" height="2rem"></v-card>

    <v-btn color="white" @click="logIn" rounded block class="custom-height"><span class="textFont">GİRİŞ
        YAP</span></v-btn>
  </v-form>
</template>

<script>
import MessageContent from "@/components/Base/MessageContent.vue";
import { AUTH_URL } from "@/constants/apis/index.js";
import { logIn } from "@/utils/httpServices";
import Operation from "@/utils/Operations.js";

export default {
  name: "MainMenu",
  inject: ["toggleLoadingOverlay", "openDialog"],
  components: {
    MessageContent,
  },
  data() {
    return {
      showPassword: false,
      user: {
        username: "",
        password: "",
      },
      imageSrc: process.env.BASE_URL + "img/gemport.jpg",
      page: null,
    };
  },
  methods: {
    async logIn() {
      if (
        this.user.username.trim() === "" ||
        this.user.password.trim() === ""
      ) {
        this.openDialog(MessageContent, "Kullanıcı adı veya parola boş olamaz");
        return;
      }

      try {
        this.toggleLoadingOverlay();
        const res = await logIn(`${AUTH_URL}SetLogIn`, {
          UserName: this.user.username,
          Password: this.user.password,
        });

        if (res.ResponseCode == "Success") {
          localStorage.setItem("isAuthenticated", true);
          Operation.logIn(res.Data);
          this.toggleLoadingOverlay();
          this.$router.push("/");
          return;
        } else {
          this.toggleLoadingOverlay();
          this.openDialog(MessageContent, res.Message || "Kullanıcı adı veya parola hatalı");
        }
      } catch (e) {
        this.openDialog(
          MessageContent,
          "Beklenmeyen bir hata oluştu. Lütfen tekrar deneyin."
        );
        this.toggleLoadingOverlay();
        return;
      }
    },
  },
  mounted() {
    console.log("..");
  },
};
</script>

<style scoped>
.left-aligned {
  text-align: left;
  display: block;
  font-size: clamp(0.2rem, 1.2vw + 1.6rem, 2.6rem);
  font-weight: bold;
  margin-bottom: 4px;
  /* Etiket ile input arasına biraz boşluk ekler */
}

/* Butonları hizalamak ve alt kısma yerleştirmek için */
/*.button-container {
  display: flex;
  flex-direction: column;
  gap: 10px;  Butonlar arasında boşluk 
  margin-top: 200px;
}*/
.textFont {
  font-size: clamp(1.4rem, 1.2vw + 1.6rem, 2.6rem);
  font-weight: bold;
}

.custom-height {
  height: calc(60vh / 4.5);
}
</style>
