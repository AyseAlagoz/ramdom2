<template>
    <v-img rounded max-height="100" :src="imageSrc" class="shrink"></v-img>
  
    <v-row dense class="mt-2">
      <v-col
        :cols="buttonMode == 1 ? 12 : 6"
        v-for="(btn, index) in buttons"
        :key="index"
      >
        <v-btn
          v-if="btn.permission.some((app) => userApps.includes(app))"
          @click="btn.click()"
          rounded
          border
          block
          :class="buttonMode == 1 ? 'custom-height' : 'custom-height2'"
        >
          <span class="menuText">{{ btn.text }}</span>
        </v-btn>
      </v-col>
      <v-col cols="12">
        <v-btn
          @click="logOutConfirmOpener"
          block
          border
          rounded
          :class="buttonMode == 1 ? 'custom-height' : 'custom-height2'"
        >
          <span class="menuText fontRed">Oturumu Kapat</span>
        </v-btn>
      </v-col>
    </v-row>
  </template>
  
  <script>
  import { useButtonModeStore } from "@/store/buttonMode";
  import { useIndexedDBStore } from "@/CommonVueCore/src/store/stores/indexDBStores";
  import ConfirmContent from "@/components/Base/ConfirmContent.vue";
  import MessageContent from "@/components/Base/MessageContent.vue";
  import Operation from "@/utils/Operations.js";
  export default {
    name: "MainMenu",
    inject:["openDialog","closeDialog"],
    data() {
      return {
        imageSrc: process.env.BASE_URL + "img/gemport.jpg",
        buttons: [
        { text: "RORO" , click:()=>{this.goTo("/roro")} , permission: ["Roro", "All"]},
          { text: "CFS - Dolum", click:()=>{this.goTo("/cfs",true) } , permission: ["Cfs", "All"]},
          // { text: "DAMAGE - HASAR", click:()=>{this.goTo("/damage" ,true) }},
          // { text: "STUFF", click:()=>{this.alertNonexistPages()} },
          // { text: "ADMİN PAGE" , click:()=>{this.alertNonexistPages()}},
        ],
        userApps : Operation.getUser().Apps || [],
      };
    },
    computed: {
      buttonMode() {
        return useButtonModeStore().mode;
      },
    },
    methods: {
      goTo(page, isConnectionRequired = false) {
        if(isConnectionRequired && !navigator.onLine){
          this.openDialog(MessageContent, "Bu sayfalar için internet bağlantısı gerekmektedir..");
          return;
        }
        this.$router.push(page);
      },
      alertNonexistPages(){
        alert("Bu sayfa üstünde çalışılmaktadır.")
      },
      async logOut() {
        try {
          const x = await useIndexedDBStore().deleteSelectedDb("Roro");
        } catch (error) {
          console.log(error);
        }
        finally{
          localStorage.clear();
          this.closeDialog();
          this.$router.push("/login");
        }
      },
      logOutConfirmOpener(){
        this.openDialog(
          ConfirmContent,
          "Çıkış yapmak istediğinize emin misiniz? \n Çevrimdışı veriler silinecektir.",
          async () => {
            this.logOut();
          }
        );
      }
    },
  };
  </script>
  
  <style scoped>
  .menuText {
    font-size: clamp(0.2rem, 1.2vw + 1.2rem, 2.5rem);
    line-height: 1.2;
    padding: 0 4px;
    white-space: wrap;
  }
  
  .custom-height {
    height: calc(60vh / 5);
  }
  
  @media (max-height: 640px) {
    .custom-height {
      height: calc(60vh / 6);
    }
  }
  
  .custom-height2 {
    height: calc(60vh / 3);
  }
  
  @media (max-height: 600px) {
    .custom-height2 {
      height: calc(60vh / 3.5);
    }
  }
  </style>
  