<template>
    <h1>Damage Main Page</h1>
</template>

<script>
</script>