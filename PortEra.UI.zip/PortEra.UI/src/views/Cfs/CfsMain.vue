<template>
    <h1>CFS İşlemleri</h1>
    <v-row justify="center" class="mt-4" gap="4">
        <v-col cols="12" md="12">
            <v-sheet class="d-flex align-center" elevation="0">
                <v-text-field v-model="unitId" label="Unit Id" :rules="[rules.required]" density="compact"
                    variant="solo" @keyup.enter="searchUnitId" @blur="searchUnitId" hide-details="auto"
                    style="flex: 1; margin-right: 8px" />
                <v-btn border rounded @click="searchUnitId" class="search-btn">
                    Search
                </v-btn>
            </v-sheet>
        </v-col>
        <v-col cols="12" md="12" v-if="additionalServiceVisible">
            <v-sheet class="d-flex align-center" elevation="0">
                <v-select v-model="selectedAdditionalService" :items="additionalServices"
                    label="Select Additional Service" :rules="[rules.required]" density="compact" variant="solo"
                    class="select-css" item-title="title" item-value="id" hide-details="auto"></v-select>
                <!-- <v-spacer style="max-width: 100px; margin-right: 8px"></v-spacer> -->
            </v-sheet>
        </v-col>
        <v-col cols="12" md="12" v-if="additionalServiceVisible">
            <v-sheet class="d-flex align-center" elevation="0">
                <v-text-field v-model="sealNumber" label="Seal Number" :rules="[rules.required]" density="compact"
                    variant="solo" @keyup.enter="searchSealNumber" @blur="searchSealNumber" hide-details="auto"
                    style="flex: 1; margin-right: 8px"></v-text-field>
                <v-btn border rounded @click="searchSealNumber" class="search-btn">
                    Search
                </v-btn>
            </v-sheet>
        </v-col>
        <v-col cols="12" md="12" v-if="weightVisible">
            <v-sheet class="d-flex align-center" elevation="0">
                <v-text-field v-model="tareWeight" label="Tare Weight" :rules="[rules.required]" density="compact"
                    variant="solo" hide-details="auto"></v-text-field>
                <!-- <v-spacer style="max-width: 100px; margin-right: 8px"></v-spacer> -->
            </v-sheet>
        </v-col>
        <v-col cols="12" md="12" v-if="weightVisible">
            <v-sheet class="d-flex align-center" elevation="0">
                <v-text-field v-model="payloadWeight" label="Payload Weight" :rules="[rules.required]" density="compact"
                    variant="solo" hide-details="auto"></v-text-field>
                <!-- <v-spacer style="max-width: 100px; margin-right: 8px"></v-spacer> -->
            </v-sheet>
        </v-col>
        <v-col v-if="weightVisible">
            <v-sheet class="d-flex align-center" elevation="0">
                <v-btn block border rounded class="save-btn" @click="saveData">SAVE</v-btn>
            </v-sheet>
        </v-col>
    </v-row>
</template>

<script>
import ErrorMessageContent from '@/components/Base/ErrorMessageContent.vue'
import MessageContent from '@/components/Base/MessageContent.vue'
import { postData } from '@/utils/httpServices.js'
import { CFS_URL } from '@/constants/apis/index.js'
export default {
    inject: ["openDialog", "toggleLoadingOverlay"],
    data() {
        return {
            unitId: null,
            previousUnitId: null,
            additionalServices: [],
            additionalServiceVisible: false,
            sealNumber: '',
            transitState: '',
            lineId: '',
            previousSealNumber: null,
            tareWeight: 0,
            payloadWeight: 0,
            weightVisible: false,
            selectedAdditionalService: null,
            rules: {
                required: value => !!value || 'This field is required.',
            }
        }
    },
    methods: {
        /**
        * @summary Posting for checking additioanal service for unit
        */
        async searchUnitId() {
            if (!this.unitId) return
            if (this.unitId === this.previousUnitId) return
            this.toggleLoadingOverlay();

            try {
                const response = await postData(`${CFS_URL}GetCfsUnitDetail`, { UnitId: this.unitId })

                if (response.ResponseCode === 'Success') {
                    // this.additionalServices = response.Data.AdditionalServiceName
                    this.additionalServices = response.Data.map(item => ({
                        title: item.AdditionalServiceName,
                        id: item.PKey,
                    }))
                    this.transitState = response.Data[0].TransitState
                    this.lineId = response.Data[0].LineId
                    this.additionalServiceVisible = true
                    this.toggleLoadingOverlay();
                } else {
                    this.additionalServiceVisible = false
                    this.toggleLoadingOverlay();
                    this.openDialog(ErrorMessageContent, "Unit için tanımlı ek servis bulunamadı.");
                }
                this.previousUnitId = this.unitId
            } catch (error) {
                this.toggleLoadingOverlay();
                console.error('Error fetching unit details:', error)
                this.additionalServiceVisible = false
                this.openDialog(ErrorMessageContent, "Bir hata oluştu.");
            }




        },
        /**
        * @summary Posting for checking seal number for unit
        */
        async searchSealNumber() {
            if (!this.sealNumber) return
            if (this.sealNumber === this.previousSealNumber) return
            this.toggleLoadingOverlay();

            try {
                const response = await postData(`${CFS_URL}GetCheckSealNumber`, { SealNumber: this.sealNumber })

                if (response.ResponseCode === 'Success') {
                    this.weightVisible = true
                    this.toggleLoadingOverlay();
                } else {
                    this.weightVisible = false
                    this.toggleLoadingOverlay();
                    this.openDialog(ErrorMessageContent, "Giriş yapmaya çalıştığınız seal numarası kullanılmaktadır.");
                }
                this.previousSealNumber = this.sealNumber
            } catch (error) {
                this.toggleLoadingOverlay();
                console.error('Error fetching unit details:', error)
                this.weightVisible = false
                this.openDialog(ErrorMessageContent, "Bir hata oluştu.");
            }




        },
        /**
        * @summary Posting for saving new seal number, tare weight and payload weight for unit
        */
        async saveData() {
            this.toggleLoadingOverlay();
            if (this.sealNumber == null || this.tareWeight == 0 || this.payloadWeight == 0) {
                this.toggleLoadingOverlay();
                this.openDialog(ErrorMessageContent, "Lütfen tüm alanları doldurunuz.");
                return
            }

            try {
                const response = await postData(`${CFS_URL}SetNavisUnitData`, {
                    UnitId: this.unitId,
                    SealNumber: this.sealNumber,
                    TareWeight: this.tareWeight,
                    PayloadWeight: this.payloadWeight,
                    AdditionalService: this.selectedAdditionalService,
                    TransitState: this.transitState,
                    LineId: this.lineId
                })

                if (response.ResponseCode === 'Success') {
                    this.toggleLoadingOverlay();
                    this.openDialog(
                        MessageContent,
                        "İşlem başarıyla tamamlandı.",
                        () => {
                            location.reload();
                        }
                    );
                } else {
                    this.toggleLoadingOverlay();
                    this.openDialog(ErrorMessageContent, "Kayıt işlemi başarısız.");
                }
            }
            catch (error) {
                this.toggleLoadingOverlay();
                console.error('Error saving data:', error)
                this.openDialog(ErrorMessageContent, "Kayıt işlemi sırasında bir hata oluştu.");
            }
        }
    },
    watch: {
        unitId(newVal, oldVal) {
            if (newVal !== oldVal) {
                this.additionalService = ''
                this.additionalServiceVisible = false
            }
        },
        sealNumber(newVal, oldVal) {
            if (newVal !== oldVal) {
                // this.sealNumber = ''
                this.weightVisible = false
            }
        }
    }
}
</script>

<style>
/* .custom-height {
    height: calc(30vh / 5);
    color: green;
} */
.search-btn {
    border-color: cadetblue;
}

.v-messages__message {
    text-align: left !important;
    justify-content: flex-start !important;
    padding-left: 4px !important;
}

.save-btn {
    font-weight: bold;
    font-size: large;
    border-color: cadetblue;
}

.select-css {
    flex: 1;
}

@media (max-width: 600px) {
    .save-btn {
        height: 40px !important;
    }

    .select-css {
        height: auto !important;
    }

    .search-btn {
        height: 35px !important;
    }
}


/* Orta ekranlar: md aralığı (601px – 960px) */
@media (min-width: 601px) and (max-width: 960px) {
    .save-btn {
        height: 50px !important;
    }

    .select-css {
        height: auto !important;
    }

    .search-btn {
        height: 45px !important;
    }
}

/* Büyük ekranlar: lg ve üzeri (≥961px) */
@media (min-width: 961px) {
    .save-btn {
        height: 60px !important;
    }

    .select-css {
        height: auto !important;
    }

    .search-btn {
        height: 50px !important;
    }
}
</style>