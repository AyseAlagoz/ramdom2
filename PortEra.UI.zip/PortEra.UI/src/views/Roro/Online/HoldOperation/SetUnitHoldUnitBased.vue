<template>
  <label for="VINLabel" class="left-aligned"><b>VIN</b></label>
  <v-text-field
    label=""
    variant="solo"
    v-model="vin"
    ref="vinTextRef"
    @keydown.enter="liftHold"
  ></v-text-field>

  <div class="responsive-spacer">
    <v-container class="left-aligned" v-show="response.state != ''">
      <span :class="response.state == 'success' ? 'fontGreen' : 'fontRed'">{{
        response.message
      }}</span>
    </v-container>
  </div>

  <v-btn
    block
    border
   
    rounded
    class="mt-3 custom-height"
    @click="liftHold"
    ><span class="menuText">Hold Kaldır</span></v-btn
  >
  <v-btn
    @click="goBack"
    prepend-icon="mdi-chevron-double-left"
    block
    border
    
    rounded
    class="mt-3 custom-height"
    ><span class="menuText">Geri Dön</span></v-btn
  >
</template>

<script>
import { clearText } from "@/helpers/base";
import { tHpuFlagAction } from "@/constants/enums/tHpuFlagAction.js";
import { postData } from "@/utils/httpServices";
import MessageContent from "@/components/Base/MessageContent.vue";
import { BASE_URL } from "@/constants/apis/index";
export default {
  components: {
    MessageContent,
  },
  inject: ["openDialog","toggleLoadingOverlay"],
  data() {
    return {
      vin: "",
      response: {
        message: "",
        state: "",
      },
      successMessage: " HOLD KALDIRILDI.",
      errorMessage: " HOLD KALDIRILAMADI.",
    };
  },
  mounted() {
    //focus text field for mobile devices
    this.$refs.vinTextRef.focus();
  },
  methods: {
    async liftHold() {
      const vin = clearText(this.vin);
      if (vin == "") return;
      this.toggleLoadingOverlay();
      let res;

      try {
        res = await postData(`${BASE_URL}Hold/SetUnitHoldUnitBased`, {
          UnitId: vin,
          hpuFlagAction: tHpuFlagAction.RELEASE_HOLD,
        });
      } catch {
        this.openDialog(MessageContent, "No internet connection")
        this.vin = "";
        this.$refs.vinTextRef.focus();
        return;
      }
      finally {
        this.toggleLoadingOverlay();
      }

      //gelen rese göre response değişkeni güncellenecek
      if (res.Success.length > 0) {
        this.response = {
          message: `${vin}${this.successMessage}`,
          state: "success",
        };
      } else {
        this.response = {
          message: `${vin}${this.errorMessage}`,
          state: "error",
        };
      }
      this.vin = "";
      this.$refs.vinTextRef.focus();
    },
    goBack() {
      this.$router.push("/roro/holdmain");
    },
  },
};
</script>

<style scoped>
.left-aligned {
  text-align: left;
  display: block;
  font-size:clamp(1.4rem, 1.2vw + 1.6rem, 2.6rem);
  margin-bottom: 4px;
}

.responsive-spacer {
  height: calc(60vh / 2);
}

@media (max-height: 705px) {
  .responsive-spacer {
    height: calc(60vh / 3.5);
  }
}

@media (max-height: 540px) {
  .responsive-spacer {
    height: calc(60vh / 3.9);
  }
}

.menuText {
  font-size: clamp(1rem, 1.2vw + 1.2rem, 2.6rem);
  font-weight: bold;
  text-transform: none;
  white-space: wrap;
}

.custom-height {
  height: calc(60vh / 5);
}


</style>
