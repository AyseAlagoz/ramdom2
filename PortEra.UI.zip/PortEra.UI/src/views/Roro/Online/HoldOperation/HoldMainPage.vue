<template>
  <v-row>
    <v-col
      :cols="btn.col[buttonMode - 1]"
      v-for="(btn, index) in buttons"
      :key="btn.route"
    >
      <v-btn
        @click="goTo(btn.route)"
        rounded
        border
        block
        :class="buttonMode == 1 ? 'custom-height' : 'custom-height2'"
      >
        <span class="menuText">{{ btn.text }}</span>
      </v-btn>
    </v-col>
  </v-row>
</template>

<script>
import { useButtonModeStore } from "@/store/buttonMode";
export default {
  data() {
    return {
      buttons: [
        {
          text: "Liman Kilitleme",
          route: "/roro/setunitholdportbased",
          col: [12, 6],
        },
        {
          text: "TSE Hold Kaldırma",
          route: "/roro/setunitholdunitbased",
          col: [12, 6],
        },
        { text: "Geri Dön", route: "/roro", col: [12, 12] },
      ],
    };
  },
  computed: {
    buttonMode() {
      return useButtonModeStore().mode;
    },
  },
  methods: {
    goTo(page) {
      this.$router.push(page);
    },
  },
};
</script>
<style scoped>
.custom-height {
  height: calc(60vh / 2.7);
}

.custom-height2 {
  height: calc(80vh / 2.4);
}

@media (max-height: 550px) {
  .custom-height {
    height: calc(60vh / 3);
  }

  .custom-height2 {
    height: calc(80vh / 2.7);
  }
}

.menuText {
  font-size: clamp(1.2rem, 1.2vw + 0.4rem, 2.6rem);
  line-height: 1.2;
  padding: 0 4px;
  font-weight: bold;
  white-space: wrap;
}
</style>
