<template>
  <label> <span class="holdTitle">Çalışan Gemiler</span></label>
  <v-autocomplete
    v-model="selectedVesselVisit"
    :items="activeVessels"
    item-title="title"
    item-value="value"
    variant="outlined"
    @click:clear="selectedVesselVisit = { title: '', value: '' }"
    return-object
    @update:modelValue="updateComboEvent"
    clearable
  >
  </v-autocomplete>

  <div class="customContainer">
    <v-toolbar color="white" density="compact">
      <span class="mdi mdi-pound ml-2 hashStyle"></span>
      <span class="hashStyle ml-3"> Liman</span>
    </v-toolbar>
    <div class="mb-4">
      <v-list v-for="item in listItems" :key="item.value">
        <v-row @click="selectPodFromList(item)" dense class="customItemRow">
          <v-col cols="1">
            <v-checkbox
              v-model="selectedPods"
              :value="item.value"
              density="compact"
            ></v-checkbox>
          </v-col>
          <v-col cols="11">
            <span class="customListItem">
              {{ item.title }}
            </span>
          </v-col>
        </v-row>
      </v-list>
    </div>
  </div>

  <v-row class="mt-3 customRow" dense>
    <v-col cols="6">
      <v-btn @click="setHold(tHpuFlagAction.ADD_HOLD)" class="buttonStyle"
        >Kilitle</v-btn
      >
    </v-col>
    <v-col cols="6">
      <v-btn @click="setHold(tHpuFlagAction.RELEASE_HOLD)" class="buttonStyle"
        >Kaldır</v-btn
      >
    </v-col>
  </v-row>

  <v-row class="customRow" dense>
    <v-col cols="6">
      <v-btn @click="goTo('/roro/holdmain')" class="buttonStyle">Geri</v-btn>
    </v-col>
    <v-col cols="6">
      <v-btn @click="refresh" class="buttonStyle">Yenile</v-btn>
    </v-col>
  </v-row>
</template>

<script>
import ErrorMessageContent from "@/components/Base/ErrorMessageContent.vue";
import MessageContent from "@/components/Base/MessageContent.vue";
import { tHpuFlagAction } from "@/constants/enums/tHpuFlagAction.js";
import { postData } from "@/utils/httpServices.js";
import { BASE_URL } from "@/constants/apis";

export default {
  inject: ["toggleLoadingOverlay", "openDialog"],
  components: {
    ErrorMessageContent,
    MessageContent,
  },
  data() {
    return {
      tHpuFlagAction,
      selectedVesselVisit: {
        title: "",
        value: "",
      },
      listItems: [],
      activeVessels: [],
      selectedPods: [],
      message: "Gemi seçmediniz...",
      errorMessage: " limanı güncellenemedi.",
      successMessage: " limanı güncellendi.",
    };
  },
  methods: {
    goTo(page) {
      this.$router.push(page);
    },
    selectPodFromList(pod) {
      const index = this.selectedPods.findIndex(
        (selectedItem) => selectedItem === pod.value
      );
      if (index === -1) {
        this.selectedPods.push(pod.value);
      } else {
        this.selectedPods.splice(index, 1);
      }
    },
    async refresh() {
      this.updateComboEvent(this.selectedVesselVisit);
    },
    async updateComboEvent(e) {
      if (e == null || e.value === 0 || typeof e == "string") {
        return;
      }
      const res = await this.getPodListByVisitId(e.value);
      const formattedPorts = this.handlePodList(res);
      this.listItems = [...formattedPorts];
      this.selectedPods = [];
    },
    generatePortList(groupedPods) {
      return Object.keys(groupedPods).map((pod) => {
        const portHoldStatusList = groupedPods[pod].join(", ");
        return {
          value: pod,
          title: `PortName: ${pod}, PortHoldStatus: ${portHoldStatusList}`,
        };
      });
    },
    handlePodList(response) {
      const groupedPods = response.reduce((acc, { Pod, HoldStatus }) => {
        const key = `${Pod}`;
        if (!acc[key]) {
          acc[key] = [];
        }
        acc[key].push(`${Pod} - ${HoldStatus}`);
        return acc;
      }, {});

      const formattedPorts = this.generatePortList(groupedPods);

      return formattedPorts;
    },
    async getActiveVesselVisit() {
      try {
        const res = await postData(
          `${BASE_URL}VesselVisit/GetWorkingVesselVisits`
        );

        res.forEach((element) => {
          this.activeVessels.push({
            title: element.VesselVisitId,
            value: element.VesselVisitId,
          });
        });
      } catch {
        this.activeVessels = [];
      }
    },
    async getPodListByVisitId(visitId) {
      try {
        const data = await postData(
          `${BASE_URL}UnitLabel/GetPodListByVisit`,
          { VesselVisitId: visitId }
        );
        return data;
      } catch {
        return [];
      }
    },
    async setHold(hpuFlagAction) {
      if (
        this.selectedVesselVisit.value === 0 ||
        this.selectedVesselVisit.value === "" ||
        typeof this.selectedVesselVisit === "string" ||
        this.selectedVesselVisit.value == null
      ) {
        this.openDialog(ErrorMessageContent, this.message);
        return;
      }

      if (this.selectedPods.length === 0) {
        this.message = "Liman seçmediniz...";
        this.openDialog(ErrorMessageContent, this.message);
        return;
      }
      const messages = [];
      this.toggleLoadingOverlay();
      for (let item of this.selectedPods) {
        const status = await this.setUnitHoldPortBased(
          this.selectedVesselVisit.value,
          item,
          hpuFlagAction
        );
        if (!(status && status.Success && status.Success.length > 0))
          // burada ki ve şartından emin degilim reelde test et
          messages.push(`${item} ${this.errorMessage}`);
        else messages.push(`${item} ${this.successMessage}`);
      }
      this.message = messages.join(",");
      this.toggleLoadingOverlay();
      this.openDialog(MessageContent, this.message);
    },

    async setUnitHoldPortBased(visit, pod, hpuFlagAction) {
      try {
        const data  = await postData(
          `${BASE_URL}Hold/SetUnitHoldPortBased`,
          {
            VesselVisitId: visit,
            Pod: pod,
            hpuFlagAction: hpuFlagAction,
          }
        );
        return data;
      } catch {
        return null;
      }
    },
  },
  async created() {
    this.toggleLoadingOverlay();
    await this.getActiveVesselVisit();
    this.toggleLoadingOverlay();
  },
};
</script>

<style scoped>
.holdTitle {
  font-size: clamp(2rem, 1.2vw + 0.4rem, 3rem);
  font-weight: bold;
}

.hashStyle {
  font-size: clamp(2rem, 1.2vw + 0.4rem, 3rem);
}

.customContainer {
  padding-left: 5%;
  padding-right: 5%;
  border: 1px solid grey;
  height: calc(40vh / 1);
  max-height: 330px;
  overflow-y: auto;
}

.buttonStyle {
  width: 100%;
  height: calc(60vh / 5);
  font-size: clamp(0.2rem, 1.2vw + 1rem, 2.5rem);
  font-weight: bold;
  border: 1px solid grey;
}

.customListItem {
  font-family: Arial, Helvetica, sans-serif;
  text-align: left;
  white-space: nowrap;
  margin: 0;
  font-size: clamp(1.4rem, 1.2vw + 0.4rem, 1.7rem);
}

.v-list {
  display: flex;
  flex-direction: column;
  align-items: flex-start; /* Liste öğelerini sola hizalar */
}
.customItemRow {
  font-weight: bold;
}

@media (max-height: 810px) {
  .buttonStyle {
    height: calc(60vh / 7);
  }

  .customContainer {
    height: calc(40vh / 1.2);
  }
}

@media (max-height: 600px) {
  .buttonStyle {
    height: calc(60vh / 7.2);
  }

  .customContainer {
    height: calc(40vh / 1.4);
  }
}
</style>
