<template>
  <label for="VINLabel" class="left-aligned"><b>VIN</b></label>
  <v-text-field
    label=""
    variant="solo"
    v-model="vin"
    ref="vinTextRef"
    @keydown.enter="addDamage"
  ></v-text-field>

  <div class="responsive-spacer">
    <v-container class="left-aligned" v-show="response.state != ''">
      <span :class="response.state == 'success' ? 'fontGreen resLabel' : 'fontRed resLabel'">{{
        response.message
      }}</span>
    </v-container>
  </div>

  <v-btn
    block
    border
    size="70"
    rounded
    class="mt-3 customButton"
    @click="addDamage"
    ><span class="menuText">Hasar Ekle</span></v-btn
  >
  <v-btn
  @click="goBack"
    prepend-icon="mdi-chevron-double-left"
    block
    border
    size="70"
    rounded
    class="mt-3 customButton"
    ><span class="menuText">Geri Dön</span></v-btn
  >
</template>

<script>
import { clearText } from '@/helpers/base';
import { postData } from '@/utils/httpServices';
import MessageContent from '@/components/Base/MessageContent.vue';
import { BASE_URL } from '@/constants/apis/index';
export default {
  inject: ['openDialog','toggleLoadingOverlay'],
  components: {
    MessageContent,
  },
  data() {
    return {
      vin: "",
      response: {
        message: "",
        state: "",
      },
    };
  },
  mounted() {
    this.$refs.vinTextRef.focus();
  },
  methods: {
    async addDamage() {
      const vin = clearText(this.vin);
      if (vin == "") return;
      this.toggleLoadingOverlay();
      let res;

      try{
        res = await postData(`${BASE_URL}Damage/SendDamage`, { UnitId: vin });  // buradan muhtemelen res.data.UpdateResult dönecek if in içini ona göre degistir
      }
      catch (error){
        this.response = {
          message: `${vin} HASAR EKLENEMEDİ.`,
          state: "error",
        };
        this.vin = "";
        this.$refs.vinTextRef.focus();
        return;
      }
      finally{
        this.toggleLoadingOverlay();
      }
      if (res?.UpdateResult == "Success") {
        this.response = {
          message: `${vin} HASAR EKLENDİ.`,
          state: "success",
        };
      } 
      else {
        this.response = {
          message: `${vin} HASAR EKLENEMEDİ.`,
          state: "error",
        };
      }
      this.vin = "";
      this.$refs.vinTextRef.focus();
    },
    goBack() {
      this.$router.push('/roro');
    },
  },
};
</script>

<style scoped>
.left-aligned {
  text-align: left;
  display: block;
  font-size: clamp(1.4rem, 1.2vw + 1.6rem, 2.6rem);
}

.responsive-spacer {
  height: calc(60vh / 1.5);
}

@media (max-height: 770px) {
  .responsive-spacer {
    height: calc(60vh / 2.8);
  }
}
@media (max-height: 570px) {
  .responsive-spacer {
    height: calc(60vh / 3.2);
  }
}

.menuText {
  font-size: clamp(0.9rem, 1.2vw + 1rem, 2rem);
  line-height: 1.2;
  padding: 0 4px;
  white-space: wrap;
}

.resLabel{
  font-size: clamp(1.4rem, 1.2vw + 1.6rem, 2.6rem);
}

</style>
