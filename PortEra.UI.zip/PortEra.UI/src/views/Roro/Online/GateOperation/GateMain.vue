<template>

    <label for="PlakaLabel" class="left-aligned"><b>PLAKA</b></label>

    <v-text-field
      label=""
      variant="solo"
      v-model="plaka"
      ref="plakaTextRef"
      @keydown.enter="enterAndContinue"
    ></v-text-field>

    <div class="responsive-spacer"></div>

    <v-btn block border rounded class="custom-height" @click="enterAndContinue"
      ><span class="menuText">Gir ve Devam Et</span></v-btn
    >
    <v-btn
      @click="goBack"
      prepend-icon="mdi-chevron-double-left"
      block
      border
      rounded
      class="mt-3 custom-height"
      ><span class="menuText">Geri Dön</span></v-btn
    >
</template>

<script>
import { clearText } from "@/helpers/base";
export default {
  data() {
    return {
      plaka: "",
    };
  },
  mounted() {
    this.$refs.plakaTextRef.focus();
  },
  methods: {
    enterAndContinue() {
      const plaka = clearText(this.plaka);
      if (plaka == "") return;
      this.$router.push({
        path: "/roro/gateoperation",
        query: { plaka: plaka },
      });
      this.plaka = "";
    },
    goBack() {
      this.$router.push("/roro");
    },
  },
};
</script>

<style scoped>
.responsive-spacer {
  height: calc(60vh / 2);
}

@media (max-height: 680px) {
  .responsive-spacer {
    height: calc(60vh / 4);
  }
}

.left-aligned {
  text-align: left;
  display: block;
  font-size: clamp(1.4rem, 1.2vw + 1.8rem, 2.6rem);
  margin-bottom: 4px;
}

.menuText {
  font-size: clamp(0.9rem, 1.2vw + 1.2rem, 2rem);
  line-height: 1.2;
  padding: 0 4px;
  white-space: wrap;
  font-weight: bold;
}
.custom-height {
  height: calc(60vh / 5);
}

</style>
