<template>
  <label for="PlakaLabel" class="left-aligned"><b>PLAKA</b></label>
  <v-text-field
    label=""
    variant="solo"
    v-model="plaka"
    ref="plakaTextRef"
    readonly
  >
  </v-text-field>

  <label for="VINLabel" class="left-aligned"><b>VIN</b></label>
  <v-text-field
    label=""
    variant="solo"
    v-model="vin"
    ref="vinTextRef"
    @keydown.enter="setPregate"
  >
  </v-text-field>

  <div class="customDivgo">
    <v-container class="left-aligned" v-show="res.message != ''">
      <span>{{ res.message }}</span>
    </v-container>
  </div>

  <v-btn
    block
    border
    size="70"
    rounded
    color="green"
    class="mt-3 customButton"
    @click="getData"
    ><span class="menuText">Sorgula</span>
  </v-btn>
  <v-btn
    block
    border
    size="70"
    rounded
    color="red"
    class="mt-3 customButton"
    @click="goBackToGateMain"
    ><span class="menuText">Temizle</span></v-btn
  >
</template>

<script>
import { clearText } from "@/helpers/base";
import ErrorMessageContent from "@/components/Base/ErrorMessageContent.vue";
import MessageContent from "@/components/Base/MessageContent.vue";

export default {
  components: {
    ErrorMessageContent,
    MessageContent,
  },
  inject: ["openDialog"],
  data() {
    return {
      vin: "", //UNİT ID
      response: {
        message: "",
        state: "",
      },
      plaka: "", //PLATE
      operationCount: 1,
      lastVin: "",
      res: {
        message: "",
      },
    };
  },
  mounted() {
    //focus text field for mobile devices

    //SetPregate ve
    this.$refs.vinTextRef.focus();
    // dısarıdan gelen yani gatemainden gelen plakayı cleartext ile alıp buradaki plakaya basıcam
  },

  methods: {
    goBackToGateMain() {
      //Gate main sayfasına geri dönüş yapılacak
    },
    getData() {
        //"Unit/GetUnitByUnitId" , UnitId = vin ŞEKLİNDE POST ATILACAK
        //bu res ne olacak sorman lazım
    },
    setPregate() {
       //"Pregate/SetPregate", Plate = plate, UnitId = unitId ŞEKLİNDE POST ATILACAK
          //ekran da vin + response.Position + " TAMAMLANDI"
          //vın boşaltılıp 
          this.vin = "";
          this.$refs.vinTextRef.focus();
    },
  },
};
</script>

<style scoped>
.left-aligned {
  text-align: left;
  display: block;
  font-size: 2.6rem;
  margin-bottom: 4px;
}

.customDivgo {
  border: 0px #e0e0e0;
  height: 30%;
  max-height: 65%;
}
.menuText {
  font-size: 1.9rem;
  font-weight: bold;
  text-transform: none;
}
.fontGreen {
  color: green;
  font-size: 1.7rem;
}
.fontRed {
  color: red;
  font-size: 1.7rem;
}
</style>
