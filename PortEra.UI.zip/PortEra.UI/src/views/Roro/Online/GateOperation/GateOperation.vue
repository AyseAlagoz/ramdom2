<template>
  <label for="PlakaLabel" class="left-aligned"><b>PLAKA</b></label>
  <v-text-field
    label=""
    variant="solo"
    v-model="plaka"
    ref="plakaTextRef"
    readonly
  >
  </v-text-field>

  <label for="VINLabel" class="left-aligned"><b>VIN</b></label>
  <v-text-field
    label=""
    variant="solo"
    v-model="vin"
    ref="vinTextRef"
    @keydown.enter="sendPregate"
  >
  </v-text-field>

  <div class="responsive-spacer">
    <v-container class="resLabel" v-show="res.message != ''">
      <span>{{ res.message }}</span>
    </v-container>
  </div>

  <v-btn
    block
    border
    rounded
    class="mt-3 custom-height"
    @click="sendPregate"
    ><span class="menuText">Gönder</span>
  </v-btn>
  <v-btn
    block
    border
        rounded
    class="mt-3 custom-height"
    @click="goBackToGateMain"
    ><span class="menuText">Plaka Değiştir</span></v-btn
  >
</template>

<script>
import { clearText } from "@/helpers/base";
import ErrorMessageContent from "@/components/Base/ErrorMessageContent.vue";
import MessageContent from "@/components/Base/MessageContent.vue";
import { postData } from "@/utils/httpServices.js";
import { BASE_URL } from "@/constants/apis/index";
export default {
  components: {
    ErrorMessageContent,
    MessageContent,
  },
  inject: ["openDialog", "toggleLoadingOverlay"],
  data() {
    return {
      vin: "", //UNİT ID
      plaka: "", //PLATE
      operationCount: 1,
      lastVin: "",
      res: {
        message: "",
      },
    };
  },
  mounted() {
    this.$refs.vinTextRef.focus();
  },
  created() {
    const plaka = this.$route.query.plaka;
    if (plaka == null || plaka == "" || plaka == undefined) {
      this.$router.push("/roro/gatemain");
    }
    this.plaka = clearText(plaka);
    this.vin = "";
  },
  methods: {
    goBackToGateMain() {
      this.$router.push("/roro/gatemain");
    },

    async sendPregate() {
      if (this.operationCount > 9) {
        this.openDialog(ErrorMessageContent, "Beklenmeyen bir hata oluştu.");
        return;
      }
      const vin = clearText(this.vin);
      if (vin == "") return;
      this.toggleLoadingOverlay();

      let res;
      try {
        res = await postData(`${BASE_URL}Pregate/SetPregate`, {
          Plate: this.plaka,
          UnitId: vin,
        });
  
      } catch {
        this.openDialog(MessageContent, "Unexpected Error");
        this.vin = "";
        this.$refs.vinTextRef.focus();
        return;
      }
      finally {
        this.toggleLoadingOverlay();
      }


      if(res.data == null || res.data == undefined) {
        this.openDialog(ErrorMessageContent, "Aktif Kayıt Bulunamadı");
        this.vin = "";
        this.$refs.vinTextRef.focus();
        return;
      }
      this.res = res.data;

      if (this.res.message === null || this.res.message === "" || this.res == null || this.res == undefined) {
        this.openDialog(ErrorMessageContent, "Aktif Kayıt Bulunamadı");
        this.vin = "";
        this.$refs.vinTextRef.focus();
        return;
      }

      this.openDialog(MessageContent, this.res.message);
      this.lastVin = vin;
      this.vin = "";
      const message = `${this.lastVin}\n POD: ${
        this.res.Pod
      } TAMAMLANDI \nOKUTULAN : ${this.operationCount.toString()}`;

      this.res.message = message;
      this.operationCount++;
    },
  },
};
</script>

<style scoped>
.left-aligned {
  text-align: left;
  display: block;
  font-size: clamp(1.4rem, 1.2vw + 1.6rem, 2rem);
}
.responsive-spacer {
  height: calc(120vh / 8);
  font-size: clamp(1.4rem, 1.2vw + 1.6rem, 2rem);
}

.menuText {
  font-size: clamp(0.9rem, 1.2vw + 1rem, 1.7rem);
  line-height: 1.2;
  padding: 0 4px;
  white-space: wrap;
  font-weight: bold;
}
.custom-height {
  height: calc(60vh / 5);
}

@media (max-height: 700px) {
  .custom-height {
    height: calc(60vh / 6);
  }
  .responsive-spacer {
    height: calc(120vh / 10);
  }
}

.resLabel {
  font-size: clamp(0.2rem, 1.2vw + 1rem, 2rem);
  text-align: left;
  display: block;
}
</style>
