<template>
    <v-card class="cardBorder">
      <v-table fixed-header class="tableHeight" hover>
        <thead>
          <tr class="customHeader">
            <th class="text-left emptyColon"></th>
            <th class="text-left">Marka</th>
            <th class="text-left">Model</th>
            <th class="text-left">Liman</th>
            <th class="text-left">Toplam</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="item in exportUnits"
            :key="item.id"
            @click="tableRowClick(item)"
          >
            <td>
              <v-checkbox
                v-model="selectedExportUnits"
                :value="item.id"
                density="compact"
                hide-details
              >
              </v-checkbox>
            </td>
            <td>{{ item.Brand }}</td>
            <td>{{ item.Model }}</td>
            <td>{{ item.PortOfDischarge }}</td>
            <td>{{ item.TotalCount }}</td>
          </tr>
        </tbody>
      </v-table>
    </v-card>
    <div class="responsive-spacer"></div>
    <v-btn
      border
      block
     
      rounded
      class="mt-8 buttonStyle"
      @click="registerOfflineData"
      
      ><span class="menuText">Çevrimdışına Aktar</span></v-btn
    >
    <v-btn
      @click="goBack"
      border
      block
      
      rounded
      class="mt-2 buttonStyle"
      prepend-icon="mdi-chevron-double-left"
      ><span class="menuText">Geri Dön</span></v-btn
    >

</template>

<script>
//BAGLANTILAR MODULE TASINACAK SİMDİLİK DATA İCİN

//vessel ıd yollamadan tüm data geliyor de bunu
import {useIndexedDBStore} from "@/CommonVueCore/src/store/stores/indexDBStores.js";
import { BASE_URL } from "@/constants/apis";
import { postData } from "@/utils/httpServices.js"
import MessageContent from "@/components/Base/MessageContent.vue";

export default {
  inject: ["openDialog"],
  data() {
    return {
      exportUnits: [],
      selectedExportUnits: [],
      backPagePath: "/roro/offlinelabeldefinationvesselvisit",
    };
  },
  methods: {
    tableRowClick(item) {
      const index = this.selectedExportUnits.indexOf(item.id);
      if (index === -1) {
        this.selectedExportUnits.push(item.id);
      } else {
        this.selectedExportUnits.splice(index, 1);
      }
    },
    async registerOfflineData() {
      if (this.selectedExportUnits.length === 0) {
        this.openDialog(MessageContent, "Lütfen en az bir kayıt seçiniz.");
        return;
      }
      let registerDatas = []; 

      this.selectedExportUnits.sort();
      
      this.selectedExportUnits.forEach((item) => {
        const result = this.exportUnits.filter((unit) => unit.id === item);
        registerDatas.push(...result); 
      });

      let offlineLabelDefination = [];

      registerDatas.forEach((exportUnit) => {
        exportUnit.UnitId.forEach((unitId) => {
          offlineLabelDefination.push({
            Brand: exportUnit.Brand,
            Model: exportUnit.Model,
            POD: exportUnit.PortOfDischarge,
            VIN: unitId,
            InboundCount: exportUnit.InboundCount,
            TotalCount: exportUnit.TotalCount,
          });
        });
      });

      offlineLabelDefination = offlineLabelDefination.filter(
        (value, index, self) =>
          index === self.findIndex((t) => t.VIN === value.VIN)
      );

      try {
        await useIndexedDBStore().deleteSelectedCollection({
          dbName: "Roro",
          collectionName: "OfflineLabelDefination",
        });
      } catch {
        console.log("OfflineLabelDefination collection not found");
      }
 
      try {
        await useIndexedDBStore().addData({
          dbName: "Roro",
          collectionName: "OfflineLabelDefination",
          dataList: offlineLabelDefination,
          keyPath: "VIN",
          autoIncrement: false,
        });

        this.openDialog(MessageContent, offlineLabelDefination.length + " adet veri çevrimdışına aktarıldı.");
      } catch (error) {
        this.openDialog(MessageContent, "Beklenmeyen bir hata oluştu.");
      }

      this.selectedExportUnits = [];
 
    },
    goBack() {
      this.$router.push(this.backPagePath);
    },
  },
  async created() {
    const vesselId = this.$route.query.vesselId;

    if (!vesselId) {
      this.$router.push(this.backPagePath);
      return;
    }

    const res = await postData(`${BASE_URL}Unit/GetExportUnitsByObForLabel`, {
      VesselVisitId: vesselId,
    });

    if (res.length == 0) {
      this.$router.push(this.backPagePath);
    }

    res.forEach((item, index) => {
      item.id = index;
    });
    this.exportUnits = res;
  },
};
</script>

<style scoped>
.customHeader > th {
  font-weight: bold !important;
  font-size: clamp(1.4rem, 1.2vw + 1.6rem, 2.6rem);
}
.menuText {
  font-size: clamp(1.4rem, 1.2vw + 1.6rem, 2.6rem);
  font-weight: bold;
  text-transform: none;
  white-space: wrap;
}
.cardBorder {
  border: 1px solid black;
  border-radius: 5px;
}
.tableHeight{
  height: calc(60vh / 1);
  max-height: 1200px;
}
@media (max-height: 950px) {
  .tableHeight{
    height: calc(60vh / 1.3);
  }
}
.buttonStyle{
  font-size: clamp(1.4rem, 1.2vw + 1.6rem, 2.6rem);
  font-weight: bold;
  height: calc(60vh / 5);
  text-transform: none;
  white-space: wrap;
}
</style>
