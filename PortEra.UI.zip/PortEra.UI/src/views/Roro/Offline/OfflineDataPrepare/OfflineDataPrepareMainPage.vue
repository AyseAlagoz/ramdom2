<template>
  <v-row>
    <v-col
      v-for="(btn, index) in buttons"
      :key="index"
      :cols="btn.cols[buttonMode - 1]"
    >
      <v-btn
        :prepend-icon="btn.icon"
        @click="btn.func"
        :color="btn.color"
        rounded
        border
        block
        :class="buttonMode == 1 ? 'custom-height' : 'custom-height2'"
        ><span class="menuText">{{ btn.text }}</span></v-btn
      >
    </v-col>
  </v-row>
</template>

<script>
import MessageContent from "@/components/Base/MessageContent.vue";
import { BASE_URL } from "@/constants/apis/index.js";
import { postData } from "@/utils/httpServices.js"
import { useIndexedDBStore } from "@/CommonVueCore/src/store/stores/indexDBStores.js";
import { useButtonModeStore } from "@/store/buttonMode";

export default {
  inject: ["toggleLoadingOverlay", "openDialog"],
  components: {
    MessageContent,
  },
  data() {
    return {
      buttons: [
        {
          text: "Etiketleme Hazırlık",
          func: () => {
            this.goTo("/roro/offlinelabeldefinationvesselvisit");
          },
          cols: [12, 6],
          color: "white",
        },
        {
          text: "Saha Hazırlık",
          func: () => {
            this.insertYardMapping();
          },
          cols: [12, 6],
          color: "white",
        },
        {
          text: "Gemi Hazırlık",
          func: () => {
            this.setVesseLMapping();
          },
          cols: [12, 12],
          color: "white",
        },
        {
          text: "Geri Dön",
          func: () => {
            this.goTo("/roro/offlinemenu");
          },
          cols: [12, 12],
          color: "white",
          icon: "mdi-chevron-double-left",
        },
      ],
    };
  },
  computed: {
    buttonMode() {
      return useButtonModeStore().mode;
    },
  },
  methods: {
    goTo(page) {
      this.$router.push(page);
    },
    async insertYardMapping() {
      this.toggleLoadingOverlay();
      try {
        await useIndexedDBStore().deleteSelectedCollection({
          dbName: "Roro",
          collectionName: "YardMap",
        });
      } catch {
        console.log("YardMap collection not found");
      }

      try {
        const data = await postData(`${BASE_URL}Unit/GetYardPlan`); //[{Name:""}] formatında res geliyor

        await useIndexedDBStore().addData({
          dbName: "Roro",
          collectionName: "YardMap",
          dataList: data,
          keyPath: "id",
          autoIncrement: true,
        });

        this.openDialog(MessageContent, "Sahalar hazırlandı.");
      } catch (error) {
        this.openDialog(MessageContent, "Beklenmeyen bir hata oluştu.");
      }

      this.toggleLoadingOverlay();
    },
    async setVesseLMapping() {
      this.toggleLoadingOverlay();
      try {
        await useIndexedDBStore().deleteSelectedCollection({
          dbName: "Roro",
          collectionName: "OfflineVesselVisit",
        });
      } catch {
        console.log("OfflineVesselVisit collection not found");
      }

      try {
        const data = await postData(
          `${BASE_URL}VesselVisit/GetActiveVesselVisits`
        ); //[{Name:""}] formatında res geliyor
        await useIndexedDBStore().addData({
          dbName: "Roro",
          collectionName: "OfflineVesselVisit",
          dataList: data,
          keyPath: "VesselVisitId",
          autoIncrement: false,
        });

        this.openDialog(MessageContent, "Gemiler hazırlandı.");
      } catch (error) {
        this.openDialog(MessageContent, "Beklenmeyen bir hata oluştu.");
      }

      this.toggleLoadingOverlay();
    },
    checkDuplicateNames(arr) {
      return arr.some((item, index, self) =>
        self.some(
          (otherItem, otherIndex) =>
            otherIndex !== index && item.name === otherItem.name
        )
      );
    },
  },
};
</script>

<style scoped>
.menuText {
  font-size: clamp(0.2rem, 1.2vw + 1.3rem, 2.5rem);
  font-weight: bold;
  text-transform: none;
  white-space: wrap;
}

.custom-height {
  height: calc(60vh / 3.3);
}

@media (max-height: 850px) {
  .custom-height {
    height: calc(60vh / 3.5);
  }
}

.custom-height2 {
  height: calc(60vh / 2.4);
}

@media (max-height: 790px) {
  .custom-height2 {
    height: calc(60vh / 2.6);
  }
}

@media (max-height: 680px) {
  .custom-height2 {
    height: calc(60vh / 2.8);
  }

  .custom-height {
    height: calc(60vh / 4);
  }
}
</style>
