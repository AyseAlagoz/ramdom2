<template>
  <label>
    <span class="customHeader">Aktif Gemiler</span>
  </label>
  <v-card class="cardBorder">
    <v-table fixed-header class="tableHeight" hover>
      <thead>
        <tr class="customHeader">
          <th class="text-left emptyColon"></th>
          <th class="text-left">Sefer No</th>
          <th class="text-left">Gemi</th>
        </tr>
      </thead>
      <tbody>
        <tr
          v-for="item in vessels"
          :key="item.VesselVisitId"
          @click="tableRowClick(item)"
        >
          <td>
            <v-checkbox
              v-model="selectedVessel"
              :value="item.VesselVisitId"
              density="compact"
              hide-details
            >
            </v-checkbox>
          </td>
          <td>{{ item.VesselVisitId }}</td>
          <td>{{ item.VesselName }}</td>
        </tr>
      </tbody>
    </v-table>
  </v-card>

  <div class="responsive-spacer"></div>
  <v-btn @click="selectAndContinue" border block size="80" rounded class="mt-8"
    ><span class="menuText">Seç ve Devam Et</span></v-btn
  >
  <v-btn
    @click="goBack"
    border
    block
    size="80"
    rounded
    class="mt-2"
    prepend-icon="mdi-chevron-double-left"
    ><span class="menuText">Geri Dön</span></v-btn
  >
</template>

<script>
//BAGLANTILAR MODULE TASINACAK SİMDİLİK DATA İCİN
import { BASE_URL } from "@/constants/apis";
//Bu sayfada checkbox olucak fakat sadece bir data seçilebilir olucak
import ErrorMessageContent from "@/components/Base/ErrorMessageContent.vue";
import { postData } from "@/utils/httpServices.js";
/*
[
    {
        VesselName: "", 
        VesselVisitId: 0 
    }
]
*/
export default {
  inject: ["openDialog"],
  components: {
    ErrorMessageContent,
  },
  data() {
    return {
      vessels: [],
      vessel: {
        VesselName: "",
        VesselVisitId: "",
      },
      selectedVessel: "",
    };
  },
  methods: {
    async getActiveVesselVisits() {
      try {
        const res = await postData(
        `${BASE_URL}VesselVisit/GetActiveVesselVisits`
      );
     
      this.vessels = res;
      }catch {
        this.vessels = [];
      }
     
    },
    tableRowClick(item) {
      if (this.selectedVessel === item.VesselVisitId) {
        this.selectedVessel = "";
        return;
      }
      this.selectedVessel = item.VesselVisitId;
    },
    goBack() {
      this.$router.push('/roro/offlinedatapreparemain');
    },
    async selectAndContinue() {
      if (this.selectedVessel === "") {
        this.openDialog(
          ErrorMessageContent,
          "Lütfen bir gemi seçiniz."
        );
        return;
      }
      this.$router.push({
        path: "/roro/offlinelabeldefinationdetail",
        query: { vesselId: this.selectedVessel },
      });
    },
  },
  created() {
    this.getActiveVesselVisits();
  },
  mounted() {
    // const isNoVessel = window.history.state.back.includes(
    //   "/offlinelabeldefinationdetail"
    // );
    // if (isNoVessel) {
    //   this.openDialog(
    //    ErrorMessageContent,
    //     "Seçilen gemiye ait veri bulunamadı."
    //   );
    // }
  },
};
</script>

<style scoped>
.customHeader {
  font-size: clamp(1rem, 1.2vw + 1rem, 2rem);
  font-weight: bold;
}
.emptyColon {
  width: 50px;
}

.menuText {
  font-size: clamp(1.4rem, 1.2vw + 1.6rem, 2.6rem);
  font-weight: bold;
  text-transform: none;
}
.cardBorder {
  border: 1px solid black;
  border-radius: 5px;
}

.tableHeight{
  height: calc(60vh / 1.3);
  max-height: 400px;
}

.responsive-spacer {
  height: calc(60vh / 13);
}

@media (max-height: 780px) {
  .responsive-spacer {
    height: 0px
  }

  .tableHeight{
    height: calc(60vh / 1.5);
  }
}
</style>
