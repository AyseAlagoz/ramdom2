<template>
  <v-container>
    <label for="fieldAdressLabel" class="fieldAdressLabel"
      >YENİ SAHA ADRESİ</label
    >
    <v-select
      variant="outlined"
      v-model="yardAdress"
      :items="comboItems"
      hide-details
    />
    <label for="vinLabel" class="vinLabel mt-3">VIN</label>
    <v-text-field
      v-model="vin"
      variant="outlined"
      ref="vinTextRef"
      @keydown.enter="enterEvent"
    />
    <v-card elevation="0" class="cardStyle">
      <label
        for="statusLabel"
        class="fieldAdressLabel"
        :style="{ color: statusColor }"
        >{{ status }}</label
      >
    </v-card>
    <v-card elevation="0" class="buttonCard">
      <v-btn
        v-if="btnIptalVisible"
        @click="deleteOfflineShifting"
        block
        border
        class="buttonStyle mb-1"
        rounded
        
        ><span class="menuText">Iptal Et</span></v-btn
      >
    </v-card>
    <v-btn
      prepend-icon="mdi-chevron-double-left"
      @click="goTo"
      block
      border
      class="mt-3 buttonStyle"
      rounded
      
    >
      <template v-slot:prepend>
        <v-icon size="large">mdi-chevron-double-left</v-icon
        ><span class="menuText">Geri Dön</span></template
      >
    </v-btn>
  </v-container>
</template>

<script>
import { clearText } from "@/helpers/base";
import { useIndexedDBStore } from "@/CommonVueCore/src/store/stores/indexDBStores.js";

export default {
  data() {
    return {
      yardAdress: "", 
      vin: "",
      comboItems: [], // string[]
      btnIptalVisible: true,
      status: "",
      lastPkey: 0,
      selectedComboItem: { value: "", text: "" },
      statusColor: "",
      shiftingType: "",
    };
  },
  methods: {
    goTo() {
      this.$router.push({ path: "/roro/offlineshiftingmain" });
    },
    async deleteOfflineShifting() {
      //burada seçili olan son pkey ile offline shifting silinecek
      //OfflineShiftings.Remove(model);  DeleteOfflineShifting(new OfflineShifting { PKey = _lastPkey }); gibi req atılmıs
      try {
        await useIndexedDBStore().deleteData({
          dbName: "Roro",
          collectionName: "OfflineShiftings",
          keyList: [this.lastPkey],
        });
        this.status = "Silme işlemi başarılı";
        this.statusColor = "green";
        this.lastPkey = 0;
        this.btnIptalVisible = false;
      } catch {
        this.status = "Silme işlemi başarısız";
        this.statusColor = "red";
      }
    },
    async enterEvent() {
      const vin = clearText(this.vin);
      if (vin === "" || this.yardAdress === "") {
        this.status = "Lütfen alanları doldurunuz";
        return;
      }

      const offlineShifting = await this.getOfflineShiftingByVIN(vin);

      if (offlineShifting != null) {
        this.btnIptalVisible = true;
        this.lastPkey = offlineShifting.id;
        this.vin = offlineShifting.VIN;
        this.status = `${offlineShifting.VIN} DAHA ÖNCEDEN OKUNDU. SİLMEK İÇİN İPTAL TUŞUNA BASINIZ.`;
        this.statusColor = "red";
      } else {
        this.lastPkey = 0;
        this.btnIptalVisible = false;
        await this.insertOfflineShifting({
          VIN: vin,
          ToPosition: this.yardAdress,
          ShiftingType: this.shiftingType,
          VesselVisitId: "",
        });
        this.status = `${vin} OKUNDU`;
        this.statusColor = "green";
      }
      this.$refs.vinTextRef.focus();
      this.vin = "";
    },
    async getOfflineShiftingByVIN(vin) {
      // index Db OfflineShiftings.FirstOrDefault(t => t.VIN == vin && t.ShiftingType == shiftingType); ==> shiftingType queryden gelicek
      //nuradan tek bir tane offline shifting gelecek
      try {
        const res = await useIndexedDBStore().getDataWithFilter({
          dbName: "Roro",
          collectionName: "OfflineShiftings",
          filterCallback: (data) =>
            data.VIN == vin && data.ShiftingType == this.shiftingType,
        });
        return res[0];
      } catch {
        return null;
      }
    },
    async insertOfflineShifting(offlineShifting) {
      //indexDb ye offlineShifting eklenecek OfflineShiftings.Add(model);
      try {
        await useIndexedDBStore().addData({
          dbName: "Roro",
          collectionName: "OfflineShiftings",
          dataList: [offlineShifting],
          keyPath: "id",
          autoIncrement: true,
        });
      } catch {
        this.status = "Eklenirken hata oluştu";
        this.statusColor = "red";
      }
    },
    async getComboItems() {
      try {
        const yardMaps = await useIndexedDBStore().getSelectedCollection({
        dbName: "Roro",
        collectionName: "YardMap",
      });
      this.comboItems = yardMaps.map((t) => t.Name);
      } catch  {
        this.comboItems = [];
        this.status = "Saha bilgileri alınamadı";
        this.statusColor = "red";
      }
      
      //indexDb den combo verisi cekiliyor YardMaps.ToList();
    },
  },
  created() {
    this.shiftingType = this.$route.query.shiftingType;
    if (
      this.shiftingType === undefined ||
      this.shiftingType === null ||
      this.shiftingType.trim() === ""
    ) {
      this.$router.push({ path: "/roro/offlineshiftingmain" });
    }
    this.status = "";
    this.statusColor = "";
    this.lastPkey = 0;
    this.btnIptalVisible = false;
    this.vin = "";
    this.yardAdress = "";
 },
  async mounted() {
    await this.getComboItems();
    this.$refs.vinTextRef.focus();
  },
};
</script>

<style scoped>
.fieldAdressLabel,
.vinLabel {
  font-size: clamp(0.2rem, 1.2vw + 1rem, 2.5rem);
  font-weight: bold;
  text-align: left;
  display: block;
}
.menuText {
  font-size: clamp(0.2rem, 1.2vw + 1.5rem, 3.5rem);
  font-weight: bold;
  text-transform: none;
}
.buttonStyle{
  height: calc(40vh / 3);
}
.buttonCard{
  height: calc(40vh / 3);
}
@media (max-height: 600px) {
  .buttonStyle{
    height: calc(40vh / 4);
  }
}
</style>
