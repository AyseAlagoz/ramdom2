<template>
  <v-row dense>
    <v-col v-for="(btn, index) in buttons" :key="index" :cols="btn.col[buttonMode-1]">
      <v-btn
        @click="btn.click"
        border
        block
        rounded
        :class="buttonMode == 1 ? 'custom-height' : 'custom-height2'"
        ><span class="menuText">{{ btn.text }}</span></v-btn>


    </v-col>
  </v-row>
</template>

<script>
import { RoroShiftingType } from "@/constants/enums/RoroShiftingType";
import { useButtonModeStore } from "@/store/buttonMode";

export default {
  data() {
    return {
      RoroShiftingType,
      buttons: [
        {
          text: "Saha Güncelleme",
          click: () => {
            this.goTo("/roro/yardupdatenobillable", RoroShiftingType.YARDMOVE);
          },
          color: "white",
          icon: "",
          col: [12, 6],
        },
        {
          text: "Ücretli Aktarma",
          click: () => {
            this.goTo(
              "/roro/yardupdatenobillable",
              RoroShiftingType.BILLABLEYARDMOVE
            );
          },
          color: "white",
          icon: "",
          col: [12, 6],
        },
        {
          text: "GemiGemi",
          click: () => {
            this.goTo("/roro/offlinevesselshifting");
          },
          color: "white",
          icon: "",
          col: [12, 12],
        },
        {
          text: "Geri Dön",
          click: () => {
            this.goTo("/roro/offlineoperationmain");
          },
          color: "white",
          icon: "mdi-chevron-double-left",
          col: [12, 12],
        },
      ],
    };
  },
  computed: {
    buttonMode() {
      return useButtonModeStore().mode;
    },
  },
  methods: {
    goTo(path, RoroShiftingType = null) {
      if (path == null) {
        alert("Couldn't find a path to go");
        return;
      }
      if (RoroShiftingType == null) {
        this.$router.push(path);
        return;
      }
      this.$router.push({
        path: path,
        query: { shiftingType: RoroShiftingType },
      });
    },
  },
};
</script>

<style scoped>
.menuText {
  font-size: clamp(0.2rem, 1.2vw + 1.2rem, 2.5rem);
  font-weight: bold;
  text-transform: none;
  white-space: wrap;
}


.custom-height {
  height: calc(40vh / 2.5);
}


.custom-height2 {
  height: calc(40vh / 1.5);
}

@media (max-height: 770px) {
  .custom-height2 {
    height: calc(40vh / 1.8);
  }
}
</style>
