<template>
  <v-container>
    <label for="vesselLabel" class="vesselLabel">GEMİ</label>

    <v-autocomplete
      variant="outlined"
      v-model="selectedVessel"
      :items="comboItems"
      item-title="VesselName"
      item-value="VesselId"
      hide-details
    />
    <label for="vinLabel" class="vinLabel mt-3">VIN</label>
    <v-text-field
      v-model="vin"
      variant="outlined"
      ref="vinTextRef"
      @keydown.enter="enterEvent"
    />
    <v-card elevation="0" class="statusCardStyle">
      <label
        for="statusLabel"
        class="vesselLabel"
        :style="{ color: statusColor }"
        >{{ status }}</label
      >
    </v-card>
    <label for="okutulanLabel" class="vesselLabel"
      >OKUTULAN : {{ count || "" }}</label
    >
    <v-card elevation="0" class="buttonCard">
      <v-btn
        v-if="btnIptalVisible"
        @click="deleteOfflineShifting"
        block
        border
  
        rounded
        class=" buttonStyle"
        color="red"
        ><span class="menuText">Iptal</span></v-btn
      >
    </v-card>
    <v-btn
      prepend-icon="mdi-chevron-double-left"
      @click="goTo"
      block
      border
  
      rounded
      class="mt-1 buttonStyle"
    >
      <template v-slot:prepend>
        <v-icon size="large">mdi-chevron-double-left</v-icon
        ><span class="menuText">Geri Dön</span></template
      >
    </v-btn>
  </v-container>
</template>

<script>
import { clearText } from "@/helpers/base";
import ErrorMessageContent from "@/components/Base/ErrorMessageContent.vue";
import { RoroShiftingType } from "@/constants/enums/RoroShiftingType";
import { useIndexedDBStore } from "@/CommonVueCore/src/store/stores/indexDBStores.js";

export default {
  inject: ["openDialog"],
  data() {
    return {
      selectedVessel: {
        VesselName: "",
        VesselId: "",
      }, //string olsa yeter gibi
      vin: "",
      comboItems: [], // string[]
      btnIptalVisible: true,
      status: "",
      lastPkey: 0,
      statusColor: "black",
      count: 0,
    };
  },
  methods: {
    goTo() {
      this.$router.push({ path: "/roro/offlineshiftingmain" });
    },
    async deleteOfflineShifting() {
      //burada random stringte ne yapması gerekiyor.
      //burada seçili olan son pkey ile offline shifting silinecek
      //OfflineShiftings.Remove(model);  DeleteOfflineShifting(new OfflineShifting { PKey = _lastPkey }); gibi req atılmıs
      try {
        await useIndexedDBStore().deleteData({
          dbName: "Roro",
          collectionName: "OfflineShiftings",
          keyList: [this.lastPkey],
        });
        this.status = "Silme işlemi başarılı";
        this.statusColor = "green";
        this.lastPkey = 0;
        this.btnIptalVisible = false;
        this.count--;
      } catch {
        this.status = "Silme işlemi başarısız";
        this.statusColor = "red";
      }
    },
    async enterEvent() {
      const vin = clearText(this.vin);
      if (vin === "" || this.selectedVessel === "") {
        this.openDialog(
          ErrorMessageContent,
          "Lütfen Gerekli bilgileri doldurun!"
        );
        return;
      }
      this.vin = "";
      const offlineShifting = await this.getOfflineShiftingByVIN(vin);
      
      this.btnIptalVisible = false;
      this.status = "";
      if (offlineShifting != null) {
        this.btnIptalVisible = true;
        this.lastPkey = offlineShifting.id;
        this.status = `${offlineShifting.VIN}  ONCEDEN EKLENDI. SILMEK ICIN IPTAL TUSUNA BASABILIRSINIZ.`;
      } 
      else {
        this.lastPkey = 0;

        this.insertOfflineShifting({
          VIN: vin,
          ShiftingType: RoroShiftingType.BILLABLEVESSELTOVESSELMOVE,
          VesselVisitId: this.selectedVessel,
        });
        this.status = `${vin} EKLENDI`;
        this.statusColor = "green";
      }
      this.count = await this.getTotalCount();
    },
    async getOfflineShiftingByVIN(vin) {
      // index Db OfflineShiftings.FirstOrDefault(t => t.VIN == vin && t.ShiftingType == RoroShiftingType.BILLABLEVESSELTOVESSELMOVE);
      //nuradan tek bir tane offline shifting gelecek
      try {
        const res = await useIndexedDBStore().getDataWithFilter({
          dbName: "Roro",
          collectionName: "OfflineShiftings",
          filterCallback: (data) =>
            data.VIN == vin && data.ShiftingType == RoroShiftingType.BILLABLEVESSELTOVESSELMOVE,
        });
        console.log(res)
        return res[0];
      } catch {
        return null;
      }
    },
    async insertOfflineShifting(offlineShifting) {
      //indexDb ye offlineShifting eklenecek OfflineShiftings.Add(model);
      try {
        await useIndexedDBStore().addData({
          dbName: "Roro",
          collectionName: "OfflineShiftings",
          dataList: [offlineShifting],
          keyPath: "id",
          autoIncrement: true,
        });
      } catch {
        this.openDialog(ErrorMessageContent, "Bir hata oluştu.");
      }
    },
    async getOfflineVesselVisits() {
      //combo dolduruyor
      //indexDb den offlineVesselVisits cekilecek
      //OfflineVesselVisitss.ToList();
      try {
        const data = await useIndexedDBStore().getSelectedCollection({
          dbName: "Roro",
          collectionName: "OfflineVesselVisit",
        });
        return data;
      } catch {
        return [];
      }
    },
    async getTotalCount() {     
      try {
        const filteredData = await useIndexedDBStore().getDataWithFilter({
          dbName: "Roro",
          collectionName: "OfflineShiftings",
          filterCallback: (data) =>
            data.ShiftingType == RoroShiftingType.BILLABLEVESSELTOVESSELMOVE,
        });
        return await filteredData.length;
      } catch {
        return 0;
      }
    },
  },
  created() {
    this.status = "";
    this.statusColor = "";
    this.lastPkey = 0;
    this.btnIptalVisible = false;
    this.vin = "";
    this.selectedVessel = "";

  },
  async mounted() {
    this.count = await this.getTotalCount();
    this.comboItems = await this.getOfflineVesselVisits();
    this.$refs.vinTextRef.focus();
  },
};
</script>

<style scoped>
.vesselLabel,
.vinLabel {
  font-size: clamp(0.2rem, 1.2vw + 1rem, 2.5rem);
  font-weight: bold;
  text-align: left;
  display: block;
}
.menuText {
  font-size: clamp(0.2rem, 1.2vw + 1.2rem, 2.5rem);
  font-weight: bold;
  text-transform: none;
  white-space: wrap;
}
.buttonStyle{
  height: calc(60vh / 4);
}
.buttonCard{
  height: calc(60vh / 4);
}
.statusCardStyle{
  height: calc(60vh / 4);
}
@media (max-height: 600px) {
  .buttonStyle{
    height: calc(60vh / 6);
  }
  .buttonCard{
  height: calc(60vh / 6);
}
}
@media (max-height: 850px) {
  .buttonStyle{
  height: calc(60vh / 5);
}
.buttonCard{
  height: calc(60vh / 5);
}
}
/* @media (max-height: 600px) {
  .buttonStyle{
    height: calc(60vh / 8);
  }
} */
</style>
