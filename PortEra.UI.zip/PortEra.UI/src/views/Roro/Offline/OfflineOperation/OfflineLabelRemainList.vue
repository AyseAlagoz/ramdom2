<template>
  <v-container>
    <label for="labelRemainHeader" class="labelRemainHeader"
      ><b>Etiket Kalan Listesi</b></label
    >
    <v-card class="cardBorder">
      <v-table height="33rem">
        <tbody>
          <tr v-for="item in labelRemainList" :key="item">
            <td>
              <span class="menuItem">
                {{ item }}
              </span>
            </td>
          </tr>
        </tbody>
      </v-table>
    </v-card>
    <label class="remainLabel"
      >{{ labelRemainList.length }} adet etiket kaldı.</label
    >
    <v-btn
      @click="goBack"
      border
      block
      
      rounded
      class="mt-4 buttonStyle"
      prepend-icon="mdi-chevron-double-left"
      ><span class="menuText">Geri Dön</span></v-btn
    >
  </v-container>
</template>

<script>
import ErrorMessageContent from "@/components/Base/ErrorMessageContent";
import MessageContent from "@/components/Base/MessageContent";
import { useIndexedDBStore } from "@/CommonVueCore/src/store/stores/indexDBStores.js";
export default {
  inject: ["openDialog"],
  components: {
    ErrorMessageContent,
    MessageContent
  },
  data() {
    return {
      labelRemainList: [],
    };
  },
  methods: {
    goBack() {
      this.$router.push("/roro/offlineoperationmain");
    },
    async getLabelRemainList() {
      try {
        const res = await useIndexedDBStore().getDataWithFilter({
          dbName: "Roro",
          collectionName: "OfflineLabelDefination",
          filterCallback: (data) => !data.IsTick,
        });

        if (res.length === 0) {
          this.openDialog(MessageContent, "Kayıt bulunamadı!.");
          return;
        }
        this.labelRemainList = res.map((item) => item.VIN);
      } catch {
        this.openDialog(ErrorMessageContent, "Kayıt bulunamadı!.");
        return;
      }
    },
  },
  async mounted() {
    // this.openDialog(ErrorMessageContent, "Hata mesajı");
    await this.getLabelRemainList();
  },
};
</script>

<style scoped>
.labelRemainHeader {
  font-size: clamp(0.2rem, 1.2vw + 1.2rem, 2.5rem);
}
.cardBorder {
  border: 1px solid black;
  border-radius: 5px;
  height: calc(60vh - 125px);
}
.menuText {
  font-size: clamp(0.2rem, 1.2vw + 1.2rem, 2.5rem);
  font-weight: bold;
  text-transform: none;
}
.menuItem {
  font-size: clamp(0.2rem, 1.2vw + 1.2rem, 2.5rem);
}
.remainLabel {
  font-size: clamp(0.2rem, 1.2vw + 1.2rem, 2.5rem);
  font-weight: bold;
  text-align: center;
}

.buttonStyle{
  height:calc(80vh / 5);
}
</style>
