<template>
  <v-container>
    <label for="VINLabel" class="left-aligned"><b>VIN</b></label>
    <v-text-field
      label=""
      variant="solo"
      v-model="vin"
      ref="vinTextRef"
      @keydown.enter="enterEvent"
    ></v-text-field>

    <v-card elevation="0" class="mt-2 cardStyle">
      <label
        v-if="status != ''"
        :style="{ color: color }"
        for="status"
        class="statusLabel"
        >{{ status }}
      </label>
    </v-card>
    <label class="text-aligned" for="okutulan"
      >OKUTULAN : {{ okutulan === 0 ? "" : okutulan }}</label
    >
    <v-btn
      @click="goBack"
      border
      block
      rounded
      class="mt-4 buttonStyle"
      prepend-icon="mdi-chevron-double-left"
      ><span class="menuText">Geri Dön</span></v-btn
    >
  </v-container>
</template>

<script>
import { clearText } from "@/helpers/base";
import { useIndexedDBStore } from "@/CommonVueCore/src/store/stores/indexDBStores.js";

export default {
  data() {
    return {
      vin: "",
      status: "",
      okutulan: 0,
      color: "",
    };
  },
  methods: {
    async enterEvent() {
      const vin = clearText(this.vin);
      if (vin === "") {
        this.$refs.vinTextRef.focus();
        return;
      }
      this.vin = "";
      //indexDb den OfflineStockControls.FirstOrDefault(t => t.VIN == vin); gelen veriyle
      const res = await this.getStockControl(vin);

      if (res === null || res.length === 0) {
        console.log("if girdi")
        // indexDb ye eklicez OfflineStockControls.Add(new OfflineStockControl { VIN = vin, IsTick = true });
        try {
          await useIndexedDBStore().addData({
            dbName: "Roro",
            collectionName: "OfflineStockControls",
            dataList: [{ VIN: vin, IsTick: true }],
            keyPath: "VIN",
            autoIncrement: false,
          });
        }
        catch  {
          this.status = `${vin} OKUTULAMADI.`;
          this.color = "red";
          return;
        }
        this.status = `${vin} OKUTULDU.`;
        this.color = "green";
        this.okutulan++;
        return;
      } else {
        console.log("else girdi")
        this.status = `${vin} ARAÇ ZATEN OKUTULDU.`;
        this.color = "red";
        res.IsTick = true;
        //indexDb OfflineStockControls.AddOrUpdate(result);
        try {
          await useIndexedDBStore().updateData({
          dbName: "Roro",
          collectionName: "OfflineStockControls",
          keyList: [vin],
          newData: { VIN: vin, IsTick: true },
        });
        } catch {
          this.status = `${vin} OKUTULAMADI.`;
          this.color = "red";
          return;
        }
      }

      await this.getStockControlCount();
      this.$refs.vinTextRef.focus();
    },
    async getStockControlCount() {
      // WriteCountStatus un aynısı
      //indexDb OfflineStockControls.Count();
      try {
        const allData = await useIndexedDBStore().getSelectedCollection({
          dbName: "Roro",
          collectionName: "OfflineStockControls",
        });
        this.okutulan = await allData.length;
      } catch {
        this.okutulan = 0;
      }
    },
    async getStockControl(vin){
      try {
        const res = await useIndexedDBStore().getDataWithFilter({
          dbName: "Roro",
          collectionName: "OfflineStockControls",
          filterCallback: (data) => data.VIN == vin,
        });
        console.log(res)
        return res;
      } catch {
        return null;
      }
    },
    goBack() {
      this.$router.push("/roro/offlineoperationmain");
    },
  },
  async mounted() {
    await this.getStockControlCount();
    this.$refs.vinTextRef.focus();
  },
};
</script>

<style scoped>
.left-aligned {
  text-align: left;
  display: block;
  font-size: clamp(0.2rem, 1.2vw + 1.5rem, 3rem);
  margin-bottom: 4px;
}
.statusLabel {
  font-size:clamp(0.2rem, 1.2vw + 1.5rem, 3rem);
  font-weight: bold;
  text-transform: uppercase;
  
}
.text-aligned {
  text-align: left;
  display: block;
  font-size: clamp(0.2rem, 1.2vw + 1.5rem, 3rem);
  margin-top: 2%;
  font-weight: bold;
}
.menuText {
  font-size:clamp(0.2rem, 1.2vw + 1.5rem, 3rem);
  font-weight: bold;
  text-transform: none;
}
.cardStyle{
  height:calc(60vh - 300px);
  min-height: 100px;
}

.buttonStyle{
  height: calc(60vh / 3);
}
</style>
