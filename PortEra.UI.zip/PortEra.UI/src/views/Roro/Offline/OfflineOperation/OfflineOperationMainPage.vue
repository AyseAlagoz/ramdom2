<template>
  <v-row dense>
    <v-col v-for="btn in buttons" :cols="btn.col[buttonMode-1]" >
      <v-btn
        @click="btn.click"
        border
        block
        rounded
        :class="buttonMode == 1 ? 'mt-2 custom-height' : 'mt-2 custom-height2'"
        :color="btn.color"
        :prepend-icon="btn.icon"
        ><span class="menuText">{{ btn.text }}</span></v-btn
      >

    </v-col>
  </v-row> 
</template>

<script>
import { useButtonModeStore } from "@/store/buttonMode";
export default {
  data() {
    return {
      buttons:[
        { text: "Etiketleme", click:()=>{ this.goTo("/roro/offlinelabeloperation") } ,color:"white" ,icon:"", col:[12,6]},
        { text: "Etiketleme Kalan", click:()=>{ this.goTo("/roro/offlinelabelremainlist") },color:"primary",icon:"", col:[12,6] },
        { text: "Araç Aktarma", click:()=>{ this.goTo("/roro/offlineshiftingmain") }, color:"white" ,icon:"", col:[12,6]},
        { text: "Stok Kontrol", click:()=>{ this.goTo("/roro/offlinestockcontrol") }, color:"white" ,icon:"", col:[12,6]},
        { text: "Stok Kalan", click:()=>{ this.goTo("/roro/offlinestockleft") },  color: "red-lighten-1" ,icon:"" , col:[12,12]},
        { text: "Geri Dön", click:()=>{ this.goTo("/roro/offlinemenu") }, color:"white",icon:"mdi-chevron-double-left" , col:[12,12]},   
      ],
    };
  },
  methods: {
    goTo(page) {
      this.$router.push(page);
    },
  },
  computed: {
    buttonMode() {
      return useButtonModeStore().mode;
    },
  },
};
</script>

<style scoped>
.fontBlack {
  color: black;
}
.menuText {
  font-size: clamp(0.2rem, 1.2vw + 1.2rem, 2.5rem);
  font-weight: bold;
  text-transform: none;
  white-space: wrap;
}

.custom-height {
  height:calc(60vh / 6);
}

.custom-height2 {
  height:calc(60vh / 3.8);
}

@media (max-height: 650px) {
  .custom-height {
    height: calc(60vh / 6.5);
  }
}

@media (max-height: 600px) {
  .custom-height {
    height: calc(60vh / 7.3);
  }

  .custom-height2 {
    height:calc(60vh / 4.3);
  }
}


</style>
