<template>
    <label for="VINLabel" class="left-aligned"><b>VIN</b></label>
    <v-text-field
      label=""
      variant="solo"
      v-model="vin"
      ref="vinTextRef"
      @keydown.enter="enterEvent"
    ></v-text-field>

    <v-row no-gutters >
      <v-col cols="3" >
        <label class="labelText ">Marka :</label>
      </v-col>,
      <v-col cols="8">
        <label class="labelText "> {{ res.Brand }}</label>
       
      </v-col>
      <v-col cols="3">
        <label class="labelText ">Model : </label>
      </v-col>
      <v-col cols="8">
        <label class="labelText ">{{ res.Model }}</label>
      </v-col>
      <v-col cols="3">
        <label class="labelText ">POD : </label>
      </v-col>
      <v-col cols="8">
        <label class="labelText ">{{ res.POD }}</label>
      </v-col>
      <v-col cols="3">
        <label class="labelText">Okutulan : </label>
      </v-col>
      <v-col cols="8">
        <label class="labelText">{{ res.Okutulan }} </label>
      </v-col>
      <v-col cols="3">
        <label class="labelText ">Kalan : </label>
      </v-col>
      <v-col cols="8">
        <label class="labelText ">{{ res.Kalan }}</label>
      </v-col>
      <v-col cols="3">
        <label class="labelText">Beklenen : </label>
      </v-col>
      <v-col cols="8">
        <label class="labelText">{{ res.Beklenen }}</label>
      </v-col>

      <v-col cols="3">
        <label class="labelText ">Toplam : </label>
      </v-col>
      <v-col cols="8" justify="center">
        <label class="labelText">{{ res.Toplam }}</label> 
      </v-col>
    </v-row>

    <v-card elevation="0" class="mt-2 customCard">
      <label
        v-if="status != ''"
        :style="{ color: color }"
        for="status"
        class="statusLabel"
        >{{ status }}
      </label>
    </v-card>

    <v-btn @click="enterEvent" border block  rounded class="buttonStyle"
      ><span class="menuText">Etiketle</span></v-btn
    >
    <v-btn
      @click="goTo('/roro/offlineoperationmain')"
      border
      block
   
      rounded
      class="mt-2 buttonStyle"
      prepend-icon="mdi-chevron-double-left"
      ><span class="menuText">Geri Dön</span></v-btn
    >
  
</template>

<script>
import { clearText } from "@/helpers/base";
import { useIndexedDBStore } from "@/CommonVueCore/src/store/stores/indexDBStores.js";
import MessageContent from "@/components/Base/MessageContent.vue";
export default {
  inject: ["openDialog"],
  data() {
    return {
      vin: "",
      res: {
        Brand: "",
        Model: "",
        POD: "",
        Okutulan: "",
        Kalan: "",
        Beklenen: "",
        Toplam: "",
      },
      status: "",
      color: "red",
    };
  },
  methods: {
    goTo(page) {
      this.$router.push(page);
    },
    async enterEvent() {
      const vin = clearText(this.vin);
      if (vin == "") return;
      let res = null;
      try {
        res = await useIndexedDBStore().getDataWithFilter({
          dbName: "Roro",
          collectionName: "OfflineLabelDefination",
          filterCallback: (data) => data.VIN == vin,
        });
      } catch {
        this.openDialog(MessageContent, "Bir hata oluştu.");
        this.status = "VIN BULUNAMADI";
        this.color = "red";
        return;
      }

      if (res.length == 0 ) {
        this.status = "VIN BULUNAMADI";
        this.color = "red";
        return;
      }

      this.res.Brand = res[0].Brand;
      this.res.Model = res[0].Model;
      this.res.POD = res[0].POD;

      if (res[0].IsTick) {
        this.status = "Bu vin daha önce etiketlendi.";
        this.color = "gold";
      } else {
        res[0].IsTick = true;
        this.status = `${res[0].VIN} Etiketlendi.`;
        this.color = "green";
        try {
          await useIndexedDBStore().updateData({
            dbName: "Roro",
            collectionName: "OfflineLabelDefination",
            keyList: [vin],
            newData: { IsTick: true },
          });
        } catch {
          this.openDialog(MessageContent, "Etiketlerken hata oluştu.");
        }
      }

      const handledPOD = await this.writeLabelStatus(res[0]);

      this.res = handledPOD;
      this.vin = "";
      this.$refs.vinTextRef.focus();
    },
    async writeLabelStatus(searchResult) {
      const labelDefinitions = await useIndexedDBStore().getSelectedCollection({
        dbName: "Roro",
        collectionName: "OfflineLabelDefination",
      });

      const readedVins = labelDefinitions.filter(
        (data) => data.IsTick && data.POD == searchResult.POD
      );
      searchResult.Okutulan = readedVins.length;

      const remainVins = labelDefinitions.filter(
        (data) => !data.IsTick && data.POD == searchResult.POD
      );
      searchResult.Kalan = remainVins.length;

      searchResult.Beklenen = this.groupAndSumByField(
        labelDefinitions,
        "InboundCount"
      );
      searchResult.Toplam = this.groupAndSumByField(
        labelDefinitions,
        "TotalCount"
      ); // indexDb de şu şarttan gelen veri OfflineLabelDefinations.GroupBy(t => t.TotalCount).Select(t => t.FirstOrDefault()).Sum(t => t.TotalCount);
      return searchResult;
    },
    groupAndSumByField(data, field) {
      return Array.from(
        data
          .reduce((map, item) => {
            if (!map.has(item[field])) {
              map.set(item[field], item);
            }
            return map;
          }, new Map())
          .values()
      ).reduce((sum, item) => sum + item[field], 0);
    },
  },
  mounted() {
    this.$refs.vinTextRef.focus();
  },
};
</script>

<style scoped>
.menuText {
  font-size: clamp(0.2rem, 1.2vw + 1.2rem, 2.5rem);
  font-weight: bold;
  text-transform: none;
}
.labelText {
  font-size: clamp(0.1rem, 1.2vw + 1rem, 2rem);
  font-weight: bold;
  text-transform: none;
  white-space: nowrap;
  text-align: end;
  display: block;
}

.left-aligned {
  text-align: left;
  display: block;
  font-size: clamp(0.1rem, 1.2vw + 1rem, 2rem);
  margin-bottom: 3px;
}
.statusLabel {
  font-size: clamp(0.1rem, 1.2vw + 1rem, 2rem);
  font-weight: bold;
  text-transform: uppercase;
}

.customCard{
  height:calc(60vh / 10.3);
}

.buttonStyle{
  height: calc(60vh / 5);
}

@media (max-height: 800px) {
  .buttonStyle{
    height: calc(60vh / 6);
  }
}

@media (max-height: 770px) {
  .buttonStyle{
    height: calc(60vh / 12);
  }
}
@media (max-height: 1680px) {
  .buttonStyle{
    height: calc(60vh / 10);
  }
}
</style>
