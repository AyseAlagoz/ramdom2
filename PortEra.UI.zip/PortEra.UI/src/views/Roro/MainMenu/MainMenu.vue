<template>
  <v-img rounded max-height="100" :src="imageSrc" class="shrink"></v-img>

  <v-row dense class="mt-2">
    <v-col
      :cols="buttonMode == 1 ? 12 : 6"
      v-for="(btn, index) in buttons"
      :key="index"
    >
      <v-btn
        @click="btn.click()"
        rounded
        border
        block
        :class="buttonMode == 1 ? 'custom-height' : 'custom-height2'"
      >
        <span class="menuText">{{ btn.text }}</span>
      </v-btn>
    </v-col>
    <v-col cols="12">
      <v-btn
        @click="goBack"
        block
        border
        rounded
        :class="buttonMode == 1 ? 'custom-height' : 'custom-height2'"
      >
        <span class="menuText">Ana menüye Dön</span>
      </v-btn>
    </v-col>
  </v-row>
</template>

<script>
import { useButtonModeStore } from "@/store/buttonMode";
import MessageContent from "@/components/Base/MessageContent.vue";
export default {
  name: "MainMenu",
  inject:["openDialog","closeDialog"],
  data() {
    return {
      imageSrc: process.env.BASE_URL + "img/gemport.jpg",
      buttons: [
        { text: "KAPI İŞLEMLERİ", click:()=>{this.goTo("/roro/gatemain",true) }},
        { text: "HASAR GİRİŞİ", click:()=>{this.goTo("/roro/damage" ,true) }},
        { text: "HOLD İŞLEMLERİ", click:()=>{this.goTo("/roro/holdmain", true)} },
        { text: "ÇEVRİMDIŞI İŞLEMLER" , click:()=>{this.goTo("/roro/offlinemenu")} },
      ],
    };
  },
  computed: {
    buttonMode() {
      return useButtonModeStore().mode;
    },
  },
  methods: {
    goTo(page, isConnectionRequired = false) {
      if(isConnectionRequired && !navigator.onLine){
        this.openDialog(MessageContent, "Bu sayfalar için internet bağlantısı gerekmektedir..");
        return;
      }
      this.$router.push(page);
    },
    goBack() {
      this.goTo("/",false)
    },
    
  },
  mounted(){
  
  }
};
</script>

<style scoped>
.menuText {
  font-size: clamp(0.2rem, 1.2vw + 1.2rem, 2.5rem);
  line-height: 1.2;
  padding: 0 4px;
  white-space: wrap;
}

.custom-height {
  height: calc(60vh / 5);
}

@media (max-height: 640px) {
  .custom-height {
    height: calc(60vh / 6);
  }
}

.custom-height2 {
  height: calc(60vh / 3);
}

@media (max-height: 600px) {
  .custom-height2 {
    height: calc(60vh / 3.5);
  }
}
</style>
