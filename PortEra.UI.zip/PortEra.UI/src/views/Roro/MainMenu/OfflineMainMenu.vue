<template>
  <v-row>
    <v-col
      v-for="(btn, index) in buttons"
      :key="index"
      :cols="btn.cols[buttonMode - 1]"
    >
      <v-btn
        @click="btn.func"
        :color="btn.color"
        rounded
        border
        block
        :class="buttonMode == 1 ? 'custom-height' : 'custom-height2'"
        ><span class="menuText">{{ btn.text }}</span></v-btn
      >
    </v-col>
  </v-row>

  <v-btn
    @click="goTo('/roro')"
    prepend-icon="mdi-chevron-double-left"
    block
    border
    rounded
    :class="buttonMode == 1 ? 'custom-height mt-3' : 'custom-height2 mt-3'"
    ><span class="menuText">Geri Dön</span></v-btn
  >
</template>

<script>
import ConfirmContent from "@/components/Base/ConfirmContent.vue";
import MessageContent from "@/components/Base/MessageContent.vue";
import { useIndexedDBStore } from "@/CommonVueCore/src/store/stores/indexDBStores.js";
import { UnitLabelType } from "@/constants/enums/UnitLabelType";
import { checkInternetConnection } from "@/helpers/base";
import { useButtonModeStore } from "@/store/buttonMode";
import { postData } from "@/utils/httpServices.js"

export default {
  inject: ["toggleLoadingOverlay", "openDialog"],
  data() {
    return {
      buttons: [
        {
          text: "Çevrimdışı Hazırlık",
          func: () => {
            this.goTo("/roro/offlinedatapreparemain");
          },
          cols: [12, 6],
          color: "white",
        },
        {
          text: "Çevrimdışı İşlemler",
          func: () => {
            this.goTo("/roro/offlineoperationmain");
          },
          cols: [12, 6],
          color: "white",
        },
        {
          text: "Navis'e Aktar",
          func: () => {
            this.sendToNavis();
          },
          cols: [12, 6],
          color: "white",
        },
        {
          text: "Çevrimdışı Verileri Temizle",
          func: () => {
            this.clearDatas();
          },
          cols: [12, 6],
          color: "red",
        },
      ],
    };
  },
  components: {
    ConfirmContent,
    MessageContent,
  },
  methods: {
    goTo(page) {
      this.$router.push(page);
    },
    async sendToNavis() {
      this.toggleLoadingOverlay();

      const res = await checkInternetConnection();

      if (!res) {
        this.toggleLoadingOverlay();
        this.openDialog(MessageContent, "İnternet bağlantısı yok.");
        return;
      }

      const labelRes = await this.getPrepareidLabelDatas();
      const stockRes = await this.getPrepareidStockDatas();
      const shiftingRes = await this.getPrepareidShiftingDatas();

      const message = `Etiketleme : Başarılı = ${labelRes.Success.length}, Başarısız = ${labelRes.Fail.length}
      \nStok Kontrol : Başarılı = ${stockRes.Success.length}, Başarısız = ${stockRes.Fail.length}
      \nShifting : Başarılı = ${shiftingRes.Success.length}, Başarısız = ${shiftingRes.Fail.length}`;

      console.log(labelRes, stockRes, shiftingRes);
      this.toggleLoadingOverlay();
      this.openDialog(MessageContent, message);
    },

    async getPrepareidLabelDatas() {
      // BURADA FOR DAKİ POST TEK SEFERDE YAPILAMAZ MI LİST YOLLANMIS SONUCTA
      const serviceResult = { Success: [], Fail: [] };
      let offlineLabelDatas = [];

      try {
        offlineLabelDatas = await useIndexedDBStore().getDataWithFilter({
          dbName: "Roro",
          collectionName: "OfflineLabelDefination",
          filterCallback: (data) => data.IsTick,
        });
      } catch {
        return serviceResult;
      }

      if (offlineLabelDatas.length === 0) {
        return serviceResult;
      }

      const copyDatas = [...offlineLabelDatas];

      for (const shift of copyDatas) {
        const newRequest = {
          UnitId: shift.VIN,
          Type: UnitLabelType.YARD,
        };

        try {
          // const res = {
          //   Success: [
          //     {
          //       UnitId: newRequest.UnitId,
          //     },
          //   ],
          //   Fail: [{ UnitId: "3" }, { UnitId: "4" }],
          // }; // dummy response

          const res = await postData("UnitLabel/SetUnitLabel", {
            UnitLabels: [newRequest],
          });
          if (res.data) {
            // Handle successful units
            for (const successItem of res.data.Success) {
              await useIndexedDBStore().deleteData({
                dbName: "Roro",
                collectionName: "OfflineLabelDefination",
                keyList: [newRequest.UnitId],
              });
              serviceResult.Success.push(successItem.UnitId);
            }
            for (const errorItem of res.data.Fail) {
              serviceResult.Fail.push(errorItem);
            }
          }
        } catch (error) {
          serviceResult.Fail.push(newRequest);
        }
      }

      return serviceResult;
    },
    async getPrepareidStockDatas() {
      const serviceResult = { Success: [], Fail: [] };
      let offlineStockDatas = [];

      try {
        offlineStockDatas = await useIndexedDBStore().getDataWithFilter({
          dbName: "Roro",
          collectionName: "OfflineStockControls",
          filterCallback: (data) => data.IsTick,
        });
      } catch {
        console.log("offlineStockDatas hata");
        return serviceResult;
      }
      if (offlineStockDatas.length === 0 || offlineStockDatas === null) {
        return serviceResult;
      }

      const copyDatas = [...offlineStockDatas];

      for (const shift of copyDatas) {
        const newRequest = {
          UnitId: shift.VIN,
          Type: UnitLabelType.shift,
        };

        try {
          // const res = {
          //   Success: [
          //     {
          //       UnitId: newRequest.UnitId,
          //     },
          //   ],
          //   Fail: [{ UnitId: "3" }, { UnitId: "4" }],
          // }; // dummy response

          const res = await postData("UnitLabel/SetUnitLabel", {
            UnitLabels: [newRequest],
          });
          if (res.data) {
            // Handle successful units
            for (const successItem of res.data.Success) {
              await useIndexedDBStore().deleteData({
                dbName: "Roro",
                collectionName: "OfflineStockControls",
                keyList: [newRequest.UnitId],
              });
              serviceResult.Success.push(successItem.UnitId);
            }
            for (const errorItem of res.data.Fail) {
              serviceResult.Fail.push(errorItem);
            }
          }
        } catch (error) {
          serviceResult.Fail.push(newRequest);
        }
      }

      return serviceResult;
    },
    async getPrepareidShiftingDatas() {
      const serviceResult = { Success: [], Fail: [] };
      let offlineShiftingDatas = [];
      try {
        offlineShiftingDatas = await useIndexedDBStore().getDataWithFilter({
          dbName: "Roro",
          collectionName: "OfflineShiftings",
          filterCallback: (data) => data.IsTick,
        });
      } catch {
        return serviceResult;
      }

      if (offlineShiftingDatas.length === 0 || offlineShiftingDatas === null) {
        return serviceResult;
      }

      const copyDatas = [...offlineShiftingDatas];

      for (const shift of copyDatas) {
        const newRequest = {
          UnitId: shift.VIN,
          ToPosition: shift.ToPosition,
          RoroShiftingType: shift.RoroShiftingType,
          VesselVisitId: shift.VesselVisitId,
        };

        try {
          // const res = {
          //   Success: [
          //     {
          //       UnitId: newRequest.UnitId,
          //     },
          //   ],
          //   Fail: [{ UnitId: "3" }, { UnitId: "4" }],
          // }; // dummy response

          const res = await postData("Shifting/SetShifting", {
            Shiftings: [newRequest],
          });
          if (res.data) {
            // Handle successful units
            for (const successItem of res.data.Success) {
              await useIndexedDBStore().deleteData({
                dbName: "Roro",
                collectionName: "OfflineShiftings",
                keyList: [shift.id],
              });
              serviceResult.Success.push(successItem.UnitId);
            }
            for (const errorItem of res.data.Fail) {
              serviceResult.Fail.push(errorItem);
            }
          }
        } catch (error) {
          serviceResult.Fail.push(newRequest);
        }
      }

      return serviceResult;
    },
    clearDatas() {
      this.openDialog(
        ConfirmContent,
        "Çevrimdışı verileri temizlemek istediğinize emin misiniz?",
        async () => {
          try {
            const res = await useIndexedDBStore().deleteSelectedDb("Roro");
            this.openDialog(MessageContent, "Çevrimdışı veriler temizlendi.");
          } catch (e) {
            this.openDialog(MessageContent, "Silinecek veri bulunamadı.");
          }
        }
      );
    },
  },
  computed: {
    buttonMode() {
      return useButtonModeStore().mode;
    },
  },
};
</script>

<style scoped>
.menuText {
  font-size: clamp(1rem, 1.2vw + 1.5rem, 3.5rem);
  font-weight: bold;
  text-transform: none;
  white-space: wrap;
}


.custom-height {
  height: calc(40vh / 3);
}

@media (max-height: 700px) {
  .custom-height {
    height: calc(40vh / 3.3);
  }
}

@media (max-height: 600px) {
  .custom-height {
    height: calc(40vh / 3.7);
  }
}

.custom-height2 {
  height: calc(60vh / 2.5);
}

@media (max-height: 700px) {
  .custom-height2 {
    height: calc(60vh / 2.5);
  }
}

@media (max-height: 650px) {
  .custom-height2 {
    height: calc(60vh / 2.8);
  }
}
</style>
