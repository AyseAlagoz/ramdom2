// Styles
import '@mdi/font/css/materialdesignicons.css'
import 'vuetify/styles'
import { VNumberInput } from 'vuetify/labs/VNumberInput'
import { VDateInput } from 'vuetify/labs/VDateInput'
// Vuetify
import { createVuetify } from 'vuetify'

export default createVuetify({
  theme: {
    defaultTheme: 'light',
    themes: {
      light: {
        admin_primary: '#2a4365',
        home_secondary: '#A0A940',
      },
      
    },
  },
  components: {
    VNumberInput,VDateInput
  },
  }
)
