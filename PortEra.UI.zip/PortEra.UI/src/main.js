import { createApp } from 'vue';
import App from './App.vue';
import './registerServiceWorker';
import router from './router';
import vuetify from './plugins/vuetify';
import { createBootstrap } from 'bootstrap-vue-next';
import { createPinia } from 'pinia';
import piniaPluginPersistedstate from 'pinia-plugin-persistedstate';

import './App.css';
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue-next/dist/bootstrap-vue-next.css'


const pinia = createPinia();
pinia.use(piniaPluginPersistedstate);

createApp(App)
  .use(vuetify)
  .use(router)
  .use(pinia) 
  .use(createBootstrap())
  .mount('#app');
