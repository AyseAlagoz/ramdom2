<template>
  <div class="text-center mb-3">
    <label class="text-h1 mt-4 fontRed">Hata!</label>
    <p class="fontCustom">{{ message }}</p>
    <v-row class="mt-3 MB-3" dense no-gutters justify="center">
      <!-- <v-btn
        
        border
     
        
        class="mt-3 customButton"
        @click="confirmCallBack"
        ><span class="menuText">Plaka Değiştir</span></v-btn
      >
      <v-btn
        
        border
        
        rounded
        class="mt-3 customButton"
        @click="cancelCallBack"
        ><span class="menuText">Plaka Değiştir</span></v-btn
      >      -->
      <v-btn
        block
        border
        variant="text"
        rounded
        size="70"
        class="mt-3 customButton"
        @click="closeDialog"
        ><span class="closeButton">Ok</span></v-btn
      >
    </v-row>
  </div>
</template>

<script>
export default {
  props: {
    confirmCallBack: {
      type: Function,
      default: () => {},
    },
    cancelCallBack: {
      type: Function,
      default: () => {},
    },
    closeDialog: {
      type: Function,
      default: () => {},
    },
    message: {
      type: String,
      default: "İşlem gerçekleştirilemedi!",
    },
  },

  methods: {},
};
</script>

<style scoped>
.fontCustom {
  font-size: 2rem;
}
.closeButton {
  font-size: 1.5rem;
}
</style>
