<template>
    <v-dialog v-model="overlay" persistent no-click-animation width="75%">
        
        <v-card color="white">
            <v-img rounded height="130"  :src="imageSrc" ></v-img>
            <v-card-text class="text-center">
                <div class="blue-text" style="font-size: 24px;">
                    LÜTFEN BEKLEYİNİZ
                </div>
                <div class="red-text" style="font-size: 20px;">
                    İŞLEM YAPILIYOR
                </div>
                <div class="text-center mt-3 mb-1">
                    <v-progress-circular :size="50" color="primary" indeterminate></v-progress-circular>
                </div>
            </v-card-text>
        </v-card>
    </v-dialog>
</template>

<script>
export default {
    data: () => ({
        overlay: false,
        imageSrc:  process.env.BASE_URL + 'img/gemport.jpg'
    }),
    methods: {
        async toggle() {
            this.overlay = !this.overlay;
        }
    },
};
</script>

<style scoped>
.text-center {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 100%;
}

.blue-text {
    color: blue;
}

.red-text {
    color: red;
}
</style>
