<template>
  <v-btn
    @click="changeMode(isActive == 1 ? 2 : 1)"
    :class="isActive == 1 ? 'active fixed-btn ma-2' : 'fixed-btn ma-2'"
    :icon="isActive == 1 ? 'mdi-menu' : 'mdi-dots-grid'"
  >
  </v-btn>
</template>

<script>
import { useButtonModeStore } from "@/store/buttonMode";
export default {
  computed: {
    isActive() {
      return useButtonModeStore().mode;
    },
  },
  methods: {
    changeMode(mode) {
      useButtonModeStore().setButtonMode(mode);
    },
  },
};
</script>

<style scoped>
.active {
  background-color: rgb(99, 37, 242);
  color: white;
}
.fixed-btn {
  position: fixed;
  z-index: 1000; /* Diğer elementlerin üzerinde görünsün */
  transform: none; /* Önceki translateY'yi kaldırıyoruz */
  bottom: 5px;
  right: 5px;
  border-radius: 50%; /* Daire şeklinde olması için */
  height: 30px; /* Yükseklik 60px azaltıyoruz */
  width: 30px; /* Genişlik 60px azaltıyoruz */
}
</style>
