<template>
  <v-footer app color="white">
    <v-container>
      <v-row no gutters justify="start">
        <v-col class="text-left" cols="9" sm="10">
          <span v-if="footerVisibility" class="fontBlack">Version</span>
        </v-col>
      </v-row>
    </v-container>
  </v-footer>
</template>

<script>
import ButtonMode from './ButtonMode.vue';
import { buttonModeVisibleRoutes } from '@/constants/root/buttonModeSpecial';
import { footerRoutes } from '@/constants/root/routeSpecial';

export default {
  components: {
    ButtonMode
  },
  data(){
    return{
    }
  },
  computed:{
    footerVisibility() {
      return footerRoutes.includes(this.$route.path);
    },
  },
};
</script>
