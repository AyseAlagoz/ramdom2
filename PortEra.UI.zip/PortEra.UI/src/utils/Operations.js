import { Buffer } from 'buffer'

export default{
    tokenString:"",
    user: {
        Email: null,
        FullName: null,
        UserId: null,
        UserName: null,
        Roles: [],
        Apps: [],
    },
    jwtDecoder(tokenParam){
        const token = tokenParam
        var base64Payload = token.split('.')[1];
        var payload = Buffer.from(base64Payload, 'base64');
        return JSON.parse(payload.toString())
    },
    getUser() {
        if(this.user.FullName === null){
            try
            {
                const token = localStorage.getItem('token') 
                const user = this.jwtDecoder(token)
                this.userFiller(user)
            }
            catch{
                this.logOut()
            }
        }
        return this.user
    },
    isLogin(){
        try{
            const token = localStorage.getItem('token')
            const info = this.jwtDecoder(token)
            const currentTimeInSeconds = Math.floor(Date.now() / 1000);

            if(info.exp && currentTimeInSeconds < info.exp){
                return true
            }
            return false
        }
        catch{
            return false
        }
    },
    getToken() {
        if(this.tokenString === '' || this.tokenString === null){
            try
            {
                const token = localStorage.getItem('token') 
                this.tokenString = token;      
            }
            catch{
                this.tokenString = ''
            }
        }
        return this.tokenString
    },
    userFiller(userInfo){
        this.user = {
            Email: userInfo.email,
            FullName: userInfo.name,
            UserId: userInfo.userId,
            UserName: userInfo.preferred_username,
            Roles: userInfo.roles,
            Apps: userInfo.apps,
        }    
    },
    logIn(tokenString){
        this.tokenString = tokenString;
        const user = this.jwtDecoder(tokenString)
        this.userFiller(user) 
        localStorage.setItem('token',tokenString)
    },

    cleanUser(){
        this.user= {
            Email: null,
            FullName: null,
            UserId: null,
            UserName: null,
            Roles: [],
            Apps: [],
        } 
    },
    
    logOut() {
        localStorage.removeItem('token')
        this.cleanUser();
        this.tokenString = ''
    },

    getHeaders(){
        const token = this.getToken()
        const headers = [
            {key: 'Content-Type', value: 'application/json'},
            {key: 'Authorization', value: `Bearer ${token}`},
            {key: 'Accept', value: 'application/json'},
        ]

        return headers
    }
}

