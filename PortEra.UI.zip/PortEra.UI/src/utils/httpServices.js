import Operations from "./Operations";
import { post, api } from "@/CommonVueCore/src/services/httpService/JsonServiceClient/basicServiceClient.js";

export async function postData(url, data, headers = null) {
    if (headers === null) {
        headers = Operations.getHeaders();
    }
    function callBack(client) {
        client.bearerToken = Operations.getToken();
        return client;      
      }

    return await post(url, data,headers,callBack);
}

export async function apiMethod(url, data, headers = null) {
    if (headers === null) {
        headers = Operations.getHeaders();
    }
    function callBack(client) {
        client.bearerToken = Operations.getToken();
        return client;      
      }
    return await api(url, data,headers,callBack);
}

export async function logIn(url,data){
    return await post(url, data);
}