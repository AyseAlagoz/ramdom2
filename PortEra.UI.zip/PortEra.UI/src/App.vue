<template>
  <v-app>
    <v-container>
      <HeadeR v-show="headerVisibility" />
      <router-view ></router-view>

    </v-container>
    <button-mode v-show="buttonModeVisibility" />
  </v-app>

  <LoadingOverlay ref="loadingOverlayRef" />
  <DialogComponent ref="dialogRef" />
  <SnackbarS ref="SnackBarS" />
</template>

<script>
import LoadingOverlay from "./components/Base/LoadingOverlay.vue";
import FooteR from "./components/Base/FooteR.vue";
import DialogComponent from "./components/Base/DialogComponent.vue";
import HeadeR from "./components/Base/HeadeR.vue";
// import MessageContent from './components/Base/MessageContent.vue';
import { buttonModeVisibleRoutes } from "@/constants/root/buttonModeSpecial";
import { headerVisibleRoutes } from "./constants/root/headerRoutesSpecial";
import ButtonMode from "./components/Base/ButtonMode.vue";
import SnackbarS from './components/Base/SnackbarS.vue';
export default {
  components: {
    LoadingOverlay,
    FooteR,
    DialogComponent,
    HeadeR,
    ButtonMode,
    SnackbarS
  },
  //mounted() {
  // localStorage.setItem('myData', JSON.stringify({name: 'ChatGPT', type: 'AI'}));
  // const x =window.navigator.storage.estimate().then(estimate => {
  //   console.log(estimate)
  // })
  // console.log(x)

  // const y = window.navigator.platform
  // const z = window.navigator.userAgent
  // console.log(z)
  // console.log(y)
  // this.openDialog(MessageContent, `${z}\r\n platform: ${y}`);
  //},
  computed: {
    buttonModeVisibility() {
      return buttonModeVisibleRoutes.includes(this.$route.path);
    },
    headerVisibility() {
      return !headerVisibleRoutes.includes(this.$route.path);
    },
  },

  methods: {
    toggleLoadingOverlay() {
      this.$refs.loadingOverlayRef.toggle();
    },
    openDialog(
      component,
      message = "",
      confirmCallBack = () => { },
      cancelCallBack = () => { }
    ) {
      this.$refs.dialogRef.openDialog(
        component,
        message,
        confirmCallBack,
        cancelCallBack
      );
    },
    closeDialog() {
      this.$refs.dialogRef.closeDialog();
    },
  },
  provide() {
    return {
      toggleLoadingOverlay: this.toggleLoadingOverlay,
      openDialog: this.openDialog,
      closeDialog: this.closeDialog,
    };
  },
  mounted() {
    this.$root.SnackBarS = this.$refs.SnackBarS;
  }
};
</script>
