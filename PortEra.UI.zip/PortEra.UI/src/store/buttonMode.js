import { defineStore } from 'pinia';

export const useButtonModeStore = defineStore('buttonMode', {
    state: () => ({
        mode: 1 
    }),
    actions: {
        setButtonMode(mode) {
            this.mode = parseInt(mode);
        },
    },
    getters:{

    },
    persist: true,
});