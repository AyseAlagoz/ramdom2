import { createRouter, createWebHistory } from 'vue-router'
import LoginPage from '../views/Main/LoginPage.vue'
import MainPage from '../views/Main/MainPage.vue'

//Roro
import RoroMainMenu from '../views/Roro/MainMenu/MainMenu.vue'
import OfflineMainMenu from '../views/Roro/MainMenu/OfflineMainMenu.vue'
import DamagePage from '../views/Roro/Online/DamageOperation/DamagePage.vue'
import GateMain from '../views/Roro/Online/GateOperation/GateMain.vue'
import GateOperation from '@/views/Roro/Online/GateOperation/GateOperation.vue'
import PreGate from '@/views/Roro/Online/GateOperation/PreGate.vue'
import HoldMainPage from '@/views/Roro/Online/HoldOperation/HoldMainPage.vue'
import SetUnitHoldPortBased from '@/views/Roro/Online/HoldOperation/SetUnitHoldPortBased.vue'
import SetUnitHoldUnitBased from '@/views/Roro/Online/HoldOperation/SetUnitHoldUnitBased.vue'
import OfflineDataPrepareMainPage from '@/views/Roro/Offline/OfflineDataPrepare/OfflineDataPrepareMainPage.vue'
import OfflineLabelDefinationDetail from '@/views/Roro/Offline/OfflineDataPrepare/OfflineLabelDefinationDetail.vue'
import OfflineLabelDefinationVesselVisit from '@/views/Roro/Offline/OfflineDataPrepare/OfflineLabelDefinationVesselVisit.vue'
import OfflineOperationMainPage from '@/views/Roro/Offline/OfflineOperation/OfflineOperationMainPage.vue'
import OfflineLabelOperation from '@/views/Roro/Offline/OfflineOperation/OfflineLabelOperation.vue'
import OfflineLabelRemainList from '@/views/Roro/Offline/OfflineOperation/OfflineLabelRemainList.vue'
import OfflineStockControl from '@/views/Roro/Offline/OfflineOperation/OfflineStockControl.vue'
import OfflineStockLeft from '@/views/Roro/Offline/OfflineOperation/OfflineStockLeft.vue'
import OfflineShiftingMain from '@/views/Roro/Offline/YardUpdate/OfflineShiftingMainPage.vue'
import YardUpdateNoBillable from '@/views/Roro/Offline/YardUpdate/YardUpdateNoBillable.vue'
import OfflineVesselShifting from '@/views/Roro/Offline/YardUpdate/OfflineVesselShifting.vue'

//CFS
import CfsMain from "../views/Cfs/CfsMain.vue"

//Damage
import DamageMain from "../views/Damage/DamageMain.vue"

//Operations for authentication
import Operations from '@/utils/Operations'

const routes = [
  {
    path: '/',
    name: 'home',
    component: MainPage
  },
  {
    path: '/login',
    name: 'login',
    component: LoginPage
  },
  {
    path: '/cfs',
    name: 'cfsmain',
    component: CfsMain
  }, {
    path: '/damage',
    name: 'damagemain',
    component: DamageMain
  },
  {
    path: '/roro',
    name: 'roromain',
    component: RoroMainMenu
  },
  {
    path: '/roro/offlinemenu',
    name: 'offlinemenu',
    component: OfflineMainMenu
  },
  {
    path: '/roro/damage',
    name: 'damage',
    component: DamagePage
  },
  {
    path: '/roro/gatemain',
    name: 'gatemain',
    component: GateMain
  },
  {
    path: '/roro/gateoperation',
    name: 'gateoperation',
    component: GateOperation
  },
  {
    path: '/roro/pregate',
    name: 'pregate',
    component: PreGate
  }, 
  {
    path: '/roro/holdmain',
    name: 'holdmainpage',
    component: HoldMainPage
  },
  {
    path: '/roro/setunitholdportbased',
    name: 'setunitholdportbased',
    component: SetUnitHoldPortBased
  },
  {
    path: '/roro/setunitholdunitbased',
    name: 'setunitholdunitbased',
    component: SetUnitHoldUnitBased
  },
  {
    path: '/roro/offlinedatapreparemain',
    name: 'offlinedatapreparemainpage',
    component: OfflineDataPrepareMainPage
  },
  {
    path: '/roro/offlinelabeldefinationdetail',
    name: 'offlinelabeldefinationdetail',
    component: OfflineLabelDefinationDetail
  },
  {
    path: '/roro/offlinelabeldefinationvesselvisit',
    name: 'offlinelabeldefinationvesselvisit',
    component: OfflineLabelDefinationVesselVisit
  },
  {
    path: '/roro/offlineoperationmain',
    name: 'offlineoperationmain',
    component: OfflineOperationMainPage
  },
  {
    path: '/roro/offlinelabeloperation',
    name: 'offlinelabeloperation',
    component: OfflineLabelOperation
  },
  {
    path: '/roro/offlinelabelremainlist',
    name: 'offlinelabelremainlist',
    component: OfflineLabelRemainList
  },
  {
    path: '/roro/offlinestockcontrol',
    name: 'offlinestockcontrol',
    component: OfflineStockControl
  },
  {
    path: '/roro/offlinestockleft',
    name: 'offlinestockleft',
    component: OfflineStockLeft
  },
  {
    path: '/roro/offlineshiftingmain',
    name: 'offlineshiftingmain',
    component: OfflineShiftingMain
  },
  {
    path: '/roro/yardupdatenobillable',
    name: 'yardupdatenobillable',
    component: YardUpdateNoBillable
  },
  {
    path: '/roro/offlinevesselshifting',
    name: 'offlinevesselshifting',
    component: OfflineVesselShifting
  },
  {
    path: "/:pathMatch(.*)*",
    redirect: "/"
  }
  // {
  //   path: '/about',
  //   name: 'about',
  //   // route level code-splitting
  //   // this generates a separate chunk (about.[hash].js) for this route
  //   // which is lazy-loaded when the route is visited.
  //   component: () => import(/* webpackChunkName: "about" */ '../views/Roro/AboutView.vue')
  // }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

router.beforeEach((to, from, next) => {
  const isAuthenticated = Operations.isLogin();
  const roles = Operations.getUser().Roles || [];
  
  if(!isAuthenticated){
    if(to.name !== 'login'){
      next({name: 'login'});
    }
    else{
      next();
    }
  }
  else{
    if(to.name === 'login'){
      next({name: 'home'});
    }
    else if(to.name === 'home'){
      next();
    }
    else{
      if(roles.includes(to.name) || roles.includes('Admin')){
        next();
      }
      else{
        next({name: 'home'});
      }
    }
  }
})
export default router