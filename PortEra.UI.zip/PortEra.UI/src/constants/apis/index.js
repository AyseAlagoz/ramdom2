// export const BASE_URL = "https://roroapi.tr20.yph.inc/api/";
// export const AUTH_URL = "https://localhost:60079/";
// export const CFS_URL = "https://localhost:60009/";

export const BASE_URL = "https://roroapi.tr20.yph.inc/api/";
export const AUTH_URL = "https://porteraaccount.api.trgem.ary.inc/";
export const CFS_URL = "https://porteracfsprocess.api.trgem.ary.inc/";