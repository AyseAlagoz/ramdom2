export const UnitLabelType = {
    NONE : 'NONE',
    YARD : 'YARD',
    STOCK : 'STOCK',
};