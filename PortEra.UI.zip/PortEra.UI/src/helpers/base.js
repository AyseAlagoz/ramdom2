export function clearText(text) {
    if (!text) return "";

    return text
        .replace(/[\r\n]+/g, "") // Satır başı ve sonu karakterlerini kaldır
        .replace(/\s+/g, "") // Tüm boşlukları kaldır
        .toUpperCase(); // Metni büyük harfe dönüştür
}
export const checkInternetConnection = async () => {
    try {
      const response = await fetch("https://www.google.com", { mode: "no-cors" });
      return true;
    } catch (error) {
      return false;
    }
  };