import { register } from 'register-service-worker'

// Güncelleme onayı veren fonksiyon
function promptUserToUpdate(registration) {
  const userConfirmed = confirm('Yeni bir sürüm mevcut. Güncellemek ister misin? Reddetmeniz durumunda 15 dk sonra tekrar sorulacaktır yada sayfayı yenileyebilirsiniz.');
  if (userConfirmed) {
    if (registration.waiting) {
      registration.waiting.postMessage({ type: 'SKIP_WAITING' });
    }
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      window.location.reload();
    });
  } else {
    
    setTimeout(() => {
      if (registration.waiting) {
        promptUserToUpdate(registration);
      }
    }, 15 * 60 * 1000); 
  }
}

if (process.env.NODE_ENV === 'production') {
  register(`${process.env.BASE_URL}service-worker.js`, {
    registered(registration) {
      
      // Eğer sayfa yüklendiğinde yeni sürüm waiting durumundaysa, hemen sor
      if (registration.waiting) {
        promptUserToUpdate(registration);
      }
      
      // Uygulama açıkken de periyodik kontrol sağlamak için (her 60 saniyede)
      setInterval(() => {
        registration.update();
      }, 60000);
    },
    updatefound(registration) {
      const newWorker = registration.installing;
      newWorker.addEventListener('statechange', () => {
        if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
          // Yeni worker waiting durumuna geçtiğinde güncelleme onayını sor
          promptUserToUpdate(registration);
        }
      });
    },
    updated() {
      // updated callback’inde de istenirse promptUserToUpdate(registration) çağrılabiliriz. Ihtiyac durumuna göre bakacagız
    },
    offline() {
      console.log('İnternet bağlantısı yok, offline modda çalışılıyor.');
    },
    error(error) {
      console.error('Service worker kaydı sırasında hata:', error);
    }
  });
}
