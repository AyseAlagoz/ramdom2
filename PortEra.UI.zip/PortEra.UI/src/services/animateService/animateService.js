import { useGlobals } from "@/main";
import { useGlobalVariableStore } from "@/store/stores/globalVariableStores.js";

export class AnimateService {
  animateElement({ targetId = null, element = null, animateType }) {
    // Get animation class from 'data' attribute
    var animationTarget = null;

    if (targetId !== null) animationTarget = useGlobals().$jquery(targetId);

    if (element !== null) animationTarget = useGlobals().$jquery(element);

    animationTarget.addClass("animated " + animateType);

    animationTarget.on("animationend", function () {
      animationTarget.removeClass(animateType);
    });
  }


  //todo: customAnimateService e taşınacak
  transferInfoCompPositionUpdate(targetId) {
    useGlobals()
      .$jquery("." + targetId)
      .closest("div.div-position")
      .css("opacity", "1");

    this.animateElement({ targetId: "." + targetId, animateType: "bounceIn" });

    // var positions = useGlobalVariableStore().getTransferPosition;
    
    // if (positions.fromPosition && positions.toPosition) {
    //   var disabledButtons = useGlobals().$jquery(
    //     ".operation-button-panel button:disabled"
    //   );
    //   disabledButtons.removeAttr("disabled");
    // }
  }

  // //todo: customAnimateService e taşınacak
  // transferInfoCompJobDoneButtonUpdate() {

  //   // if(state === "active"){

  //   // }
  //   // else {
      
  //   // }

  //   var positions = useGlobalVariableStore().getTransferPosition;
  //   var operationType = useGlobalVariableStore().getOperationType;

  //   // if(operationType === )
    
  //   if (positions.fromPosition && positions.toPosition) {
  //     var disabledButtons = useGlobals().$jquery(
  //       ".operation-button-panel button:disabled"
  //     );
  //     disabledButtons.removeAttr("disabled");
  //   }
  // }

}
