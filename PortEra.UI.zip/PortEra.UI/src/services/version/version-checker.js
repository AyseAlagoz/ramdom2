export async function checkVersion() {
  const response = await fetch("/globalSettings/version.json", { cache: "no-store" });
  const serverVersion = (await response.json()).version;

  const localVersion = localStorage.getItem("appVersion");

  if (!localVersion || serverVersion !== localVersion) {
    localStorage.setItem("appVersion", serverVersion);
    return true; // Yeni sürüm mevcut
  }
  return false; // Sürüm güncel
}
