import SecureLS from "secure-ls"

export var ls = new SecureLS({ isCompression: false });






