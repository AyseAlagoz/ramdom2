
function loading(_root, _isShow) {
    _root.loading.toggle({
        isActive: _isShow
    })
}

export default loading