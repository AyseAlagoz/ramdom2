import { useLangStore } from '@/CommonVueCore/src/store/stores/langStores';
import localization from "@/localization/localization";

function ChangeLang(_lang) {
    const langStore = useLangStore();
    langStore.setLangInfo(_lang);
}

function CheckLang() {
    var langStore = useLangStore();
    var selectedLang = langStore.$state.lang; //langStore.getLangInfo

    if (selectedLang === null)
        langStore.setLangInfo(localization.global.locale)

}

function GetSelectedLang() {
    var langStore = useLangStore();
    var selectedLang = langStore.$state.lang;
    return selectedLang;
}

function ResetLang() {
    const langStore = useLangStore();
    langStore.setResetLang();
}

export default {
    ChangeLang,
    CheckLang,
    GetSelectedLang,
    ResetLang
};
