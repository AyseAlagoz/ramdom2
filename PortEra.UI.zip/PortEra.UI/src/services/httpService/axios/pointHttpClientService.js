// import axios from "axios";

// export default class PointHttpClientService {
//   constructor({
//     // root = null,
//     baseUrl = null
//   }) {
//     // this.root = root;
//     this.baseUrl = baseUrl;
//   }

//   async get({route, params = null, headers = null, successCallback = null, errorCallback = null, requestInterceptorFn = null, cancelToken = null} = {}) {
    
//     var request = axios.create({
//       baseURL: this.baseUrl,
//       params: params,
//       headers: {
//         Accept: "application/json",
//         ...headers
//       },
//       timeout: window.appsettings.AppGlobal.ApiTimeOut,
//     });
    
//     if (requestInterceptorFn != null) {
//       // request.interceptors.request.use(requestInterceptorFn, (error) => { console.log(error) });
//       request.interceptors.request.use(async (config) => {
//         config.cancelToken = cancelToken
//         await requestInterceptorFn();

//         return config;
//       }, (error) => { 
//         console.log(error);
//         return Promise.reject(error);
//        });
//     }
    
//     var response = null;

//     try {
//       response = await request.get(route);

//       if (successCallback) {
//         successCallback(response);
//       }

//     } catch (error) {
      
//       if (errorCallback) {
//         errorCallback(error);
//         response = error;
//         response.ResponseMessage = error?.response?.data?.ResponseStatus?.Message
//       }
//     }

//     return response;
//   }


//   async post({route, data = null, params = null, headers = null, successCallback = null, errorCallback = null, requestInterceptorFn = null, cancelToken = null } = {}) {
    
    
//     var request = axios.create({
//       baseURL: this.baseUrl,
//       params: params || {},
//       headers: headers || {},
//       timeout: window.appsettings.AppGlobal.ApiTimeOut
//     });
    
    
//     if (requestInterceptorFn != null) {
//       // request.interceptors.request.use(requestInterceptorFn, (error) => { console.log(error) });
//       request.interceptors.request.use(async (config) => {
//         config.cancelToken = cancelToken;

//         await requestInterceptorFn();

//         return config;
//       }, (error) => { 
//         console.log(error);
//         return Promise.reject(error);
//        });
//     }

//     try {
//       var response = await request.post(route, data);
        
//         if (successCallback) {
//           successCallback(response);
//         }
//     } catch (error) {

//       if (errorCallback) {
//         errorCallback(error);
//         response = error;
//         response.ResponseMessage = error?.response?.data?.ResponseStatus?.Message
//       }    
//     }

//     return response;
//   }

//   async put({route, data = null, params = null, headers = null, successCallback = null, errorCallback = null, requestInterceptorFn = null, cancelToken = null } = {}) {
    
//     var request = axios.create({
//       baseURL: this.baseUrl,
//       params: params || {},
//       headers: headers || {},
//       timeout: window.appsettings.AppGlobal.ApiTimeOut
//     });
    
    
//     if (requestInterceptorFn != null) {
//       request.interceptors.request.use(async (config) => {
//         config.cancelToken = cancelToken;

//         await requestInterceptorFn();

//         return config;
//       }, (error) => { 
//         console.log(error);
//         return Promise.reject(error);
//        });
//     }

//     try {
//       var response = await request.put(route, data);
        
//         if (successCallback) {
//           successCallback(response);
//         }
//     } catch (error) {

//       if (errorCallback) {
//         errorCallback(error);
//         response = error;
//         response.ResponseMessage = error?.response?.data?.ResponseStatus?.Message
//       }    
//     }

//     return response;
//   }


//   async delete({route, params = null, headers = null, successCallback = null, errorCallback = null, requestInterceptorFn = null, cancelToken = null } = {}){
//     var request = axios.create({
//       baseURL: this.baseUrl,
//       params: params || {},
//       headers: headers || {},
//       timeout: window.appsettings.AppGlobal.ApiTimeOut
//     });
    
    
//     if (requestInterceptorFn != null) {
//       request.interceptors.request.use(async (config) => {
//         config.cancelToken = cancelToken;

//         await requestInterceptorFn();

//         return config;
//       }, (error) => { 
//         console.log(error);
//         return Promise.reject(error);
//        });
//     }

//     try {
//       var response = await request.delete(route);
        
//         if (successCallback) {
//           successCallback(response);
//         }
//     } catch (error) {

//       if (errorCallback) {
//         errorCallback(error);
//         response = error;
//         response.ResponseMessage = error?.response?.data?.ResponseStatus?.Message
//       }    
//     }

//     return response;
//   }

// }