// import axios from 'axios'
// export  {
//   getData,
//   postData,
// }

// async function getData(url, paramName, paramValue) {
//   var params = {
//     [paramName]: paramValue
//   }
//   return await axios.get(url, params)
// }

// async function postData(url, data) {
//   try {
//     return await axios.post(url, data);
//   }
//   catch (error) {
//     return new Error(error)
//   }
// }

