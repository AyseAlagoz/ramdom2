export class FormValidationService{
  
    getInputRefs(refs) {
        const form = refs.myForm;
        const inputRefs = Object.keys(refs)
          .filter(ref => form.contains(refs[ref]))
          .filter(t => t !== "myForm");
  
        console.log('Input Refs:', inputRefs);
        
        return inputRefs;
      }
}