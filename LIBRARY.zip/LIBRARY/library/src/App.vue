<template>
  <DesignView/>

  <SnackbarPage ref="SnackbarPage" />
</template>

<script>
import DesignView from './common-views/DesignView.vue';
import SnackbarPage from './common-components/SnackbarPage.vue';


export default {
    name: "App",
    data: () => ({
    //
    }),
    components: { 
     DesignView,
     SnackbarPage
    },
    mounted() {
    // this.tokenLifeControl();
    this.$root.SnackbarPage = this.$refs.SnackbarPage;
  },
  //   methods: {
  //     tokenLifeControl() {
  //       setTimeout(
  //         () => (
  //           localStorage.removeItem("user"),
  //           this.$router.push("/login")
  //         ),
  //         3 * 60 * 1000
  //       );
  //     }
  //   }
}
</script>
