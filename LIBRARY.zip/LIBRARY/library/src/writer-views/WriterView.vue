<template>
  <WriterPage/>
</template>

<script>
import WriterPage from "@/writer-components/WriterPage.vue";

export default {
  name: "writerView",
  components: { WriterPage },
};
</script>
