<template>
  <div id="list">
    <p v-if="books.length == 0">Kitap Listesi Boş</p>

    <v-table v-else>
      <thead>
        <br />
        <td>
          <v-btn depressed color="red lighten-5" @click="deleteBooks"
            >Kitapları sil</v-btn
          >
          <v-btn depressed color="#E3F2FD" @click="openUpdateCard"
            >Kitapları güncelle</v-btn
          >
        </td>

        <tr>
          <th style="text-align: left">
            <input
              type="checkbox"
              v-model="multipleSelect"
              @change="selectAllBook"
            />
          </th>
          <th class="text-left">
            <h3>Kitap Id</h3>
          </th>
          <th class="text-left">
            <h3>Kitap Adı</h3>
          </th>
          <th class="text-left">
            <h3>Kitabın ait olduğu yazar Id</h3>
          </th>
          <th class="text-left">
            <h3>Kitabın ait olduğu yazar Adı</h3>
          </th>
          <th></th>
        </tr>
      </thead>

      <tbody>
        <tr v-for="book in books" :key="book.bookId">
          <td>
            <input
              type="checkbox"
              v-model="singleSelect"
              @change="selectSingleBook"
              :value="book"
            />
          </td>
          <td>
            {{ book.bookId }}
          </td>
          <td v-if="updateId === book.bookId">
            <input v-model="book.bookName" type="text" class="textbox" />
          </td>
          <td v-else>
            {{ book.bookName }}
          </td>
          <td v-if="updateId === book.bookId">
            <input v-model="book.writerId" type="text" class="textbox" />
          </td>
          <td v-else>
            {{ book.writerId }}
          </td>
          <td>
            {{ book.writerName }}
          </td>

          <td v-if="updateId !== book.bookId">
            <v-btn depressed color="success" @click="handleUpdate(book)"
              >Güncelle</v-btn
            >
            <v-btn depressed color="error" @click="handleDelete(book)"
              >Sil</v-btn
            >
          </td>
          <td v-else>
            <v-btn depressed color="success" @click="handleSave(book)"
              >Kaydet</v-btn
            >
            <v-btn depressed color="error" @click="updateId = null"
              >İptal</v-btn
            >
          </td>
        </tr>
      </tbody>
    </v-table>
  </div>

  <v-dialog v-model="showCard">
  <v-card max-width="400" class="mx-auto">
    <v-container>
      <v-row dense>
        <v-col cols="12">
          <v-card color="#385F73" theme="dark">
            <v-card-title class="text-h6">
              Lütfen güncelenecek yazar id giriniz.
            </v-card-title>

            <v-card-subtitle>
              <input v-model="bookWriterId" type="text" class="textbox2" />
            </v-card-subtitle>

            <v-card-actions>
              <v-btn
                class="ml-2"
                variant="outlined"
                size="small"
                @click="updateBooks()"
              >
                Güncelle
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-col>
      </v-row>
    </v-container>
  </v-card>
</v-dialog>
</template>

<script>
import axios from "axios";

export default {
  // bookpage gelen book bilgilerini karşılamak için
  name: "book-list",
  props: {
    books: Array,
  },

  data() {
    return {
      updateId: null,
      oldWriterId: null,
      oldBookName: null,
      selectedId: null,
      multipleSelect: false,
      singleSelect: [],
      showCard: false,
      writerId: null,
      bookWriterId: null,
    };
  },

  methods: {
    //eğer interceptor kullanılmasaydı her işlem için if sorgusu yazmak gerekecekti!
    handleDelete(book) {
      // if(this.roleControl() == "Admin"){
        this.$emit("delete:book", book);
      // }
      // else {
      //   this.$root.SnackbarPage.show({
      //           text: "Yetkiniz bulunmamaktadır!",
      //         });
      // } 
    },
    handleUpdate(book) {
      // if(this.roleControl() == "Admin"){
        this.oldWriterId = book.writerId;
        this.oldBookName = book.bookName;
        this.updateId = book.bookId;
      // }
      // else {
      //   this.$root.SnackbarPage.show({
      //           text: "Yetkiniz bulunmamaktadır!",
      //         });
      // }
      
    },

    // roleControl() {
    //   let role = localStorage.getItem("roles")
    //   return role;
    // },

    handleSave(book) {
      const newWriterId = book.writerId;
      const newBookName = book.bookName;
      if(this.oldWriterId !== newWriterId || this.oldBookName !== newBookName) {
        this.$emit("update:book", book);
        this.updateId = null;
      }
      else {
        this.$root.SnackbarPage.show({ text: "Herhangi bir güncelleme yapılmamıştır!" });
      }

    },

    selectAllBook() {
      if (this.multipleSelect == true) {
        this.singleSelect = [];
        for (var i = 0; i < this.books.length; i++) {
          this.singleSelect.push(this.books[i]);
        }
      } else {
        this.singleSelect = [];
      }
    },

    selectSingleBook() {
      if (this.books.length == this.singleSelect.length) {
        this.multipleSelect = true;
      } else {
        this.multipleSelect = false;
      }
    },

    async deleteBooks() {
        if (this.singleSelect.length !== 0) {
        for (var i = 0; i < this.singleSelect.length; i++) {
          await axios
            .delete(
              `https://localhost:7283/api/Book/` + this.singleSelect[i].bookId
            )
            .then((response) => {
              console.log(response);
              this.$root.SnackbarPage.show({
                text: "Kitaplar başarıyla silindi!",
              });
            });
        }
      }
    },

    openUpdateCard() {
        this.showCard = true;
    },

    async updateBooks() {
      if (this.singleSelect.length !== 0) {
        for (var i = 0; i < this.singleSelect.length; i++) {
          console.log(this.singleSelect[i].bookName);
          try {
            let result = await axios.put(
              `https://localhost:7283/api/Book/` + this.singleSelect[i].bookId,
              {
                writerId: this.bookWriterId,
                bookName: this.singleSelect[i].bookName,
              }
            );

            console.log(result.data);
            this.$root.SnackbarPage.show({
              text: "Kitaplar başarıyla güncellendi!",
            });
          } catch (e) {
            console.log(e);
          }
        }
      }
    },
  },
};
</script>

<style scoped>
#list {
  margin: 100px;
}
.textbox {
  background-color: lightgray;
}
.textbox2 {
  background-color: lightcyan;
  color: black;
}
.mx-auto {
  text-align: center;
}
</style>
