<template>
  <v-sheet class="bg-deep-purple pa-12" rounded v-if="showBookAdd">
    <v-card class="mx-auto px-6 py-8" max-width="344">
      <v-form v-model="form" @submit.prevent="onSubmit">
        <v-text-field
          v-model="BookName"
          :readonly="loading"
          :rules="[required]"
          class="mb-2"
          clearable
          label="Kitap Adı"
        ></v-text-field>

        <v-text-field
          v-model="WriterId"
          :readonly="loading"
          :rules="[required]"
          clearable
          label="Yazar id"
          placeholder="Kitabın ait olduğu yazar id giriniz"
        ></v-text-field>

        <br />

        <v-btn
          :disabled="!form"
          :loading="loading"
          block
          color="success"
          size="large"
          type="submit"
          variant="elevated"
          @click="addBook"
        >
          Kaydet
        </v-btn>
      </v-form>
    </v-card>
  </v-sheet>
</template>

<script>
import axios from "axios";

export default {
  data: () => ({
    form: false,
    BookName: "",
    WriterId: "",
    loading: false,
    showBookAdd: false,
    errorMessage: "",
  }),
  mounted() {
    this.showAdd();
  },

  methods: {
    onSubmit() {
      if (!this.form) return;

      this.loading = true;

      setTimeout(() => (this.loading = false), 2000);
    },
    required(v) {
      return !!v || "Bu alan boş geçilemez!";
    },

    async addBook() {
      await axios
        .post("https://localhost:7283/api/Book", {
          BookName: this.BookName,
          WriterId: this.WriterId,
        })
        .then((response) => {
          console.log(response);
          this.$root.SnackbarPage.show({ text: "Kitap başarıyla eklendi!" });
        })
        .catch((error) => {
          this.errorMessage = error.response.data.errors;
          const errorsArray = Object.values(this.errorMessage);
          const errorString = errorsArray.join(" - ");
          this.$root.SnackbarPage.show({ text: errorString });
        });
    },

    showAdd() {
      let role = localStorage.getItem("roles");
      console.log(role);
      if (role == "Admin") {
        this.showBookAdd = true;
      }
    },
  },
};
</script>
