<template>
  <BookAddVue />

  <!-- oluşturduğumuz booku bookliste göndermek için -->
  <BookListVue
    @delete:book="deleteBook"
    @update:book="updateBook"
    :books="books"
  />
</template>

<script>
import axios from "axios";
import BookListVue from "./BookList.vue";
import BookAddVue from "./BookAdd.vue";

export default {
  name: "App",

  data() {
    return {
      url: "https://localhost:7283/api/Book",
      books: [],
      showWriterList: false,
    };
  },

  mounted() {
    this.getBooks();
  },

  methods: {
    async getBooks() {
      await axios
        .get(this.url)
        .then((response) => (this.books = response.data));
    },

    async deleteBook(book) {
      await axios
        .delete(`https://localhost:7283/api/Book/${book.bookId}`)
        .then((response) => {
          console.log(response);
          this.$root.SnackbarPage.show({ text: "Kitap başarıyla silindi!" });
        });
    },

    async updateBook(book) {
      try {
        const result = await axios.put(
          "https://localhost:7283/api/Book/" + book.bookId,
          {
            bookName: book.bookName,
            writerId: book.writerId,
          }
        );
        console.log(result.data);
        this.$root.SnackbarPage.show({ text: "Kitap başarıyla güncellendi!" });
      } catch (e) {
        console.log(e);
      }
    },
  },

  components: {
    BookListVue,
    BookAddVue,
  },
};
</script>
