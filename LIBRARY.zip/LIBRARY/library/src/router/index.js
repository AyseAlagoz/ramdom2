import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../common-views/HomeView.vue'
import AboutView from '../common-views/AboutView.vue'
import BookView from '../book-views/BookView.vue'
import WriterView from '../writer-views/WriterView.vue'
import LoginView from '../common-views/LoginView.vue'

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  {
    path: '/about',
    name: 'about',
    component: AboutView
  },
  {
    path: '/book',
    name: 'book',
    component: BookView
  },
  {
    path: '/writer',
    name: 'writer',
    component: WriterView
  },
  {
    path: '/login',
    name: 'login',
    component: LoginView
  },
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
