<template>
  <BookPageVue />
</template>

<script>
import BookPageVue from "@/book-components/BookPage.vue";

export default {
  name: "BookView",
  components: { BookPageVue },
};
</script>
