<template>
    <HomePage />
  </template>
  
  <script>
  import HomePage from "@/common-components/HomePage.vue";
  
  export default {
    components: { HomePage },
  };
  </script>