<template>
    <LoginPage/>
</template>


<script>
import LoginPage from '@/common-components/LoginPage.vue';

export default {
    components: { LoginPage }
}

</script>