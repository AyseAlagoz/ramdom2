<template>
  <DesignPage />
</template>

<script>
import DesignPage from "@/common-components/DesignPage.vue";

export default {
  components: { DesignPage },
};
</script>
