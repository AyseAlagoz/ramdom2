<template>
  <AboutPage />
</template>

<script>
import AboutPage from "@/common-components/AboutPage.vue";

export default {
  components: { AboutPage },
};
</script>
