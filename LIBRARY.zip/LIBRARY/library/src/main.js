import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import vuetify from './plugins/vuetify'
import { loadFonts } from './plugins/webfontloader'
import axios from 'axios'

loadFonts()

// Add a request interceptor
axios.interceptors.request.use(function (config) {
  // Do something before request is sent
  const token = localStorage.getItem('user');

  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, function (error) {
  // Do something with request error
  return Promise.reject(error);
});

// Add a response interceptor
axios.interceptors.response.use(function (response) {
  return response;
}, function (error) {
  console.log(error.message)
  switch(error.message){
    case 'Request failed with status code 401':
      alert("Lütfen giriş yapınız")
      window.location.href = "/login";
      break;

    case 'Request failed with status code 403':
        alert("Bu işlemi yapmak için yetkiniz bulunmamaktadır.")
  }
  return Promise.reject(error);
});

createApp(App)
  .use(router)
  .use(vuetify)
  .mount('#app')
