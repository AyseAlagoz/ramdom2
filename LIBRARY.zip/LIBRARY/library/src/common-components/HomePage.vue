<template>
    <h1>Anasayfa</h1>
</template>

<script>

</script>

<style scoped>
</style>