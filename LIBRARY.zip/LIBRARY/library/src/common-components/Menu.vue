<template>
  <v-navigation-drawer v-model="drawer" width="325">
    <v-list :lines="false" density="compact" nav>
      <v-list-group v-for="(item, i) in items" :key="i" :value="item">
        <template v-slot:activator="{ props }">
          <v-list-item
            v-bind="props"
            :prepend-icon="item.icon"
            :title="item.text"
            active-color="green-lighten-2"
            rounded="xl"
          ></v-list-item>
        </template>

        <v-list-item-title
          v-for="itemdetail in item.subItem"
          :key="itemdetail.id"
          :value="itemdetail"
        >
          <template v-if="itemdetail.childItem">
            <v-list-group>
              <template v-slot:activator="{ props }">
                <v-list-item
                  v-bind="props"
                  :prepend-icon="itemdetail.icon"
                  :to="itemdetail.link"
                  :title="itemdetail.text"
                  active-color="green-lighten-2"
                  rounded="xl"
                ></v-list-item>
              </template>
              <v-list-item
                v-for="childItem in itemdetail.childItem"
                :key="childItem.id"
                :to="childItem.link"
                :title="childItem.text"
                active-color="green-lighten-2"
                rounded="xl"
              >
              </v-list-item>
            </v-list-group>
          </template>
          <template v-else>
            <v-list-item
              :prepend-icon="itemdetail.icon"
              :to="itemdetail.link"
              :title="itemdetail.text"
              active-color="green-lighten-2"
              rounded="xl"
            >
            </v-list-item>
          </template>
        </v-list-item-title>
      </v-list-group>
    </v-list>
  </v-navigation-drawer>
</template>

<script>
export default {
  data: () => ({
    drawer: true,
    items: [
      {
        text: "Anasayfa",
        icon: "mdi-home-assistant",
        subItem: [
          {
            text: "Anasayfa",
            icon: "mdi-home-export-outline",
            link: {
              name: "home",
            },
          },
          {
            text: "Hakkımızda",
            icon: "mdi-information-variant",
            link: {
              name: "about",
            },
          },
        ],
      },
      {
        text: "Kitap ve Yazarlar",
        icon: "mdi-book-open-page-variant",
        subItem: [
          {
            text: "Kitaplar",
            icon: "mdi-library",
            link: {
              name: "book",
            },
          },
          {
            text: "Yazarlar",
            icon: "mdi-typewriter",
            link: {
              name: "writer",
            },
          },
        ],
      },
    ],
  }),
};
</script>
