<template>
  <div class="text-center">
    <v-snackbar
      v-model="snackbar"
      :timeout="timeout"
      color="lime lighten-5"
      location="center"
      :vertical="vertical"
    >
      {{ text }}

      <template v-slot:actions>
        <v-btn color="blue" variant="text" @click="snackbar = false">
          Kapat
        </v-btn>
      </template>
    </v-snackbar>
  </div>
</template>

<script>
export default {
  data: () => ({
    snackbar: false,
    text: "",
    timeout: 2000,
    vertical: true,
  }),

  methods: {
    show(data) {
      this.text = data.text || 'missing "text".';
      this.snackbar = true;
      this.timeout = data.timeout || 2000;
      setTimeout(this.reloadPage, 2000);
    },
    reloadPage() {
      window.location.reload();
    },
  },
};
</script>

<style></style>
