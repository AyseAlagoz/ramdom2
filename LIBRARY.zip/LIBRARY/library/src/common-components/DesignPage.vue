<template>
  <v-layout>
    <v-app-bar color="#F5F5F5" prominent class="appBar">
      <v-app-bar-nav-icon
        variant="text"
        @click.stop="drawer = !drawer"
      ></v-app-bar-nav-icon>

      <v-toolbar-title class="Cursive">KÜTÜPHANE</v-toolbar-title>

      <v-spacer></v-spacer>

      <v-btn
      v-if="showLoginButton"
        variant="text"
        icon="mdi-account"
        v-on:mouseover="showTooltip = true"
        v-on:mouseout="showTooltip = false"
        class="icon"
        @click="loginPage"
      ></v-btn>

      <span v-if="showTooltip" class="tooltip">Giriş</span>

      <v-btn
      v-if="showLogoutButton"
        variant="text"
        icon="mdi-logout"
        v-on:mouseover="showTooltip = true"
        v-on:mouseout="showTooltip = false"
        class="icon"
        @click="logOut"
      ></v-btn>
      <span v-if="showTooltip" class="tooltip"> Çıkış </span>

      <v-btn variant="text" icon="mdi-magnify"></v-btn>
    </v-app-bar>

    <Menu v-if="drawer"></Menu>

    <v-main>
        <KeepAlive>
          <RouterView></RouterView>
        </KeepAlive> 
    </v-main>
  </v-layout>
</template>

<script>
import Menu from './Menu.vue';

export default {
  components: {
    Menu
  },
  data: () => ({
    drawer: false,
    group: null,
    showTooltip: false,
    showLoginButton: true,
    showLogoutButton: false,
  }),

  watch: {
    group() {
      this.drawer = false;
    },
  },

  mounted() {
    this.showInOut()
  },

  methods: {
    loginPage() {
      this.$router.push({ path: "/login" });
    },

    logOut() {
      localStorage.removeItem("user");
      window.location.href = "/login";
      
    },
    showInOut() {
      let tokenControl = localStorage.getItem("user")
      if(tokenControl) {
        this.showLoginButton = false
        this.showLogoutButton = true
      }
      else {
        this.showLoginButton = true
      }
    },
  },
};
</script>

<style scoped>
.Cursive {
  font-family: "Great Vibes", cursive;
  font-style: italic;
}
.appBar {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1;
}
.tooltip {
  display: none;
}

.icon:hover + .tooltip {
  display: inline-block;
}

.item h3 {
  background: #f4f4f4;
  padding: 20px;
  border-radius: 10px;
  margin: 10px auto;
  max-width: 280px;
  cursor: pointer;
  color: #444;
}
.item h3:hover {
  background: #ddd;
}
.item a {
  text-decoration: none;
}
</style>
