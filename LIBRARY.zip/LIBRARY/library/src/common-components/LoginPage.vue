<template>
   <v-app class="my-background">
    <v-card class="px-6 py-12" max-width="344">
      <v-form v-model="form" @submit.prevent="onSubmit">
        <v-text-field
          v-model="login.Username"
          :readonly="loading"
          :rules="[required]"
          class="mb-2"
          clearable
          label="Kullanıcı Adı"
        ></v-text-field>

        <v-text-field
          v-model="login.Password"
          :readonly="loading"
          :rules="[required]"
          clearable
          label="Şifre"
          :append-icon="showPassword ? 'mdi-eye' : 'mdi-eye-off'"
          :type="showPassword ? 'text' : 'password'"
          name="input-10-1"
          @click:append="showPassword = !showPassword"
        ></v-text-field>

        <br />

        <v-btn
          :disabled="!form"
          :loading="loading"
          block
          color="primary"
          size="large"
          type="submit"
          variant="elevated"
          @click="loginUser"
        >
          Giriş Yap
        </v-btn>
      </v-form>
    </v-card>
    </v-app>
</template>

<script>
import axios from "axios";

export default {
  data: () => ({
    form: false,
    showPassword: false,
    login: {
      Username: "",
      Password: "",
    },
    loading: false,
  }),

  methods: {
    onSubmit() {
      if (!this.form) return;

      this.loading = true;

      setTimeout(() => (this.loading = false), 2000);
    },
    required(v) {
      return !!v || "Bu alan boş geçilemez!";
    },

    async loginUser() {
      try {
        let response = await axios.post("https://localhost:7283/api/Login", {
          Username: this.login.Username,
          Password: this.login.Password,
        });
        let tokens = response.data.token;
        let role = response.data.user.role;
        localStorage.setItem("roles", role);
        console.log(role);
        localStorage.setItem("user", tokens);
        console.log(tokens);

        window.location.href = "/";

      } catch (err) {
        console.log(err.response);
      }
    },
  },
};
</script>

<style scoped>
.my-background {
  background-image: url('C:\Users\ayse.alagoz\NOTLAR\Vuetify3 NOTLAR\31_olena-lishchyshyna-istock-1344733780.jpg');
  background-repeat: no-repeat;
  background-size: cover;
}
.px-6  {
  margin-top: 100px;
  margin-left: 580px;
  background-color:aliceblue;
}
</style>
