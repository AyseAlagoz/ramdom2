<template>
  <div id="writerList" style="padding: 16px; margin: 16px">
    <v-row>
      <v-col v-for="writer in writers" :key="writer.writerId" cols="12" md="3">
        <v-card class="mx-auto" max-width="344">
          <v-img
            src="https://parlakjurnal.com/wp-content/uploads/2017/03/35097.jpg"
            height="200px"
            cover
          ></v-img>

          <v-card-title>
            {{ writer.writerName }}
          </v-card-title>

          <v-card-subtitle> Yazar id: {{ writer.writerId }} </v-card-subtitle>

          <v-card-actions>
            <v-btn color="orange-lighten-2" variant="text">
              Yazarın Eserleri
            </v-btn>

            <v-spacer></v-spacer>
            <v-btn
              :icon="show ? 'mdi-chevron-up' : 'mdi-chevron-down'"
              @click="getWritersBook(writer.writerId)"
            ></v-btn>
          </v-card-actions>

          <v-expand-transition
            v-for="books in writersBook"
            :key="books.writerId"
          >
            <div v-show="show">
              <v-divider></v-divider>

              <v-card-text v-if="writer.writerId == books.writerId">
                {{ books.bookName }}
              </v-card-text>
            </div>
          </v-expand-transition>
        </v-card>
      </v-col>
    </v-row>
  </div>
</template>

<script>
import axios from "axios";

export default {
  // appvuedan gelen writer bilgilerini karşılamak için
  name: "writer-list",
  props: {
    writers: Array,
  },
  components: {},
  data() {
    return {
      writersBook: [],
      show: false,
    };
  },

  methods: {
    async getWritersBook(writerId) {
      this.show = !this.show;
      await axios
        .get(`https://localhost:7283/api/Book/` + writerId)
        // .then((response) => console.log(response.data));
        .then((response) => (this.writersBook = response.data));
    },
  },
};
</script>

<style scoped></style>
