<template>
  <WriterListVue :writers="writers" />
</template>

<script>
import axios from "axios";
import WriterListVue from "./WriterList.vue";

export default {
  name: "writerApp",
  props: {},

  data() {
    return {
      writers: [],
    };
  },

  mounted() {
    this.getWriters();
  },

  methods: {
    async getWriters() {
      await axios
        .get("https://localhost:7283/api/Writer")
        .then((response) => (this.writers = response.data));
    },
  },
  components: {
    WriterListVue,
  },
};
</script>
