import { Routes, Route, useNavigate } from 'react-router-dom';
import Home from '..//components/Home';
import About from '..//components/About';
import Setting from '..//components/Setting';
import Layout from './Layout';
import List from '../components/List';
import Sub2 from '..//components/Sub2';
import LoginPage from '../components/LoginPage';
import { useEffect, useState } from 'react';


function AppRoutes() {
    const navigate = useNavigate();
    const [isAuthenticated, setIsAuthenticated] = useState(null);

    useEffect(() => {
        const token = localStorage.getItem('accessToken');
        if (!token || token === "") {
            setIsAuthenticated(false);
            navigate('/loginPage');
        } else {
            setIsAuthenticated(true);
        }
    }, [navigate]);

    if (isAuthenticated === null) {
        return null;
    }
    return (
        <Routes>
            <Route element={isAuthenticated ? <Layout /> : null}>
                <Route path="/" element={<Home />} />
                <Route path="/about" element={<About />} />
                <Route path="/setting" element={<Setting />} />
                <Route path="/list" element={<List />} />
                <Route path="/sub2" element={<Sub2 />} />
                <Route path="/loginPage" element={<LoginPage />} />
            </Route>
        </Routes>
    );
}

export default AppRoutes;
