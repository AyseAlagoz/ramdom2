import React from 'react';
import AppBar from './AppBar';
import NavBar from './NavBar';
import { Box } from '@mui/material';
import { Outlet } from 'react-router-dom';

function Layout({ children }) {
    return (
        <>
            <AppBar />
            <Box height={30} />
            <Box sx={{ display: 'flex' }}>
                <NavBar />
                <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
                    <Outlet />
                </Box>
            </Box>
        </>
    );
}

export default Layout;