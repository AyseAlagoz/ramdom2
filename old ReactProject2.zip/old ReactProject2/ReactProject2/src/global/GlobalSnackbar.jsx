import * as React from 'react';
import Snackbar from '@mui/material/Snackbar';
import Alert from '@mui/material/Alert';
import { useSnackbar } from '../globalState/snackbarContext';

const GlobalSnackbar = () => {
    const { snackbar, closeSnackbar } = useSnackbar();

    return (
        <div>
            <Snackbar open={snackbar.isOpen} autoHideDuration={6000} onClose={closeSnackbar}>
                <Alert
                    onClose={closeSnackbar}
                    severity={snackbar.severity}
                    variant="filled"
                    sx={{ width: '100%' }}
                >
                    {snackbar.message}
                </Alert>
            </Snackbar>
        </div>
    );
}

export default GlobalSnackbar;
