import * as yup from "yup";

export const loginPageSchema = yup.object({
    userName: yup.string().email("Lütfen geçerli bir mail giriniz").required("Email adresi zorunlu"),
    password: yup.string().required("Parola zorunlu")
})