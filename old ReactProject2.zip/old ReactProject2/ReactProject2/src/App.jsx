import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import NavBar from './global/NavBar'
import { Routes, Route, BrowserRouter } from 'react-router-dom'
import Home from './components/Home'
import About from './components/About'
import Setting from './components/Setting'
import AppRoutes from './global/AppRoutes'
import GlobalSnackbar from './global/GlobalSnackbar'
import { SnackbarProvider } from './globalState/snackbarContext'

function App() {

  return (
    <>
      <BrowserRouter>
        <SnackbarProvider>
          <GlobalSnackbar />
          <AppRoutes />
        </SnackbarProvider>
      </BrowserRouter>

    </>
  )
}

export default App
