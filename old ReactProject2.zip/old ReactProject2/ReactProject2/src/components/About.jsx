import React from 'react'
import Typography from '@mui/material/Typography';
import { Box } from '@mui/material';
import NavBar from '../global/NavBar';
import AppBar from '../global/AppBar';

function About() {
    return (
        <>
            <Box component="main" sx={{ flexGrow: 1, p: 3, display: 'flex' }}>
                <h1>About</h1>
            </Box>
        </>


    )
}

export default About