import React from 'react'
import { useFormik } from 'formik';
import { loginPageSchema } from '../schemas/LoginPageSchema'
import '../css/LoginPage.css';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardActions from '@mui/material/CardActions';
import CardMedia from '@mui/material/CardMedia';
import pic from '../images/yildirim.jpg';

function LoginPage() {
    const submit = (values, action) => {
        localStorage.setItem('accessToken', true);
        window.location.href = '/';
        // setTimeout(() => {
        //     action.resetForm();
        //     navigate('/');
        // }, 2000);
    }
    const { handleSubmit, values, errors, handleChange, setFieldTouched, touched } = useFormik({
        initialValues: {
            userName: '',
            password: ''
        },
        onSubmit: submit,
        validationSchema: loginPageSchema,
    })

    return (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
            <Card sx={{
                width: { xs: 'auto', sm: 'auto', md: 'auto' },
                display: 'flex',
                boxShadow: 10
            }}>
                <CardMedia
                    component="img"
                    sx={{ width: '400px', display: { xs: 'none', sm: 'none', md: 'flex' }, margin: 'auto', padding: '30px' }}
                    image={pic}
                    alt=""
                />
                <CardContent>
                    <form onSubmit={handleSubmit}>
                        <div className='inputDiv'>
                            <label style={{ fontWeight: 'bold' }}>User Name: </label>
                            <input
                                id="userName"
                                name="userName"
                                placeholder='Please enter user name'
                                type="text"
                                onChange={handleChange}
                                onBlur={() => setFieldTouched('userName')}
                                value={values.userName}
                            />
                            {errors.userName && touched.userName && <p className='input-error'>{errors.userName}</p>}
                        </div>

                        <div className='inputDiv'>
                            <label style={{ fontWeight: 'bold' }}>Password: </label>
                            <input
                                id="password"
                                name="password"
                                placeholder='Please enter your password'
                                type="password"
                                onChange={handleChange}
                                onBlur={() => setFieldTouched('password')}
                                value={values.password}
                            />
                            {errors.password && touched.password && <p className='input-error'>{errors.password}</p>}


                            <CardActions>

                                <button type='submit' className='saveButton'>Login</button>

                            </CardActions>
                        </div>
                    </form>
                </CardContent>
            </Card>
        </div>


    )
}

export default LoginPage