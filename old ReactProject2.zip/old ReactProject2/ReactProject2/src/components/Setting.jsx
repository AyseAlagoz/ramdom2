import React from 'react'
import { Box } from '@mui/material';

function Setting() {
    return (
        <>
            <Box component="main" sx={{ flexGrow: 1, p: 3, display: 'flex' }}>
                <h1>Setting</h1>
            </Box>
        </>


    )
}

export default Setting