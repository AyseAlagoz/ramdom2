import React from 'react'
import { get } from '../globalJS/crud'
import Box from '@mui/material/Box';
import { DataGrid, GridActionsCellItem, GridToolbar, GridToolbarContainer, GridToolbarExport } from '@mui/x-data-grid';
import { useState, useEffect } from 'react';
import RefreshIcon from '@mui/icons-material/Refresh';
import { QRCodeSVG } from 'qrcode.react';
import Button from '@mui/material/Button';
import { blue } from '@mui/material/colors';

function List() {
    const [response, setResponse] = useState([]);
    const [selectedRows, setSelectedRows] = useState([]);

    useEffect(() => {
        // localStorage.setItem('accessToken', "");
        async function getData() {
            const data = await get('https://jsonplaceholder.typicode.com/users')
            setResponse(data);
            console.log(response.data)
        }
        getData();
    }, [])

    const getFullName = (value, row) => {
        return `${row.name || ''} ${row.username}`
    }

    const updateSelectedRows = (type, rows) => {
        console.log(selectedRows)
        let updatedData;
        setResponse((prevRows) => {
            if (type === "single") {
                updatedData = prevRows.data.map((row) =>
                    rows.id === row.id
                        ? { ...row, name: 'test', username: 'deneme' }
                        : row
                );
            }
            else {
                updatedData = prevRows.data.map((row) =>
                    selectedRows.includes(row.id)
                        ? { ...row, name: 'test', username: 'deneme' }
                        : row
                );
            }

            return {
                ...prevRows,
                data: updatedData,
            };
        });

    };

    const columns = [
        { field: 'id', headerName: 'ID', flex: 1, disableExport: true },
        { field: 'name', headerName: 'Name', flex: 1 },
        { field: 'username', headerName: 'Username', flex: 1 },
        { field: 'fullname', headerName: 'Full Name', flex: 1, valueGetter: getFullName },
        { field: 'email', headerName: 'Email', flex: 1 },
        { field: 'address', headerName: 'Address', flex: 1 },
        {
            field: 'qrCode',
            headerName: 'QR Code',
            flex: 1,
            headerClassName: 'bold-header',
            renderCell: (params) => (
                <div
                    style={{
                        display: 'flex',
                        alignItems: 'center',
                        height: '100%',
                    }}
                >
                    <QRCodeSVG
                        value={params.row.username}
                        size={50}
                        className="qr-code-img"
                    />
                </div>
            ),
        },
        {
            field: 'actions',
            type: 'actions',
            headerName: 'Refresh QR',
            description:
                'You can create new QR using this button',
            headerClassName: 'bold-header',
            getActions: (params) => [
                <GridActionsCellItem
                    icon={<RefreshIcon sx={{ color: 'green', fontSize: 25 }} />}
                    label="Refresh"
                    onClick={() => updateSelectedRows("single", params.row)}
                />
            ]
        },
    ];

    function CustomToolbar() {
        return (
            <GridToolbarContainer>
                <GridToolbarExport csvOptions={{ disableToolbarButton: true }}
                    printOptions={{
                        fields: ['email', 'qrCode'],
                        hideFooter: true,
                        hideToolbar: true,
                    }} />
            </GridToolbarContainer>
        );
    }

    return (
        <>
            <Box display="flex" justifyContent="flex-end">
                <Button variant="outlined" endIcon={<RefreshIcon />} onClick={() => updateSelectedRows("multiple")}>
                    Refresh
                </Button>
            </Box>
            <Box paddingTop={2}>
                <DataGrid
                    rows={response.data}
                    columns={columns}
                    onRowSelectionModelChange={(newSelection) => setSelectedRows(newSelection)}
                    initialState={{
                        pagination: {
                            paginationModel: {
                                pageSize: 20,
                            },
                        },
                    }}
                    pageSizeOptions={[20, 50]}
                    checkboxSelection
                    slots={{ toolbar: CustomToolbar, }}

                    rowHeight={70}
                    sx={{
                        '.MuiDataGrid-columnHeaderTitle': {
                            fontWeight: 'bold',
                        },

                        '@media print': {
                            '.MuiDataGrid-root': {
                                display: 'flex',
                                flexDirection: 'column',
                            },
                            '.MuiDataGrid-columnHeaders': {
                                display: 'none', // Yazdırma sırasında kolon başlıklarını gizler
                            },
                            '.MuiDataGrid-row': {
                                display: 'flex',
                                flexDirection: 'column',
                                alignItems: 'stretch', // Satır içeriğini genişletir
                                padding: '10px 0', // Satırlar arasında boşluk bırakır
                                pageBreakAfter: 'always', // Her satırdan sonra yeni sayfa
                            },
                            '.MuiDataGrid-cell': {
                                fontSize: '16px',
                                display: 'flex',
                                flexDirection: 'column',
                                alignItems: 'center',
                                justifyContent: 'center',
                                padding: '10px', // Hücre içindeki boşluk
                                minHeight: '100px', // Minimum hücre yüksekliği
                                height: 'auto', // İçeriğe göre yükseklik
                                borderBottom: '1px solid #ccc', // Hücreler arasında görsel ayrım
                            },
                            '.qr-code-img': {
                                width: '150px !important',
                                height: '150px !important',
                                marginBottom: '10px', // QR kodun altında boşluk
                            },
                        },
                    }}
                />
            </Box>
        </>

    )
}

export default List