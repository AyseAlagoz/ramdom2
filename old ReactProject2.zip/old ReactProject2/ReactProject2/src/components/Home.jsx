import React from 'react'
import Typography from '@mui/material/Typography';
import { Box } from '@mui/material';
import NavBar from '../global/NavBar';
import AppBar from '../global/AppBar';

function Home() {
    return (
        <>
            <Box height={30} />
            <Box sx={{ display: 'flex' }}>
                <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
                    <h1>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Voluptatibus quibusdam nostrum vel. Deleniti nostrum nihil atque iste laboriosam neque omnis quos dolore, obcaecati perferendis voluptate facere ut. Nam, numquam! Est.
                        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eveniet placeat recusandae ut officiis, non quas deserunt quaerat vel natus accusamus temporibus illum dignissimos tenetur! Vel autem eos perferendis necessitatibus nemo!
                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Harum est dolor ex corrupti, cumque distinctio soluta eum eius ab? Magni accusamus iusto praesentium consequuntur officia eaque amet, quidem libero ex.
                    </h1>
                </Box>
            </Box>
        </>


    )
}

export default Home