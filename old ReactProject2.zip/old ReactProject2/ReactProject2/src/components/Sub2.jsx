import React from 'react'

function Sub2() {
    return (
        <div>Sub2</div>
    )
}

export default Sub2