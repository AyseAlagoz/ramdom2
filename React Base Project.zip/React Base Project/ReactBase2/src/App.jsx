import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { useEffect } from 'react'

function App() {
  const [firstName, setfirstName] = useState('');

  useEffect(() => {
    console.log("her zaman çalışır.")
  })

  useEffect(() => {
    console.log("component ilk render edildiğinde çalışır")
  }, [])

  useEffect(() => {
    console.log("ilk render edildiğinde ve firstname değeri değiştiğinde çalışır.")
  }, [firstName])
  // birden fazla state değiştiğinde de çalışabilir.

  return (
    <>
      <div>
        <button onClick={() => setfirstName("ayse")}>adı değiştir</button>
      </div>
    </>
  )
}

export default App
