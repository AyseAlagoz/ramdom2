import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Login from './Login'


function App() {
  let sonuc = false
  // bu değer htmlde süslü parantezler arasında çağırıldığında okunabilir. buna jsx denir. js kodu olduğunu belirtmiş oluruz böylece. bir formattır.

  //bu şekilde değişken tanımlamaya state denir. setfirstName fonksiyonu ile set edilebilir. useState içeirinde default değer verilir. firstName adı ile çağırılır.
  //set fonksiyonu kullanıldığında component tekrar render edilir. usestate bir hookstur.
  const [firstName, setfirstName] = useState(0);


  return (
    // kapsayıcı ana html oluşturulur. aşağıdaki şekilde oluşturmaya fragment denir.
    <>
      <div>
        {/* if kullanmaktan daha mantıklı */}
        {sonuc ? <p style={{ backgroundColor: 'orange' }}>test1</p> : <p style={{ backgroundColor: 'blue' }}>test2</p>}
        {/* prop kullanarak alt componente veri yolladık */}
        <Login name="test" surname="test"></Login>
      </div>
    </>

  )
}

//başka componentlerde kullanabilmek için, çağırabilmek için 
//bütün componenti değil sadece 1 parçasını dışarıda kullanmak için sadece export kullanılır.
// export const users = [{username: "ayse", {password: "test"}}]
//çağırırken import {users} from './Login' (aynı isimde olmalıdır.)
export default App
