import React from 'react'

//üst componentten gelen veriyi props ile karşıladık. props olarak karşılayıp props.name olarak da çağırabilirdik. ama bu şekilde js'deki destructure yapısını kullanmış
//oluyoruz ve destructure etmiş oluyoruz.
function Login({ name, surname }) {
    return (
        <>
            <div>{name}</div>
            <div>{surname}</div>
        </>

    )
}

export default Login