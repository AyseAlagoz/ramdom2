import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { useSelector, useDispatch } from 'react-redux'
import { decrement, increment } from './Redux/counterSlice'
import UserList from './components/UserList'

function App() {
  //storedaki initialstate'i döner.
  const value1 = useSelector((store) => store.counter)
  console.log(value1)
  //destructure
  const { value } = useSelector((store) => store.counter)
  console.log(value)

  //storedaki metotları dönmesi için kullanılır. aşağıda div içerisinde de çağırdık.
  const dispatch = useDispatch();

  return (
    <>
      <div>
        <div>{value}</div>
        <div>
          {/* dispatch ile çağırdık store'daki metotu */}
          <button onClick={() => dispatch(increment())}>Arttır</button>
          <button onClick={() => dispatch(decrement())}>Azalt</button>
        </div>
      </div>
      <UserList />
    </>
  )
}

export default App
