import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import axios from 'axios'

const initialState = {
    users: [],
    loading: false
}

export const userSlice = createSlice({
    name: "user",
    //initial state yerine farklı isim verilmek istendiğinde aşağıdaki gibi kullanılabilir. Normalde gerek yok. : koyup kendine eşitlemeye.
    initialState: initialState,
    reducers: {
        //http isteği değilse kullanılır
    },
    extraReducers: (builder) => {
        //http isteğinde kullanılır. stateimizi burada dolduruyoruz.
        builder.addCase(getAllUsers.fulfilled, (state, action) => {
            state.users = action.payload
        })
    }
})

export const getAllUsers = createAsyncThunk('users', async () => {
    const response = await axios.get("https://jsonplaceholder.typicode.com/users")
    console.log(response.data)
    return response.data;
})

export const { } = userSlice.actions
export default userSlice.reducer