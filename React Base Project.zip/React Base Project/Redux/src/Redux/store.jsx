import { configureStore } from '@reduxjs/toolkit'
import counterSlice from './counterSlice'
import userSlice from './UserSlice'

//slice(dilim)ları tanımlarız. Ortak parçalar slice'da tutulur. fonksiyonlar ise  slice içerisindeki increment alanına yazılır.
export const store = configureStore({
    reducer: {
        counter: counterSlice,
        user: userSlice
    },
})