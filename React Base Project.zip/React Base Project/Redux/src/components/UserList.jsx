import React, { useEffect, useSyncExternalStore } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { getAllUsers } from '../Redux/UserSlice';
import User from './User';

function UserList() {
    const dispatch = useDispatch();

    const { users } = useSelector(store => store.user);

    useEffect(() => {
        dispatch(getAllUsers())
    }, [])

    return (
        <div>
            {
                users && users.map((user) => (
                    <User key={user.id} user={user} />
                ))
            }
        </div>
    )
}

export default UserList