import React from 'react'

function User({ user }) {
    return (
        <div>{user.name}</div>
    )
}

export default User