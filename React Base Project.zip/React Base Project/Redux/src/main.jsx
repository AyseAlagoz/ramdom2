import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import { Provider } from 'react-redux'
import { store } from './Redux/store.jsx'

createRoot(document.getElementById('root')).render(
  //store'a her yerden erişebilmek için app componenti redux toolkitten gelen provider ile sarmalamak gerek
  <Provider store={store}>
    <App />
  </Provider>,
)
