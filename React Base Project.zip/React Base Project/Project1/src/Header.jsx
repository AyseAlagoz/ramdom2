import React from 'react'
import './css/Header.css'

function Header() {
    return (
        <div className='header'>
            <div className='title'>Manzaralar</div>
        </div>
    )
}

export default Header