import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Header from './Header'
import { landscapes } from './Data'
import Landscape from './components/Landscape.jsx'
import './css/Landscape.css'

function App() {

  return (
    <>
      <Header />
      <div className='course-main'>
        {
          landscapes?.map((landscape) => (
            <Landscape key={landscape.id} landscape={landscape} />

          ))
        }
      </div>
    </>
  )
}

export default App
