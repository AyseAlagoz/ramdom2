import React from 'react'

function Landscape({ landscape }) {
    const { id, title, image } = landscape
    return (
        <div className='landscape'>
            <div>
                <h4>{title}</h4>
                <img src={image} width={250} height={150}></img>
            </div>
        </div>
    )
}

export default Landscape