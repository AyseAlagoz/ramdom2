import Images1 from './images/images1.png'
import manzara2 from './images/images2.png'
import manzara3 from './images/images3.png'
import manzara4 from './images/images4.png'

export const landscapes = [
    {
        id: 1,
        title: "test",
        image: Images1
    },
    {
        id: 2,
        title: "Manzara2",
        image: manzara2
    },
    {
        id: 3,
        title: "Manzara3",
        image: manzara3
    },
    {
        id: 4,
        title: "Manzara4",
        image: manzara4
    }
]