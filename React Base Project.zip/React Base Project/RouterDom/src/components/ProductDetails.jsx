import React from 'react'
import { useParams } from 'react-router-dom'

function ProductDetails() {
    //id'yi destruct ettik, useParams ile url'deki id'yi aldık.
    const { id } = useParams();
    return (
        <div>ProductDetails</div>
    )
}

export default ProductDetails