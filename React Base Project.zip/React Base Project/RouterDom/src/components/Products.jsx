import React from 'react'
import Product from './Product'

const products = [
    {
        id: "1",
        name: "Bilgisayar",
        price: 50000
    },
    {
        id: "2",
        name: "Telefon",
        price: 20000
    },
    {
        id: "3",
        name: "Televizyon",
        price: 14000
    }
]

function Products() {
    return (
        <div>
            {
                products && products.map((product) => (
                    <Product key={product.id} product={product}></Product>
                ))
            }
        </div>
    )
}

export default Products