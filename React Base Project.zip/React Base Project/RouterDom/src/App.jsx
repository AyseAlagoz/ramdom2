import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { Routes, Route } from 'react-router-dom'
import Home from './components/Home'
import About from './components/About'
import Contact from './components/Contact'
import Products from './components/Products'
import NotFound from './components/NotFound'
import Header from './components/Header'
import ProductDetails from './components/ProductDetails'

function App() {

  return (
    <>
      <div>
        <Header />
        <Routes>
          <Route path='/' element={<Home />} ></Route>
          <Route path='/about' element={<About />} ></Route>
          <Route path='/contact' element={<Contact />} ></Route>
          <Route path='/products' element={<Products />} ></Route>
          <Route path='/product-details/:id' element={<ProductDetails />} ></Route>
          <Route path='*' element={<NotFound />} ></Route>
        </Routes>
      </div>
    </>
  )
}

export default App
