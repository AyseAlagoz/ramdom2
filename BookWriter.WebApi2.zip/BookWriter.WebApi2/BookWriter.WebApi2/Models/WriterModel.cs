﻿using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace BookWriter.WebApi2.Models
{
    public class WriterModel
    {
        [Key]
        public int WriterId { get; set; }
        public string WriterName { get; set; }

        //[JsonIgnore]
        //[IgnoreDataMember]
        //public ICollection<BookModel> BookModels { get; set; }
    }
}
