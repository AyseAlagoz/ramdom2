﻿namespace BookWriter.WebApi2.Models
{
    public class AddWriterModel
    {
        public string WriterName { get; set; }

    }
}
