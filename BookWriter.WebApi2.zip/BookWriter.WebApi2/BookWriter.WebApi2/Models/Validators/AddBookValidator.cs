﻿using FluentValidation;

namespace BookWriter.WebApi2.Models.Validators
{
    public class AddBookValidator : AbstractValidator<AddBookModel>
    {
        public AddBookValidator()
        {
            RuleFor(x => x.BookName).MinimumLength(5).WithMessage("Kitap Adı 5 karakterden az olamaz");
            //RuleFor(x => x.WriterId).LessThan(2).WithMessage("deneme");

        }
    }
}
