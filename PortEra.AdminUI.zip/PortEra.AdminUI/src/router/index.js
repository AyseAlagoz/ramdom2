import { createRouter, createWebHistory } from "vue-router";
import MainPage from "@/views/Main/MainPage.vue";
import LoginPage from "@/views/Main/LoginPage.vue";
import UserManagement from "@/views/UserManagement/UserManagement.vue";
// import AddNewAdditionalService from "@/views/CfsManagement/AddNewAdditionalService.vue";
import RoleManagement from "@/views/UserManagement/RoleManagement.vue";


const routes = [

  {
    path: "/",
    name: "main",
    component: MainPage,
  },
  {
    path: "/login",
    name: "login",
    component: LoginPage,
  },
  {
    path: "/usermanagement",
    name: "UserManagement",
    component: UserManagement,
  },
  {
    path: "/commodityAdditionalService",
    name: "CommodityAdditionalService",
    component: () => import("@/views/CfsManagement/CommodityAdditionalService.vue"),
  },
  //  {
  //   path: "/addAdditionalService",
  //   name: "AddNewAdditionalService",
  //   component: () => import("@/views/CfsManagement/AddNewAdditionalService.vue"),
  // },
  {
    path: "/rolemanagement",
    name: "RoleManagement",
    component: RoleManagement,
  },


];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

router.beforeEach((to, from, next) => {
  const isAuthenticated = localStorage.getItem("isAuthenticated");
  if (!isAuthenticated) {
    if (to.name !== "login") {
      next({ name: "login" });
    }
    else {
      next();
    }
  } else {
    if (to.name === "login") {
      next({ name: "home" });
    }
    else {
      next();
    }
  }
});
export default router;
