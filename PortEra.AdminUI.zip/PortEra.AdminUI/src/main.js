import 'devextreme/dist/css/dx.light.css';
import { createApp } from "vue";
import App from "./App.vue";
import router from "./router";
import vuetify from "./plugins/vuetify";
import { loadFonts } from "./plugins/webfontloader";
import "./App.css";
import { licenseKey } from "./devextremeLicense";
import config from 'devextreme/core/config';

config({
    licenseKey
});

loadFonts();

createApp(App).use(router).use(vuetify).mount("#app");
