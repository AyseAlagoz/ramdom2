export class SetUpdateUser {
    constructor(UserInfo, Ids) {
        this.Ids = Ids;
        this.UserInfo = UserInfo;
    }
}

export class SetCreateUser {
    constructor(UserInfo,Ids) {
        this.Ids = Ids;
        this.UserInfo = UserInfo;
    }
}

export class SetDeleteUser {
    constructor(Ids) {
        this.Ids = Ids;
    }
}


export class SetUpdateRole {
    constructor(Role) {
        this.Role = Role;
    }
}

export class SetCreateRole {
    constructor(Role) {
        this.Role = Role;
    }
}

export class SetDeleteRole {
    constructor(Ids) {
        this.Ids = Ids;
    }
}

export class GetSelectedUser{
    constructor(Id) {
        this.Id = Id;
    }
}

export class FindUser{
    constructor(UserName) {
        this.UserName = UserName;
    }
}

export class GetRoles {
    constructor(Name) {
        this.Name = Name;
    }
}

export class GetRolesByApp {
    constructor(Name) {
        this.Name = Name;
    }
}