import * as signalR from "@microsoft/signalr";
// import { useGlobalVariableStore } from "@/store/stores/globalVariableStores.js";
import { useSignalRStore } from "@/CommonVueCore/src/store/stores/signalRStores.js";
import { connectionStateEnum } from "@/constants/connectionStateEnum";

export default class SignalRService {
  constructor() {
    this.connection = null;
  }

  // SignalR bağlantısını başlatma
  startConnection({ hubUrl, successCallBack = null, errorCallBack = null }) {
    // var store = new useGlobalVariableStore();
    var store = new useSignalRStore();

    store.setConnectionState(connectionStateEnum.Reconnecting);

    this.connection = new signalR.HubConnectionBuilder()
      .withUrl(hubUrl, {
        skipNegotiation: true,
        withCredentials: false,
        transport: signalR.HttpTransportType.WebSockets,
      })
      .configureLogging(signalR.LogLevel.Debug)
      .withAutomaticReconnect({
        nextRetryDelayInMilliseconds: () => {
          store.setConnectionState(connectionStateEnum.Disconnected);
          errorCallBack();
          return window.appsettings.AppGlobal.SocketTimeOut;
        },
      })
      .build();

    // Bağlantı durumu değişikliklerini kontrol et
    this.connection.onreconnecting((error) => {
      if (!store.getIsManuallyStopState) {
        console.log("SignalR bağlantısı yeniden bağlanıyor...");
        store.setConnectionState(connectionStateEnum.Reconnecting);
      }
    });

    this.connection.onreconnected((connectionId) => {
      if (!store.getIsManuallyStopState) {
        console.log("SignalR bağlantısı yeniden kuruldu.");
        store.setConnectionState(connectionStateEnum.Connected);
        if (successCallBack) {
          successCallBack();
        }
      }
    });

    this.connection.onclose((error) => {
      console.error("Soket bağlantısı kapandı: ", error);
      if (!store.getIsManuallyStopState) {
        store.setConnectionState(connectionStateEnum.Disconnected);
        if (errorCallBack) {
          errorCallBack();
        }
        setTimeout(() => {
          this.startConnection({
            hubUrl: hubUrl,
            successCallBack: successCallBack,
            errorCallBack: errorCallBack,
          });
        }, window.appsettings.AppGlobal.SocketTimeOut);
      }
    });

    var glbThis = this;

    this.connection
      .start()
      .then(() => {
        console.log("Soket bağlantısı başarılı bir şekilde kuruldu.");
        store.setConnectionState(connectionStateEnum.Connected);
        if (successCallBack) {
          successCallBack();
        }
      })
      .catch((err) => {
        console.error("Soket bağlantısı kurulurken hata oluştu: ", err);
        store.setConnectionState(connectionStateEnum.Disconnected);
        if (errorCallBack) {
          errorCallBack();
        }
        setTimeout(() => {
          this.startConnection({
            hubUrl: hubUrl,
            successCallBack: successCallBack,
            errorCallBack: errorCallBack,
          });
        }, window.appsettings.AppGlobal.SocketTimeOut);
      });

    return this.connection;
  }

  stopConnection() {
    if (this.connection) {
      this.connection.stop();
    }
  }
}
