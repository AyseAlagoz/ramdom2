import StringHelper from "@/CommonVueCore/src/helpers/stringHelpers";

export default {
  constructor() {
    this.stringHelper = null;
  },

  validateNotNull(value) {
    if (this.stringHelper === undefined) this.stringHelper = new StringHelper();
    return !this.stringHelper.isNullOrEmpty(value);
  },

  validateUsername(username) {
    return username && username.length > 3;
  },

  validateEmail(email) {
    // DevExtreme'in email doğrulama kuralını manuel olarak uyguluyoruz
    const emailPattern = /^[\w.-]+@[a-zA-Z\d.-]+\.[a-zA-Z]{2,4}$/;

    // Geçerli mi değil mi kontrol edilir
    return emailPattern.test(email);

  },

  validateRequired(value) {
    return value && String(value).trim() !== "";
  },

  validateAreaPosition(position) {
    // DevExtreme'in email doğrulama kuralını manuel olarak uyguluyoruz
    const postionPattern = /^[a-zA-Z]+[0-9]*\.[0-9]$/;

    // Geçerli mi değil mi kontrol edilir
    return postionPattern.test(position);

  },
};
