import { Offcanvas } from "bootstrap";
import $ from "jquery";

export class OffCanvasService {
  offCanvasInstance = null;

  createInstance({ targetId }) {
    this.offCanvasInstance = new Offcanvas(document.getElementById(targetId));
  }

  show() {
    var isOpenedJobListPanel = $("#" + this.targetId).hasClass("show");
    if (!isOpenedJobListPanel) this.offCanvasInstance.show();
  }

  hide() {
    var isOpenedJobListPanel = $("#" + this.targetId).hasClass("hide");
    if (!isOpenedJobListPanel) this.offCanvasInstance.hide();
  }
}
