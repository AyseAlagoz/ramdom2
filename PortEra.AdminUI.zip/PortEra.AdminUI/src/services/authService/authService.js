// import { useCoreAuthStore } from "@/CommonVueCore/src/store/stores/authStores";

// function tokenParse() {
//   const authStore = useCoreAuthStore();
//   var authInfo = authStore.getParsedToken;
//   return authInfo;
// }

// function ResetUserInfo() {
//   const authStore = useCoreAuthStore();
//   authStore.setResetUserInfo();
// }

// function ResetToken() {
//   const authStore = useCoreAuthStore();
//   authStore.setResetToken();
// }

// function GetInfo() {
//   console.log("123123");
// }

// function GetInfo3() {
//   console.log("123w123");
// }

// export default {
//   tokenParse,
//   ResetUserInfo,
//   ResetToken,
//   GetInfo,
// };
