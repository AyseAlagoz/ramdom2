export class Preloader {
  start() {
    if (this.running) {
      return;
    }

    this.target.classList.add("running");
    this.pickCrate();
  }

  stop() {
    clearTimeout(this.timeout);
    this.target.classList.remove("running");
    this.target.classList.remove("transition");
    this.target.classList.remove(`crate-${this.current}`);
    this.crates[this.current].classList.remove("source");
    this.crates[this.crates.length - 1 - this.current].classList.remove(
      "destination"
    );
  }

  get running() {
    return this.target.classList.contains("running");
  }

  constructor(target) {
    this.current = 0;
    this.target = target;
    this.crates = target.getElementsByClassName("crate");
  }

  pickCrate() {
    this.target.classList.remove(`crate-${this.current}`, "transition");
    this.crates[this.current].classList.remove("source");
    this.crates[this.crates.length - 1 - this.current].classList.remove(
      "destination"
    );

    this.current = Math.floor(Math.random() * this.crates.length);

    this.target.classList.add(`crate-${this.current}`);
    this.timeout = setTimeout(this.grabCrate.bind(this), 1500);
  }

  grabCrate() {
    this.target.classList.add("transition");
    this.crates[this.current].classList.add("source");
    this.crates[this.crates.length - 1 - this.current].classList.add(
      "destination"
    );

    this.timeout = setTimeout(this.pickCrate.bind(this), 1500);
  }
}
