import { Complex } from "@/CommonVueCore/src/constants/globalEnums/Complex"

export class ComplexService {

  getInfoByCode(code) {
    const numericCode = typeof code === "string" ? parseInt(code, 10) : code; // Eğer string ise sayıya dönüştür
  
    for (const key of Object.keys(Complex)) {
      const value = Complex[key];
  
      if (Array.isArray(value)) {
        // Değer bir dizi ise, dizi öğelerini kontrol et
        const found = value.find(item => item.code === numericCode);
        if (found) {
          return found;
        }
      } else if (typeof value === "object" && value.code === numericCode) {
        // Değer tek bir nesne ise ve kod eşleşiyorsa
        return value;
      }
    }
  
    // Eşleşme bulunamazsa null döner
    return null;
  }
  
  

  getAllCodes() {
    const codes = [];

    for (const key in Complex) {
      const value = Complex[key];

      if (Array.isArray(value)) {
        for (const item of value) {
          codes.push(item.code);
        }
      } else if (typeof value === "object" && "code" in value) {
        codes.push(value.code);
      }
    }
    return codes;
  }

  getInfoByDescription(description) {

    for (const key in Complex) {
      const value = Complex[key];
      
      // Eğer değer bir dizi ise, içindeki nesnelerde arama yap
      if (Array.isArray(value)) {
        for (const item of value) {
          if (item.description === description) {
            return item;
          }
        }
      } else if (typeof value === 'object' && value.description === description) {
        // Eğer değer nesne ise ve açıklama eşleşiyorsa
        return value;
      }
    }
    
    // Eşleşme bulunamazsa null döner
    return null;
  }

  getInfoByDescriptions(descriptions) {
    const results = [];
  
    for (const description of descriptions) {
      for (const key of Object.keys(Complex)) {
        const value = Complex[key];
  
        if (Array.isArray(value)) {
          // Değer bir dizi ise, eşleşen öğeyi bul
          const found = value.find(item => item.description === description);
          if (found) {
            results.push(found); // Bulunan nesneyi listeye ekle
          }
        } else if (typeof value === "object" && value.description === description) {
          // Değer tek bir nesne ise ve açıklama eşleşiyorsa
          results.push(value); // Nesneyi listeye ekle
        }
      }
    }
  
    return results; // Sonuç listesini döndür
  }
  
  
}
