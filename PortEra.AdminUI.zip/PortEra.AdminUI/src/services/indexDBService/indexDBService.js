class IndexedDBService {
    constructor() {
      this.openConnections = new Map();
    }
  
    // ======================
    // Helper Methods
    // ======================
    async _dbExists(dbName) {
      const databases = await indexedDB.databases();
      return databases.some(db => db.name === dbName);
    }
  
    async _collectionExists(dbName, collectionName) {
      if (!(await this._dbExists(dbName))) return false;
      const db = await this._openDB(dbName);
      const exists = db.objectStoreNames.contains(collectionName);
      db.close();
      return exists;
    }
  
    async _openDB(dbName) {
      return new Promise((resolve, reject) => {
        const request = indexedDB.open(dbName);
        request.onsuccess = () => resolve(request.result);
        request.onerror = (e) => reject(e.target.error);
      });
    }
  
    async _validateDBAndCollection(dbName, collectionName) {
      if (!(await this._dbExists(dbName))) {
        throw new Error(`Database '${dbName}' not found`);
      }
      if (!(await this._collectionExists(dbName, collectionName))) {
        throw new Error(`Collection '${collectionName}' not found in database '${dbName}'`);
      }
    }
  
    async _getOrCreateDB(dbName, collectionName, keyPath, autoIncrement) {
      try {
        let db = await this._openDB(dbName);
        if (!db.objectStoreNames.contains(collectionName)) {
          db.close();
          const newVersion = db.version + 1;
          db = await new Promise((resolve, reject) => {
            const req = indexedDB.open(dbName, newVersion);
            req.onupgradeneeded = (e) => {
              e.target.result.createObjectStore(collectionName, {
                keyPath,
                autoIncrement
              });
            };
            req.onsuccess = () => resolve(req.result);
            req.onerror = (e) => reject(e.target.error);
          });
        }
        return db;
      } catch (error) {
        throw new Error(`Database setup failed: ${error.message}`);
      }
    }
  
    // ======================
    // CRUD Operations
    // ======================
    async addData(dbName, collectionName, dataList, keyPath, autoIncrement = true) {
      try {
        const db = await this._getOrCreateDB(dbName, collectionName, keyPath, autoIncrement);
        const tx = db.transaction(collectionName, 'readwrite');
        const store = tx.objectStore(collectionName);
  
        const results = await Promise.all(
          dataList.map(data => new Promise((resolve, reject) => {
            const request = store.add(data);
            request.onsuccess = () => resolve(request.result);
            request.onerror = (e) => reject(e.target.error);
          }))
        );
  
        db.close();
        return results;
      } catch (error) {
        throw new Error(`Add data failed: ${error.message}`);
      }
    }
  
    async deleteData(dbName, collectionName, keyList) {
      try {
        await this._validateDBAndCollection(dbName, collectionName);
        const db = await this._openDB(dbName);
        const tx = db.transaction(collectionName, 'readwrite');
        const store = tx.objectStore(collectionName);
  
        const results = await new Promise((resolve, reject) => {
          const promises = keyList.map(key =>
            new Promise((resolve, reject) => {
              const request = store.delete(key);
              request.onsuccess = () => resolve(key);
              request.onerror = (e) => reject(e.target.error);
            })
          );
  
          Promise.all(promises)
            .then(resolve)
            .catch(error => {
              tx.abort();
              reject(error);
            });
        });
  
        db.close();
        return results;
      } catch (error) {
        throw new Error(`Delete data failed: ${error.message}`);
      }
    }
  
    async updateData(dbName, collectionName, keyList, newData) {
      try {
        await this._validateDBAndCollection(dbName, collectionName);
        const db = await this._openDB(dbName);
        const tx = db.transaction(collectionName, 'readwrite');
        const store = tx.objectStore(collectionName);
  
        const results = await new Promise((resolve, reject) => {
          const promises = keyList.map(key =>
            new Promise((resolve, reject) => {
              const getRequest = store.get(key);
              getRequest.onsuccess = () => {
                const existing = getRequest.result;
                if (!existing) {
                  reject(new Error(`Key ${key} not found`));
                  return;
                }
                const updated = { ...existing, ...newData };
                const putRequest = store.put(updated);
                putRequest.onsuccess = () => resolve(updated);
                putRequest.onerror = (e) => reject(e.target.error);
              };
              getRequest.onerror = (e) => reject(e.target.error);
            })
          );
  
          Promise.all(promises)
            .then(resolve)
            .catch(error => {
              tx.abort();
              reject(error);
            });
        });
  
        db.close();
        return results;
      } catch (error) {
        throw new Error(`Update data failed: ${error.message}`);
      }
    }
  
    // ======================
    // Query Operations
    // ======================
    async getDataWithFilter(dbName, collectionName, filterCallback, returnKeys = false) {
      try {
        await this._validateDBAndCollection(dbName, collectionName);
        const db = await this._openDB(dbName);
        const tx = db.transaction(collectionName, 'readonly');
        const store = tx.objectStore(collectionName);
  
        return new Promise((resolve, reject) => {
          const request = store.openCursor();
          const results = [];
  
          request.onsuccess = (e) => {
            const cursor = e.target.result;
            if (cursor) {
              try {
                if (filterCallback(cursor.value)) {
                  results.push(returnKeys ? cursor.primaryKey : cursor.value);
                }
                cursor.continue();
              } catch (filterError) {
                reject(new Error(`Filter error: ${filterError.message}`));
              }
            } else {
              db.close();
              resolve(results);
            }
          };
  
          request.onerror = (e) => {
            db.close();
            reject(new Error(`Cursor error: ${e.target.error.message}`));
          };
        });
      } catch (error) {
        throw new Error(`Filter query failed: ${error.message}`);
      }
    }
  
    async getDataWithKey(dbName, collectionName, keyList) {
      try {
        await this._validateDBAndCollection(dbName, collectionName);
        const db = await this._openDB(dbName);
        const tx = db.transaction(collectionName, 'readonly');
        const store = tx.objectStore(collectionName);
  
        const results = await new Promise((resolve, reject) => {
          const promises = keyList.map(key =>
            new Promise((resolve, reject) => {
              const request = store.get(key);
              request.onsuccess = () => {
                if (!request.result) {
                  reject(new Error(`Key ${key} not found`));
                } else {
                  resolve(request.result);
                }
              };
              request.onerror = (e) => reject(e.target.error);
            })
          );
  
          Promise.all(promises)
            .then(resolve)
            .catch(error => {
              tx.abort();
              reject(error);
            });
        });
  
        db.close();
        return results;
      } catch (error) {
        throw new Error(`Get by keys failed: ${error.message}`);
      }
    }
  
    // ======================
    // Database Management
    // ======================
    async getAllDb(dbName) {
      if (!(await this._dbExists(dbName))) {
        throw new Error(`Database '${dbName}' not found`);
      }
  
      const db = await this._openDB(dbName);
      const result = {};
  
      await Promise.all(
        Array.from(db.objectStoreNames).map(async (storeName) => {
          const tx = db.transaction(storeName, 'readonly');
          const store = tx.objectStore(storeName);
          result[storeName] = await new Promise(resolve => {
            const request = store.getAll();
            request.onsuccess = () => resolve(request.result);
          });
        })
      );
  
      db.close();
      return result;
    }
  
    async deleteSelectedCollection(dbName, collectionName) {
      if (!(await this._collectionExists(dbName, collectionName))) {
        throw new Error(`Collection '${collectionName}' not found in database '${dbName}'`);
      }
  
      const db = await this._openDB(dbName);
      const version = db.version;
      db.close();
  
      return new Promise((resolve, reject) => {
        const req = indexedDB.open(dbName, version + 1);
        req.onupgradeneeded = (e) => {
          e.target.result.deleteObjectStore(collectionName);
        };
        req.onsuccess = () => {
          req.result.close();
          resolve();
        };
        req.onerror = (e) => reject(e.target.error);
      });
    }
  
    async deleteSelectedDb(dbName) {
      if (!(await this._dbExists(dbName))) {
        throw new Error(`Database '${dbName}' not found`);
      }
  
      return new Promise((resolve, reject) => {
        const req = indexedDB.deleteDatabase(dbName);
        req.onsuccess = resolve;
        req.onerror = (e) => reject(e.target.error);
      });
    }
  
    async getSelectedCollection(dbName, collectionName) {
      try {
        // Validate database and collection existence
        await this._validateDBAndCollection(dbName, collectionName);
  
        const db = await this._openDB(dbName);
        const tx = db.transaction(collectionName, 'readonly');
        const store = tx.objectStore(collectionName);
  
        // Get all data from the collection
        const data = await new Promise((resolve, reject) => {
          const request = store.getAll();
          request.onsuccess = () => resolve(request.result);
          request.onerror = (e) => reject(e.target.error);
        });
  
        db.close();
        return data;
      } catch (error) {
        throw new Error(`Get collection failed: ${error.message}`);
      }
    }
  }
  
  export default new IndexedDBService();