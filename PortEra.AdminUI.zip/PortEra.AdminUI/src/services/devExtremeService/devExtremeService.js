import CustomStore from "devextreme/data/custom_store";
export default class DevExtremeService {
  getItems({ serviceClient, route, insertRoute, updateRoute }) {
    
    var dataSource = new CustomStore({
      key: "PKey",
      load: async (loadOptions) => {
        var queryStrObject = {};
        [
          "skip",
          "take",
          "requireTotalCount",
          "requireGroupCount",
          "sort",
          "filter",
          "totalSummary",
          "group",
          "groupSummary",
        ].forEach((i) => {
          if (i in loadOptions && this.#isNotEmpty(loadOptions[i])) {
            queryStrObject[i] = JSON.stringify(loadOptions[i]);
          }
        });

        try {
          var response = await serviceClient.get({
            route: route,
            params: queryStrObject,
          });

          const data = response.data;

          return data;
        } catch (error) {
          throw new Error("Data loading error");
        }
      },
      insert: async (values) => {
        console.log("values", values);
        console.log("insertRoute", insertRoute);
        

        await serviceClient.post({
          route: insertRoute,
          data: values,
          successCallBack: (resp) => {
            console.log("resp", resp);
          },
          errorCallBack: (err) => {
            console.log("err", err);
          },
        });
        
      },
      update: async (key, values) => {
        console.log("updated keys", key);
        console.log("updated values", values);
      }
    });

    return dataSource;
  }

  // async setItems({
  //   serviceClient,
  //   route,
  //   data = null,
  //   successCallback = null,
  //   errorCallback = null,
  // }) {
  //   var response = await serviceClient.post({
  //     route: route,
  //     data: data,
  //     successCallback: successCallback,
  //     errorCallback: errorCallback,
  //   });

  //   return response;
  // }

  // prepareContextMenu(e, menuItems) {
  //   //! kullanılan yerde bu şekilde obje listesi beklenir
  //   /**const menuItems = [
  //   {
  //     text: 'Display Email Content',
  //     icon: 'alignleft',
  //     clickEvent: () => this.contextMenuDisplayEmailContent
  //   },
  //   {
  //     text: 'Display Email Content 2',
  //     icon: 'alignleft',
  //     clickEvent: () => this.contextMenuDisplayEmailContent2
  //   }
  // ];**/

  //   if (e.target == "header") {
  //     if (!e.items) e.items = [];
  //   }

  //   if (e.target == "content") {
  //     if (!e.items) e.items = [];

  //     for (var item of menuItems) {
  //       var newItem = {
  //         text: item.text,
  //         icon: item.icon,
  //       };

  //       if (item.items && item.items.length > 0) {
  //         newItem.items = [];
  //         for (var subMenuItem of item.items) {
  //           var newSubItem = {
  //             text: subMenuItem.text,
  //             icon: subMenuItem.icon,
  //             onItemClick: subMenuItem?.clickEvent(),
  //           };
  //           newItem.items.push(newSubItem);
  //         }
  //       } else {
  //         newItem.onItemClick = item?.clickEvent();
  //       }
  //       e.items.push(newItem);
  //     }
  //   }
  // }

  // * bu metot apilerinde CRUD işlemlerinde bazılarında toplu islemin yapilip bazilarinda yapilmamis
  // * olan ekranlar icin yapildi. tam olarak genel bir service degil. Fakat kullanan birden fazla view
  // * olabilir. Apilerde ki tum islemler batch isleme cevrilmedigi surece kullanilabilir.
  // getTransactionRows({ changes }) {
  //   return {
  //     insertedRows: changes.filter((item) => item.type === "insert"),
  //     updatedRows: changes.filter((item) => item.type === "update"),
  //     removedRows: changes.filter((item) => item.type === "remove"),
  //   };
  // }

  #isNotEmpty(value) {
    return value !== undefined && value !== null && value !== "";
  }
}
