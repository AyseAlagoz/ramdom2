import CustomStore from "devextreme/data/custom_store";
import { get } from "@/CommonVueCore/src/services/httpService/JsonServiceClient/basicServiceClient.js";

async function getItems(url,headers) {
  var dataSource = new CustomStore({
    key: "PKey",
    async load(loadOptions) {
      const params = {};
      ["skip","take","requireTotalCount","requireGroupCount","sort","filter","totalSummary","group","groupSummary"]
        .forEach(k => {
          const v = loadOptions[k];
          if (_isNotEmpty(v)) params[k] = v;
        });
      var response = await get(url, params, headers);
      return response;
    },
  });

  return dataSource;
}

function _isNotEmpty(value) {
  return value !== undefined && value !== null && value !== "";
}


export {
  getItems,
};
