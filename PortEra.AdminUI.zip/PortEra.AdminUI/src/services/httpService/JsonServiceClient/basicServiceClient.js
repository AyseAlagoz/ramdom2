import { JsonServiceClient } from '@servicestack/client';
//post methodu dönüşte json döner bundan dolayı response classlarının dönmesi gerekmektedir.
// client.setResponseType('json'); // default olarak json döner
// Bizim backend yapımız json döndüğü için default kullanıyoruz.

async function api(baseUrl, TObject, headers = [], callBack = ()=>{}) {// Bu method domain üstünden class signaturea göre request atar.
    const client = new JsonServiceClient(baseUrl);
    client.credentials = 'omit';

    headers.forEach(header => {
        client.headers.append(header.key, header.value); // header ekleme işlemi
    });

    callBack(client);
    try {
        const response = await client.api(TObject);
        return response;
    } catch (error) {
        console.error(error);
        throw error
    }
}

async function get(baseUrl, params, headers = [],callBack = ()=>{}) {//[{key: 'headerKey', value: 'headerValue'}] şeklinde header gönderilebilir.
    const client = new JsonServiceClient(baseUrl);
    client.credentials = 'omit';

    headers.forEach(header => {
        client.headers.append(header.key, header.value); // header ekleme işlemi
    });

    callBack(client);
    try {
        const response = await client.get(baseUrl, params);
        return response;
    } catch (error) {
        console.error(error);
        throw error
    }
}

async function post(baseUrl, data, headers = [], callBack = ()=>{}) {
    let client = new JsonServiceClient(baseUrl);
    client.credentials = 'omit';

    headers.forEach(header => {
        client.headers[header.key] = header.value; // header ekleme işlemi
    });

    callBack(client);

    try {
        const response = await client.postToUrl(baseUrl, data);
        return response;
    } catch (error) {
        console.error(error);
        throw error
    }
}


// (()=>{
//     function setInterceptor(){
//         JsonServiceClient.prototype.credentials = 'omit'; // default olarak include kullanılıyor. Bunu omit yaparak sadece backend'e giden requestlerde cookie gönderiyoruz.
//         console.log('JsonServiceClient credentials set to omit');
//     }
//     setInterceptor();
// })();
export { api, get, post };

/*
      // const res = await api(
        //   "https://localhost:60009",
        //   new TestPostPa("test", "test")
         
            
          
        // );
        // console.log(res)

        // const resx = await get(
        //   "https://localhost:60009/TestGetQ",
        //   new TestGetQ("test")
        // );
        // console.log(resx)

        const res = await post(
          "https://localhost:60009/TestPostP",
          new TestPostP("test"),
          [{
            key: "Bearer ",
            value:"1asdasdasd",
          },
          {
            key: "Bearer2 ",
            value:"1asdasdasd",
          }]
        );
*/