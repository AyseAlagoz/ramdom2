// Bu sınıfta JsonServiceClient'in önbelleklenmiş instance'larını yönetiyoruz.
// Bu manager ile bir baseUrl çok kullanılıyorsa her seferinde yeni bir instance oluşturmak yerine önbellekten alıyoruz.
// Bu sayede performans artışı sağlıyoruz ve gereksiz bellek kullanımını azaltıyoruz.
import { JsonServiceClient } from '@servicestack/client';

class ApiClientManager {
  constructor() {
    this.clients = new Map();
  }

  /**
   * Verilen baseUrl için daha önce oluşturulmuş client varsa onu döner,
   * yoksa yeni bir instance oluşturup cache'e ekler.
   * Alttaki param syntaxı sadece tipi belirtmek için kullanılıyor.Başka bir işlevi yok.
   * @param {string} baseUrl
   * @returns {JsonServiceClient}
   */
  getClient(baseUrl) {
    if (!this.clients.has(baseUrl)) {
      this.clients.set(baseUrl, new JsonServiceClient(baseUrl));
    }
    return this.clients.get(baseUrl);
  }

  /**
   * İsteğe bağlı: Belirli bir baseUrl için client instance’ını resetler.
   * Bu, önbelleği temizlemek için kullanılabilir.
   * Örneğin, baseUrl değiştiğinde veya istemciyi yeniden başlatmak istediğinizde.
   * @param {string} baseUrl
   */
  resetClient(baseUrl) {
    this.clients.delete(baseUrl);
  }
}

// Manager'ı global olarak export ediyoruz.
export const apiClientManager = new ApiClientManager();

/**
 * BaseUrl ve request DTO (ya da isteğe bağlı bir nesne) alarak
 * ilgili client instance’ı üzerinden api isteği yapar.
 * @param {string} baseUrl
 * @param {Object} requestDto
 * @returns {Promise<any>} API çağrısı sonucu
 */
export async function get(baseUrl, requestDto, headers = []) {
  const client = apiClientManager.getClient(baseUrl);
  client.credentials = 'omit'
  console.log(client)
  headers.forEach(header => {
    client.headers[header.key] = header.value; // header ekleme işlemi
  });

  try {
    const response = await client.get(baseUrl, requestDto);
    console.log(response)
    return response;
  } catch (error) {
    throw error;
  }
}

export async function post(baseUrl, requestDto, headers = []) {
  const client = apiClientManager.getClient(baseUrl);
  client.credentials = 'omit'

  headers.forEach(header => {
    client.headers[header.key] = header.value; // header ekleme işlemi
  });

  console.log(client)
  try {
    const response = await client.postToUrl(baseUrl, requestDto);
    console.log(response)
    return response;
  } catch (error) {
    throw error;
  }
}

export async function api(baseUrl, requestDto, headers = []) {
  const client = apiClientManager.getClient(baseUrl);
  client.credentials = 'omit'

  headers.forEach(header => {
    client.headers[header.key] = header.value; // header ekleme işlemi
  });

  console.log(client)
  try {
    const response = await client.api(requestDto);
    console.log(response)
    return response;
  } catch (error) {
    throw error;
  }
}