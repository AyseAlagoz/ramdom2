import swal from "@/CommonVueCore/src/assets/js/vendor/notifications/sweet_alert.min";

export class SweetToastrService {
  constructor({ defaultOptions = {} } = {}) {
    this.defaultOptions = {
      toast: true,
      buttonsStyling: false,
      position: "top-end",
      showConfirmButton: false,
      showCloseButton: true,
      timer: 3000,
      timerProgressBar: true,
      customClass: {},
      newestOnTop: true, // Yeni bildirimi üstte göster
      progressBar: true, // Bildirim süresini gösteren progress bar
      positionClass: "toast-top-right", // Bildirimlerin nerede görüneceği
      preventDuplicates: false, // Aynı bildirimin birden fazla kez görünmesini engelleme
      didOpen: (toast) => {
        toast.onmouseenter = swal.stopTimer;
        toast.onmouseleave = swal.resumeTimer;
      },
      ...defaultOptions,
    };
    this.swalInit = swal.mixin(this.defaultOptions);
  }

  fireCustom(options) {
    return this.swalInit.fire({
      ...this.defaultOptions,
      ...options,
    });
  }

  success(text, customOptions = {}) {
    return this.fireCustom({
      text: text,
      icon: "success",
      customClass: {
        popup: "swal-success",
      },
      ...customOptions,
    });
  }

  info(text, customOptions = {}) {
    return this.fireCustom({
      text: text,
      icon: "info",
      customClass: {
        popup: "swal-info",
      },
      ...customOptions,
    });
  }

  warning(text, customOptions = {}) {
    return this.fireCustom({
      text: text,
      icon: "warning",
      customClass: {
        popup: "swal-warning",
      },
      ...customOptions,
    });
  }

  error(text, customOptions = {}) {
    return this.fireCustom({
      text: text,
      icon: "error",
      customClass: {
        popup: "swal-error",
      },
      ...customOptions,
    });
  }

  question(text, customOptions = {}) {
    return this.fireCustom({
      text: text,
      icon: "question",
      customClass: {
        popup: "swal-question",
      },
      ...customOptions,
    });
  }

  clearToastr() {
    this.swalInit.close();
  }
}
