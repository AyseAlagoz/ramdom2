import swal from "@/CommonVueCore/src/assets/js/vendor/notifications/sweet_alert.min";

export class SweetAlertService {
  constructor({ defaultOptions = {} }) {
    this.defaultOptions = {
      buttonsStyling: false,
      customClass: {
        confirmButton: "btn btn-primary",
        cancelButton: "btn btn-light",
        denyButton: "btn btn-light",
        input: "form-control",
      },
      ...defaultOptions,
    };
    this.swalInit = swal.mixin(this.defaultOptions);
  }

  fireCustom(options) {
    const largeButtons = options.largeButtons ? " btn-lg" : "";

    const mergedOptions = {
      ...this.defaultOptions,
      ...options,
      customClass: {
        ...this.defaultOptions.customClass,
        ...options.customClass,
        confirmButton: this.defaultOptions.customClass.confirmButton + largeButtons,
        cancelButton: this.defaultOptions.customClass.cancelButton + largeButtons,
        denyButton: this.defaultOptions.customClass.denyButton + largeButtons,
      },
    };

    return this.swalInit.fire(mergedOptions);
  }

  success(title, text, customOptions = {}) {
    return this.fireCustom({
      title: title,
      text: text,
      icon: "success",
      ...customOptions,
    });
  }

  info(title, text, customOptions = {}) {
    return this.fireCustom({
      title: title,
      text: text,
      icon: "info",
      ...customOptions,
    });
  }

  warning(title, text, customOptions = {}) {
    return this.fireCustom({
      title: title,
      text: text,
      icon: "warning",
      ...customOptions,
    });
  }

  error(title, text, customOptions = {}) {
    return this.fireCustom({
      title: title,
      text: text,
      icon: "error",
      ...customOptions,
    });
  }

  question(title, htmlContent, customOptions = {}) {
    return this.fireCustom({
      title: title,
      html: htmlContent,
      icon: "question",
      ...customOptions,
    });
  }
}

