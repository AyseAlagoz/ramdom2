<template>  
    <v-container dense class="mt-2">
      <h1>Main page</h1>
    </v-container>
  </template>
  
  <script>
  import ConfirmContent from "@/components/base/ConfirmContent.vue";
  import MessageContent from "@/components/base/MessageContent.vue";
  export default {
    name: "MainMenu",
  //  inject:["openDialog","closeDialog"],
    data() {
      return {
      };
    },
    methods: {
      goTo(page, isConnectionRequired = false) {
        if(isConnectionRequired && !navigator.onLine){
          this.openDialog(MessageContent, "Bu sayfalar için internet bağlantısı gerekmektedir..");
          return;
        }
        this.$router.push(page);
      },
      alertNonexistPages(){
        alert("Bu sayfa üstünde çalışılmaktadır.")
      },
      async logOut() {
        alert("Çıkış yapıldı.")
      },
      logOutConfirmOpener(){
        this.openDialog(
          ConfirmContent,
          "Çıkış yapmak istediğinize emin misiniz? \n Çevrimdışı veriler silinecektir.",
          async () => {
            this.logOut();
          }
        );
      }
    },
    mounted(){
    
    }
  };
  </script>
  
  <style scoped>
  .menuText {
    font-size: clamp(0.2rem, 1.2vw + 1.2rem, 2.5rem);
    line-height: 1.2;
    padding: 0 4px;
    white-space: wrap;
  }
  
  .custom-height {
    height: calc(60vh / 5);
  }
  
  @media (max-height: 640px) {
    .custom-height {
      height: calc(60vh / 6);
    }
  }
  
  .custom-height2 {
    height: calc(60vh / 3);
  }
  
  @media (max-height: 600px) {
    .custom-height2 {
      height: calc(60vh / 3.5);
    }
  }
  </style>
  