<template>
  <v-container fluid class="login-container">
    <v-row justify="center" align="center" class="fill-height">
      <v-col cols="12" sm="8" md="6" lg="4">
        <v-card class="pa-6" elevation="6" rounded>
          <v-form>
            <div class="mb-4">
              <label for="email" class="left-aligned"><b>KULLANICI ADI</b></label>
              <v-text-field v-model="user.username" variant="solo"></v-text-field>
            </div>
            <div class="mb-4">
              <label for="password" class="left-aligned"><b>PAROLA</b></label>
              <v-text-field
                v-model="user.password"
                :append-inner-icon="showPassword ? 'mdi-eye-off' : 'mdi-eye'"
                :type="showPassword ? 'text' : 'password'"
                prepend-inner-icon="mdi-lock-outline"
                variant="solo"
                @click:append-inner="showPassword = !showPassword"
                @keydown.enter="logIn"
              ></v-text-field>
            </div>
            <v-btn color="primary" @click="logIn" rounded block class="custom-height textFont">
              GİRİŞ YAP
            </v-btn>
          </v-form>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>


<script>
import MessageContent from "@/components/base/MessageContent.vue";
import Operation from "@/utils/Operations.js";
import { logIn } from "@/utils/httpServices";
import { BASE_URL } from "@/constants/api";
export default {
  name: "MainMenu",
  emits: ["loginSuccess"],
  inject: ["toggleLoadingOverlay", "openDialog"],
  components: {
    MessageContent,
  },
  data() {
    return {
      showPassword: false,
      user: {
        username: "",
        password: "",
      },
    };
  },
  methods: {
    async logIn() {
      if (
        this.user.username.trim() === "" ||
        this.user.password.trim() === ""
      ) {
        this.openDialog(MessageContent, "Kullanıcı adı veya parola boş olamaz");
        return;
      }

      try {
        this.toggleLoadingOverlay();
        const res = await logIn(`${BASE_URL}SetLogIn`, {
          UserName: this.user.username,
          Password: this.user.password,
        });
        
        if (res.ResponseCode == 'Success') {
          localStorage.setItem("isAuthenticated", true);
          Operation.logIn(res.Data);
          this.toggleLoadingOverlay();
          this.$emit("login-success");
          this.$router.push("/");
          return;
        } 
        else {
          this.toggleLoadingOverlay();
          this.openDialog(MessageContent, "Kullanıcı adı veya parola hatalı");
        }
      } catch (e){
        this.openDialog(MessageContent, "Beklenmeyen bir hata oluştu");
        this.toggleLoadingOverlay();
      }
    },
  },
};
</script>

<style scoped>
.login-container {
  height: 100vh;
  background-color: #f5f5f5; /* İsteğe bağlı arka plan rengi */
}

.left-aligned {
  text-align: left;
  display: block;
  font-size: clamp(0.2rem, 1.2vw + 1.6rem, 2.6rem);
  font-weight: bold;
  margin-bottom: 4px;
}

.textFont {
  font-size: clamp(1.4rem, 1.2vw + 1.6rem, 2.6rem);
  font-weight: bold;
}

.custom-height {
  height: calc(60vh / 4.5);
}
</style>
