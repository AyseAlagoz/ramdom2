<template>
    <v-dialog :model-value="showNewASCard" @update:model-value="$emit('update:showNewASCard', $event)" width="500px"
        :style="{ zIndex: 3 }" persistent no-click-animation>
        <v-card>
            <v-toolbar color="white" border>
                <v-chip class="ma-2" color="orange-darken-4" label>
                    <v-icon start icon="mdi-bookmark"></v-icon>
                    {{ dialogTitle }}
                </v-chip>
                <v-spacer></v-spacer>
                <v-btn class="ma-2" tile outlined color="green" @click="saveData">
                    <v-icon left>mdi-content-save</v-icon>SAVE
                </v-btn>
                <v-btn class="ma-2" tile outlined color="red" @click="deleteData" v-if="type === 'update'">
                    <v-icon left>mdi-content-save</v-icon>DELETE
                </v-btn>
                <v-icon size="small" color="red" start icon="mdi-close-octagon-outline"
                    @click="closeOperationPage"></v-icon>
            </v-toolbar>
            <v-container>
                <v-row>
                    <v-col cols="12" md="12">
                        <v-autocomplete v-model="selectedCommodities" :items="commodityItems" item-value="id"
                            item-title="title" :loading="loadingCommodities" return-object
                            label="Please select commodity" multiple variant="outlined"
                            @update:search="handleSearchCommodities" :value-comparator="compareById"
                            :menu-props="{ maxWidth: 0 }">
                            <template v-slot:selection="data">
                                <v-chip :key="JSON.stringify(data.item)" v-bind="data.attrs" :disabled="data.disabled"
                                    :model-value="data.selected" size="small"
                                    @click:close="data.parent.selectItem(data.item)">
                                    <template v-slot:prepend>
                                        <v-avatar color="orange-darken-4" class="text-white" start>{{
                                            data.item.title.slice(0,
                                                1)
                                        }}</v-avatar>
                                    </template>
                                    {{ data.item.title }}
                                </v-chip>
                            </template>
                        </v-autocomplete>
                    </v-col>
                    <v-col cols="12" md="12">
                        <v-autocomplete v-model="selectedAdditionalItems" label="Please select a additional service"
                            :loading="loadingAdditionalServices" :items="additionalServiceItems" item-value="title"
                            item-title="title" multiple return-object variant="outlined"
                            @update:search="handleSearchAdditionalServices">
                            <template v-slot:selection="data">
                                <v-chip :key="JSON.stringify(data.item)" v-bind="data.attrs" :disabled="data.disabled"
                                    :model-value="data.selected" size="small"
                                    @click:close="data.parent.selectItem(data.item)">
                                    <template v-slot:prepend>
                                        <v-avatar color="orange-darken-4" class="text-white" start>{{
                                            data.item.title.slice(0,
                                                1)
                                        }}</v-avatar>
                                    </template>
                                    {{ data.item.title }}
                                </v-chip>
                            </template>
                        </v-autocomplete>
                    </v-col>
                </v-row>
            </v-container>
        </v-card>
    </v-dialog>
</template>

<script>
import { postData } from '@/utils/httpServices'
import { BASE_URL } from '@/constants/apis/index.js'

export default {
    props: {
        showNewASCard: {
            type: Boolean,
            default: false,
        },
        updateData: { type: Object, default: () => ({}) },
        oldCommodityCode: { type: String, default: () => ({}) },
        oldAdditionalService: { type: String, default: () => ({}) },
        emits: ['update:showNewASCard', 'save', 'update:updateData', 'pkey'],
    },
    data() {
        return {
            selectedCommodities: [],      // Seçilen öğeler
            selectedAdditionalItems: [],  // Seçilen ek hizmetler
            commodityItems: [],
            query: '',       // Arama sorgusu
            additionalServiceItems: [], // Ek hizmet öğeleri
            postData: [], // POST verileri
            loadingCommodities: false,
            loadingAdditionalServices: false,
            dialogTitle: 'Add New Additional Service',
            type: 'create',
            pkey: 0,
        }
    },
    methods: {
        /**
        * @summary Post that fetches all commodities for combobox
        */
        async getCommodities(query) {
            if (query.length >= 3) {
                this.loadingCommodities = true
                try {
                    const response = await postData(`${BASE_URL}GetCommodities`, { Value: query })
                    this.commodityItems = response.Data.map(item => ({
                        title: item.Name,
                        id: item.Id,
                    }))
                } catch (error) {
                    console.error("Error fetching commodities:", error)
                    this.openDialog(ErrorMessageContent, "Bir hata oluştu");
                }
                finally {
                    this.loadingCommodities = false

                }
            }
        },
        /**
        * @summary Post that fetches all additional service for combobox
        */
        async getAdditionalServices(query) {
            if (query.length >= 3) {
                this.loadingAdditionalServices = true
                try {
                    const response = await postData(`${BASE_URL}GetAdditionalServices`, { Value: query })
                    this.additionalServiceItems = response.Data.map(item => ({
                        title: item.Value,
                        id: item.GKey,
                        additionalServiceId: item.AdditionalServiceId,
                    }))
                } catch (error) {
                    console.error("Error fetching additional services:", error)
                    this.openDialog(ErrorMessageContent, "Bir hata oluştu");
                }
                finally {
                    this.loadingAdditionalServices = false
                }
            }
        },
        /**
        * @summary Emit the selected commodity and additional service pkey to the parent component
        */
        async deleteData() {
            const pkey = this.updateData.PKey
            this.$emit('pkey', pkey);
            this.closeOperationPage()

        },
        async handleSearchCommodities(value) {
            this.query = value;
            await this.getCommodities(value);
        },
        handleSearchAdditionalServices(value) {
            this.query = value;
            if (value != null) {
                this.getAdditionalServices(value);
            }
        },
        /**
        * @summary Emit the selected commodity and additional service data to the parent component
        */
        async saveData() {
            if (this.updateData.additionalServiceName !== "") {
                this.type = "update"
            }

            const payload = {
                commodities: this.selectedCommodities,
                additional: this.selectedAdditionalItems,
                type: this.type,
                pkey: this.PKey
            }
            this.$emit('save', payload);
            this.type = "create"
            this.PKey = 0
            this.closeOperationPage()

        },
        closeOperationPage() {
            this.$emit('update:showNewASCard', false)
            this.selectedCommodities = [];
            this.selectedAdditionalItems = [];
            this.postData = [];

            this.payload = {
                commodities: "",
                additional: "",
                type: "created",
                pkey: 0,
            }
        },
        compareById(a, b) {
            if (a && b && typeof a === 'object' && typeof b === 'object') {
                return a.id === b.id;
            }
            return a === b;
        }
    },
    watch: {
        updateData() {
            this.selectedCommodities = [this.updateData.commodityCode] || [];
            console.log(this.updateData);
            this.selectedAdditionalItems = [{
                title: this.updateData.additionalServiceName,
                additionalServiceId: this.updateData.additionalServiceId,
            }];
            this.PKey = this.updateData.PKey || null;
            this.type = this.updateData?.additionalServiceName ? 'update' : 'create';
        }
    },

}
</script>

<style scoped>
.outlined-tonal {
    border: 1px solid #265073;
}
</style>