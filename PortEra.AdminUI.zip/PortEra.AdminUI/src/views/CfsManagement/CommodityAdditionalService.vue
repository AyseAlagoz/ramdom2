<template>
    <v-container>
        <v-card class="pa-2">Commodity - Additional Service</v-card>
        <div class="d-flex justify-end">
            <v-btn variant="outlined" color="#265073" class="ma-2 outlined-tonal" @click="addMethod()">
                Add
            </v-btn>
        </div>
        <div>
            <DxDataGrid id="grid" :show-borders="true" :data-source="dataSource" :repaint-changes-only="true"
                :key="gridKey" :remote-operations="true" :focused-row-index="0" :column-hiding-enabled="false"
                :selection="{ mode: 'single' }" @selectionChanged="onSelectionChanged" :scrolling="{ mode: 'standard' }"
                :ref="dataGridRef" :show-row-lines="true">

                <DxPaging :page-size="10" :page-index="0" />
                <DxPager :show-page-size-selector="true" :show-info="true" />

                <DxColumn data-field="CommodityCode" caption="Commodity Code" :allow-filtering="true"
                    :allow-sorting="false"></DxColumn>
                <DxColumn data-field="AdditionalServiceName" caption="Additional Service Name" :allow-filtering="true"
                    :allow-sorting="false">
                </DxColumn>
                <DxColumn data-field="Created" caption="Created" :allow-filtering="true" :allow-sorting="false">
                </DxColumn>
                <DxColumn data-field="Creator" caption="Creator" :allow-filtering="true" :allow-sorting="false">
                </DxColumn>
                <DxColumn cell-template="buttons" type="buttons" :css-class="'fixed-column'" :width="50"> </DxColumn>
                <template #buttons="{ data }">
                    <v-btn @click="OpenOperationPage(data.data)" icon small :style="{ background: 'transparent' }"
                        class="elevation-0">
                        <v-icon color="green">mdi mdi-pencil</v-icon>
                        <v-tooltip activator="parent" text="Edit" location="bottom"></v-tooltip>
                    </v-btn>
                </template>
            </DxDataGrid>
        </div>

        <AddNewAdditionalService v-model:showNewASCard="showNewASCard" v-model:updateData="updateData"
            v-model:oldCommodityCode="oldCommodityCode" v-model:oldAdditionalService="oldAdditionalService"
            @save="onSaveAdditionalService" @pkey="onDeleteAdditionalService" />


    </v-container>

</template>

<script>
const dataGridRef = 'dataGrid';
import { getData } from "@/utils/httpServices";
import AddNewAdditionalService from ".//AddNewAdditionalService.vue";
import { postData } from '@/utils/httpServices'
import { BASE_URL } from '@/constants/apis/index.js'
import {
    DxDataGrid,
    DxPager,
    DxPaging,
    DxColumn,
} from "devextreme-vue/data-grid";
import MessageContent from "@/components/base/MessageContent.vue";
import ErrorMessageContent from "@/components/base/ErrorMessageContent.vue";

export default {
    inject: ["openDialog"],
    components: {
        DxDataGrid,
        DxPager,
        DxPaging,
        DxColumn,
        AddNewAdditionalService,
    },
    data() {
        return {
            dataSource: [],
            showNewASCard: false,
            updateData: {
                commodityCode: "",
                additionalServiceName: "",
                additionalServiceId: "",
                id: "",
                PKey: ""
            },
            oldCommodityCode: "",
            oldAdditionalService: "",
            dialogTitle: "Edit/Delete Commodity - Additional Service",
            gridKey: 0,
            dataGridRef,
        };
    },
    created() {
        this.getDatas();
    },
    methods: {
        /**
        * @summary Commodity additional service fetches and lists all data
        */
        async getDatas() {
            const url = `https://localhost:60009/GetAdditionalServicesForCommodity`;
            this.dataSource = await getData(url)
        },
        onSelectionChanged(e) {
        },
        cleanDialogComponents() {
        },
        addMethod() {
            this.showNewASCard = true;
            // this.updateData = {
            //     commodityCode: [],
            //     additionalServiceName: "",
            //     additionalServiceId: "",
            //     PKey: 0
            // }
        },
        OpenOperationPage(data) {
            this.showNewASCard = true;

            this.updateData = {
                commodityCode: data.CommodityCode,
                additionalServiceName: data.AdditionalServiceName,
                additionalServiceId: data.AdditionalServiceId,
                PKey: data.PKey,
                id: data.id
            }
            console.log("updateData", this.updateData)
            console.log("data", data)
            this.oldCommodityCode = data.CommodityCode
            this.oldAdditionalService = data.AdditionalServiceName
        },
        closeOperationPage() {
        },
        updateModelValue(updatedData) {
        },
        /**
        * @summary Post for setting additional service for commodity
        */
        async onSaveAdditionalService(payload) {
            try {
                const body = { CommodityAdditionalServices: [] };
                if (payload.type === "update") {
                    const includesOldCommodityCode = payload.commodities.includes(this.oldCommodityCode);
                    if (!includesOldCommodityCode) {
                        await this.onDeleteAdditionalService(payload.pkey);
                    }
                    const includesOldAdditionalService = payload.additional.includes(this.oldAdditionalService);
                    if (!includesOldAdditionalService) {
                        await this.onDeleteAdditionalService(payload.pkey);
                    }
                    if (Array.isArray(payload.additional)) {
                        payload.commodities.forEach(c => {
                            payload.additional.forEach(a => {
                                body.CommodityAdditionalServices.push({
                                    CommodityCode: c?.id ?? c,
                                    AdditionalServiceId: a?.additionalServiceId ?? null,
                                    AdditionalServiceName: a?.title ?? String(payload.additional).replace(/[\[\]]/g, ''),
                                    PKey: payload.pkey,
                                });

                            });
                        });
                    }
                    else {
                        payload.commodities.forEach(c => {
                            body.CommodityAdditionalServices.push({
                                CommodityCode: c?.id ?? c,
                                AdditionalServiceId: payload.additional?.additionalServiceId ?? null,
                                AdditionalServiceName: payload.additional?.title ?? String(payload.additional).replace(/[\[\]]/g, ''),
                                PKey: payload.pkey,
                            });
                        });
                    }

                }
                else {
                    payload.commodities.forEach(c => {
                        payload.additional.forEach(a => {
                            body.CommodityAdditionalServices.push({
                                CommodityCode: c.id,
                                AdditionalServiceId: a.additionalServiceId,
                                AdditionalServiceName: a?.title ?? a,
                            });
                        });
                    });
                }

                const response = await postData(`${BASE_URL}SetAdditionalServiceForCommodity`, body);
                if (response.ResponseCode === 'Success') {
                    this.openDialog(MessageContent, "İşlem başarıyla tamamlandı");
                } else {
                    this.openDialog(ErrorMessageContent, "Kayıt sırasında bir hata oluştu");
                }
                // await this.getDatas();
                this.gridKey++;
            } catch (err) {
                console.error('Save error:', err);
                this.openDialog(ErrorMessageContent, "Bir hata oluştu");
            }

        },
        /**
        * @summary Post for delete additional service for commodity
        */
        async onDeleteAdditionalService(pkey) {
            const PKey = {
                PKey: pkey
            }
            try {
                const response = await postData(`${BASE_URL}SetDeleteAdditionalServiceForCommodity`, PKey);
                if (response.ResponseCode === 'Success') {
                    this.openDialog(MessageContent, "İşlem başarıyla tamamlandı");
                } else {
                    this.openDialog(ErrorMessageContent, "Silme işlemi sırasında bir hata oluştu");
                }

            }
            catch (err) {
                console.error('Save error:', err);
                this.openDialog(ErrorMessageContent, "Bir hata oluştu");
            }
        },


    },
}
</script>