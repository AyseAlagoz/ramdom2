<template>
  <v-container class="mt-4">
    <v-card class="mb-6">
      <v-toolbar color="white" border>
        <v-chip class="ma-2 ml-2" label>ROLE MANAGEMENT</v-chip>
        <v-spacer></v-spacer>
        <v-btn
          @click="insertRoleOpener"
          class="ma-2"
          tile
          outlined
          color="green"
        >
          <v-icon left>mdi-content-save</v-icon>New Role
        </v-btn>
        <v-btn @click="deleteDatas" class="ma-2" tile outlined color="red">
          <v-icon left>mdi-delete</v-icon>Delete Selected Roles
        </v-btn>
      </v-toolbar>
    </v-card>
    <DxDataGrid
      :data-source="dataSource"
      ref="dataGrid"
      :show-borders="true"
      :column-auto-width="true"
      :row-alternation-enabled="true"
      :show-row-lines="true"
      :remote-operations="true"
      :width="'100%'"
      @row-click="selectRow"
      @rowDblClick="updateRoleOpener"
    >
      <DxSelection
        mode="multiple"
        select-all-mode="allPage"
        :allow-select-all="false"
        show-check-boxes-mode="always"
      />
      <DxColumn
        v-for="column in columns"
        :key="column.dataField"
        :data-field="column.dataField"
        :caption="column.caption"
      >
      </DxColumn>
      <DxPaging :page-size="10" />
      <DxPager
        :visible="true"
        :show-page-size-selector="true"
        :allowed-page-sizes="[5, 10, 20]"
      />
    </DxDataGrid>
  </v-container>
  <role-dialog ref="roleDialog" />
</template>
<script>
import {
  DxDataGrid,
  DxColumn,
  DxPaging,
  DxPager,
  DxSelection,
} from "devextreme-vue/data-grid";
import { getData, apiMethod } from "@/utils/httpServices";
import { BASE_URL } from "@/constants/api";
import RoleDialog from "@/components/base/UserManagement/RoleDialog.vue";
import {
  SetUpdateRole,
  SetCreateRole,
  SetDeleteRole,
} from "@/constants/Domain/Request/Class";
import MessageContent from "@/components/base/MessageContent.vue";
import ConfirmContent from "@/components/base/ConfirmContent.vue";

const dataSource = null;

export default {
  name: "UserManagement",
  inject: ["toggleLoadingOverlay", "openDialog"],
  components: {
    DxDataGrid,
    DxPaging,
    DxPager,
    DxColumn,
    RoleDialog,
    DxSelection,
  },
  data() {
    return {
      dataSource,
      columns: [
        { dataField: "Name", caption: "Role Name", width: "1000" },
        { dataField: "AppName", caption: "App Name", width: "1000" },
      ],
      insertData: {
        Name: "",
        AppName: "",
      },
    };
  },
  computed:{
    dataGrid() {
      return this.$refs.dataGrid.instance;
    },
  },
  methods: {
    async getData() {
      const data = await getData(`${BASE_URL}GetRolesPaging`);
      this.dataSource = data;
    },
    insertRoleOpener() {
      this.$refs.roleDialog.dialogOpener({
        header: "New Role",
        buttonText: "Add",
        data: {...this.insertData},
        clickFunc: (data) => this.post(data, "insert"),
      });
    },
    updateRoleOpener(row) {
      const selectedRows = this.dataGrid.getSelectedRowKeys();
      if (selectedRows.length !== 0) {
        this.openDialog(MessageContent, "Please unselect the selected rows to update.");
        return;
      }
      const data = row.data;
      this.$refs.roleDialog.dialogOpener({
        header: "Edit Role",
        buttonText: "Update",
        data,
        clickFunc: (data) => this.post(data, "update"),
      });
    },
    async post(e, type) {
      if(type !== "delete"){
        const { valid } = await this.$refs.roleDialog.$refs.form.validate();
        if(!valid){
          return;
        }
      }

      this.toggleLoadingOverlay();
      try {
        let request;
        if (type === "insert") {
          request = new SetCreateRole(e);
        } else if (type === "update") {
          request = new SetUpdateRole(e);
        } else if (type === "delete") {
          request = new SetDeleteRole(e);
        }
        const { response } = await apiMethod(`${BASE_URL}`, request);

        if (response.ResponseCode == "Success") {
          this.$refs.roleDialog.onCloseClick();
          this.dataGrid.clearSelection();
          await this.getData();
          this.openDialog(MessageContent, response.Message);
        } else {
          this.$refs.roleDialog.closeDialog();
          this.openDialog(MessageContent, response.Message);
        }
      } catch (err) {
        this.openDialog(MessageContent, "Unexpected Error Occured.");
      } finally {
        this.toggleLoadingOverlay();
      }
    },
    deleteDatas() {
      const selectedRows = this.dataGrid.getSelectedRowKeys();
  
      if (selectedRows.length === 0) {
        this.openDialog(MessageContent, "Please select at least one row to delete.");
        return;
      }
      this.openDialog(
        ConfirmContent,
        "Are you sure you want to delete the selected rows?",
        () => {
          this.post(selectedRows, "delete");
        }
      );
    },
    selectRow(e){
       if(!e.isSelected){
        this.dataGrid.selectRows([e.key], true);
      }else{
        this.dataGrid.deselectRows([e.key]);
      }
      
    }
  },
  async created() {
    await this.getData();
  },
};
</script>
