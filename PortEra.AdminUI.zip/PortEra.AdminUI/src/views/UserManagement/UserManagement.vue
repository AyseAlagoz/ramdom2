<template>
  <v-container class="mt-4">
    <v-card class="mb-6">
      <v-toolbar color="white" border>
        <v-chip class="ma-2 ml-2" label>USER MANAGEMENT</v-chip>
        <v-spacer></v-spacer>
        <v-btn
          @click="insertUserOpener"
          class="ma-2"
          tile
          outlined
          color="green"
        >
          <v-icon left>mdi-content-save</v-icon>New User
        </v-btn>
        <v-btn @click="deleteDatas" class="ma-2" tile outlined color="red">
          <v-icon left>mdi-delete</v-icon>Delete Selected Users
        </v-btn>
      </v-toolbar>
    </v-card>
    <DxDataGrid
      :data-source="dataSource"
      ref="dataGrid"
      :show-borders="true"
      :column-auto-width="true"
      :row-alternation-enabled="true"
      :show-row-lines="true"
      :remote-operations="true"
      :width="'100%'"
      @row-click="selectRow"
      @rowDblClick="updateUserOpener"
    >
      <DxFilterRow :visible="false" />
      <DxSelection
        mode="multiple"
        select-all-mode="allPage"
        :allow-select-all="false"
        show-check-boxes-mode="always"
      />
      <DxColumn
        v-for="column in columns"
        :key="column.dataField"
        :data-field="column.dataField"
        :caption="column.caption"
        :allow-sorting="false"
        :allow-filtering="true"
      >
      </DxColumn>
      <DxPaging :page-size="10" />
      <DxPager
        :visible="true"
        :show-page-size-selector="true"
        :allowed-page-sizes="[5, 10, 20]"
      />
    </DxDataGrid>
  </v-container>
  <user-dialog ref="userDialog" :search-user-post="searchUserPost" />
</template>

<script>
import {
  DxDataGrid,
  DxColumn,
  DxPaging,
  DxPager,
  DxSelection,
  DxFilterRow,
} from "devextreme-vue/data-grid";
import { getData, apiMethod } from "@/utils/httpServices";
import { BASE_URL } from "@/constants/api";
import UserDialog from "@/components/base/UserManagement/UserDialog.vue";
import {
  SetUpdateUser,
  SetCreateUser,
  SetDeleteUser,
  GetSelectedUser,
  FindUser,
} from "@/constants/Domain/Request/Class";
import MessageContent from "@/components/base/MessageContent.vue";
import ConfirmContent from "@/components/base/ConfirmContent.vue";

const dataSource = null;

export default {
  name: "UserManagement",
  inject: ["toggleLoadingOverlay", "openDialog"],
  emits: ["login-success"],
  components: {
    DxDataGrid,
    DxPaging,
    DxPager,
    DxColumn,
    UserDialog,
    DxSelection,
    DxFilterRow,
  },
  data() {
    return {
      dataSource,
      columns: [
        { dataField: "FullName", caption: "Full Name" },
        { dataField: "UserName", caption: "User Name" },
        { dataField: "Email", caption: "Email" },
        { dataField: "IsActiveDirectory", caption: "Is Active Directory" },
      ],
      insertData: {
        Email: "",
        UserName: "",
        FullName: "",
        Password: "",
        Roles: [],
      },
    };
  },
  computed: {
    dataGrid() {
      return this.$refs.dataGrid.instance;
    },
  },
  methods: {
    async getData() {
      const data = await getData(`${BASE_URL}GetUsersPaging`);
      this.dataSource = data;
    },
    insertUserOpener() {
      this.$refs.userDialog.dialogOpener({
        header: "New User",
        buttonText: "Add",
        data: { ...this.insertData },
        type: "insert",
        clickFunc: (data) => this.post(data, "insert"),
      });
    },
    async updateUserOpener(row) {
      const selectedRows = this.dataGrid.getSelectedRowKeys();
      if (selectedRows.length !== 0) {
        this.openDialog(
          MessageContent,
          "Please unselect the selected rows to update."
        );
        return;
      }
      const data = row.data;
      const { response } = await apiMethod(
        `${BASE_URL}`,
        new GetSelectedUser(data.PKey)
      );

      this.$refs.userDialog.dialogOpener({
        header: "Edit User",
        buttonText: "Update",
        data: response.Data,
        type: "update",
        clickFunc: (data) => this.post(data, "update"),
      });
    },
    async post(e, type) {
      let roleIds;
      if (type !== "delete") {
        roleIds = e.Roles.map((item) => item.PKey);
        const { valid } = await this.$refs.userDialog.$refs.form.validate();
        if (!valid) {
          return;
        }
      }

      this.toggleLoadingOverlay();
      try {
        let request;
        if (type === "insert") {
          request = new SetCreateUser(e,roleIds);
        } else if (type === "update") {
          request = new SetUpdateUser(e,roleIds);
        } else if (type === "delete") {
          request = new SetDeleteUser(e);
        }
        const { response } = await apiMethod(`${BASE_URL}`, request);

        if (response.ResponseCode == "Success") {
          this.$refs.userDialog.onCloseClick();
          this.dataGrid.clearSelection();
          await this.getData();
          this.openDialog(MessageContent, response.Message);
        } else {
          this.$refs.userDialog.closeDialog();
          this.openDialog(MessageContent, response.Message);
        }
      } catch (err) {
        this.openDialog(MessageContent, "Unexpected Error Occured.");
      } finally {
        this.toggleLoadingOverlay();
      }
    },
    deleteDatas() {
      const selectedRows = this.dataGrid.getSelectedRowKeys();

      if (selectedRows.length === 0) {
        this.openDialog(
          MessageContent,
          "Please select at least one row to delete."
        );
        return;
      }
      this.openDialog(
        ConfirmContent,
        "Are you sure you want to delete the selected rows?",
        () => {
          this.post(selectedRows, "delete");
        }
      );
    },
    selectRow(e) {
      if (!e.isSelected) {
        this.dataGrid.selectRows([e.key], true);
      } else {
        this.dataGrid.deselectRows([e.key]);
      }
    },
    async searchUserPost(userName) {
      const isExist = await apiMethod(`${BASE_URL}`, new FindUser(userName));
      return isExist;
    },
  },
  async created() {
    await this.getData();
  },
};
</script>
