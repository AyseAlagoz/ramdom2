<template>
  <v-footer
    app
    color="#265073"
  >
    <v-chip outlined size="x-small" color="white">
      &copy; ARY Holding {{ getCurrentYear }}
    </v-chip>
  </v-footer>
</template>

<script>
export default {
    computed: {
        getCurrentYear: () => {
            return new Date().getFullYear();
        }
    }
};
</script>
