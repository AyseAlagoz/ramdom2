<template>
  <v-menu min-width="200px" rounded>
    <template v-slot:activator="{ props }">
      <v-chip
        style="margin: 5px"
        color="white"
        variant="outlined"
        size="small"
        v-bind="props"
      >
        <v-icon start icon="mdi-account-settings"></v-icon>
        {{ userInfo.UserName }}
      </v-chip>
    </template>
    <v-card>
      <v-card-text>
        <div class="mx-auto text-center">
          <v-avatar color="#265073" size="small">
            <v-icon icon="mdi-account-circle"></v-icon>
          </v-avatar>
          <h5>{{ userInfo.UserName }}</h5>
          <p class="text-caption mt-1">
            {{ userInfo.Email }}
          </p>
          <v-divider class="my-3"></v-divider>
          <!-- <v-radio-group
            @change="changeLanguage($event)"
            v-model="language"
            inline
          >
            <v-radio class="mx-3" value="tr"
              ><img class="flag-icon" :src="turkeyFlag"
            /></v-radio>
            <v-radio class="ml-1" value="en"
              ><img class="flag-icon" :src="ukFlag" />
            </v-radio>
          </v-radio-group> -->
  
 
          
          <v-divider class="my-3"></v-divider>
          <v-btn rounded variant="text" @click="logOut"> Logout </v-btn>
        </div>
      </v-card-text>
    </v-card>
  </v-menu>
</template>

<script>
export default {
  data: () => ({
    userInfo: {
      UserName: "Murat Temir",
      Email: "murat.temir@yilport.com"
    }
  }),
  methods: {
    logOut() {
      this.$emit("logout");
    },  
 
  },
  props: {
   // userInfo: { type: Object, required: true },
  },
};
</script>

<style scoped>
::deep(.v-selection-control-group) {
  justify-content: center;
}

.selected-image {
  border: 2px solid #2C7865;
  border-radius: 2rem;
  padding: 0.1rem;
  width: 35px;
  height: 34px;
}

/* .flag-icon {
  width: 30px;
  height: 20px;
} */
</style>
