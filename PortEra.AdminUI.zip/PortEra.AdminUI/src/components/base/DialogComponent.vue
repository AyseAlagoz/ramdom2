<template>
  <v-dialog v-model="overlay" persistent no-click-animation>
    <v-card color="white" class="dialog-card">
      <!-- Dinamik olarak yüklenen bileşen -->
      <component
        :is="currentComponent"
        :confirmCallBack="confirmCallBack"
        :cancelCallBack="closeDialog"
        :closeDialog="closeDialog"
        :message="message"
      ></component>
    </v-card>
  </v-dialog>
</template>

<script>
import { markRaw } from "vue";
export default {
  data: () => ({
    overlay: false,
    currentComponent: null,
    dialogWidth: "75%",
    dialogMaxWidth: "800px",
    message: "",
  }),
  watch: {
    currentComponent(newComponent) {
      if (newComponent) {
        this.updateDialogSize(markRaw(newComponent));
      }
    },
  },
  methods: {
    closeDialog() {
      this.overlay = false;
    },
    //TODO cancelCallBack parametresi eklenmeli
    openDialog(
      component,
      message = "",
      confirmCallBack = () => {},
      cancelCallBack
    ) {
      this.confirmCallBack = confirmCallBack;
      this.cancelCallBack = cancelCallBack || this.closeDialog;
      this.overlay = true;
      this.currentComponent = markRaw(component);
      this.message = message;
    },
    updateDialogSize(component) {
      // Burada component'e göre dialog boyutlarını güncelleyebilirsiniz
      // Örneğin, component'in adına göre farklı boyutlar belirleyebilirsiniz
      if (component.name === "SmallComponent") {
        this.dialogWidth = "50%";
        this.dialogMaxWidth = "400px";
      } else if (component.name === "LargeComponent") {
        this.dialogWidth = "90%";
        this.dialogMaxWidth = "1200px";
      } else {
        this.dialogWidth = "75%";
        this.dialogMaxWidth = "800px";
      }
    },
  },
};
</script>

<style scoped>
.dialog-card {
  display: flex;
  flex-direction: column;
  min-height: 150px;
  width: 50%;
  overflow: auto;
  justify-content: center;
  align-items: center;
  margin: auto;
}

/* Dialog'un kendisi için stil ayarları */
.v-dialog {
  display: flex;
  align-items: center; /* Dikeyde ortala */
  justify-content: center; /* Yatayda ortala */
}

/* v-card içeriğinin tamamen görünmesini sağla */
.v-card {
  max-height: 90vh; /* Ekran yüksekliğinin %90'ı kadar maksimum yükseklik */
  overflow-y: auto; /* İçerik taşarsa scrollbar göster */
}
</style>
