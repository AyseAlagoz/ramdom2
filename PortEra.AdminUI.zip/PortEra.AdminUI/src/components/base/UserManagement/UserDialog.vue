<template>
  <v-row justify="center">
    <v-dialog
      v-model="dialog"
      persistent
      width="700"
      style="z-index: 1"
      no-click-animation
    >
      <v-card>
        <v-toolbar color="white" border>
          <v-chip class="ma-2 ml-2" label>{{ header }}</v-chip>
          <v-spacer></v-spacer>

          <v-icon
            size="small"
            color="red"
            start
            icon="mdi-close-octagon-outline"
            @click="onCloseClick"
          ></v-icon>
        </v-toolbar>
        <v-card-text>
          <v-container>
            <v-form ref="form">
              <v-row dense>
                <v-col cols="12" sm="6">
                  <v-text-field
                    variant="outlined"
                    density="compact"
                    label="Full Name"
                    v-model="data.FullName"
                    :rules="reqRules"
                  />
                </v-col>
                <v-col cols="12" sm="6">
                  <v-text-field
                    ref="userNameRef"
                    @update:modelValue=" ()=>{insertBool = false; isAdBool = true}"
                    variant="outlined"
                    density="compact"
                    label="User Name"
                    v-model="data.UserName"
                    :rules="userNameRule"
                  />
                </v-col>
                <v-col cols="12" sm="6">
                  <v-text-field
                    variant="outlined"
                    density="compact"
                    label="Email"
                    v-model="data.Email"
                    :rules="reqRules"
                  />
                </v-col>
                <v-col cols="12" sm="6">
                  <v-btn v-if="!insertBool" block @click="searchUser"
                    >Search user name</v-btn
                  >
                  <v-text-field v-else-if="!isAdBool" 
                    variant="outlined"
                    density="compact"
                    label="Password"
                    v-model="data.Password"
                    :rules="reqRules"
                    :type="passwordBool ? 'text' : 'password'"
                     @click:append-inner="passwordBool = !passwordBool"
                     :append-inner-icon="passwordBool ? 'mdi-eye-off' : 'mdi-eye'"
                  />
                </v-col>
              </v-row>
            </v-form>
            <v-row>
              <v-container>
                <v-btn 
                @click="roleDialogOpener"
                class="newButtonStyle">Add Role</v-btn>
                <DxDataGrid :show-borders="true" :data-source="dataSource">
                  <DxPaging :page-size="10" :page-index="0" />

                  <dx-pager :show-page-size-selector="true" :show-info="true" />

                  <DxColumn
                    v-for="column in columns"
                    :key="column"
                    :data-field="column.dataField"
                    :visible="column.visible"
                    :caption="column.caption"
                  >
                  </DxColumn>
                  <DxColumn
                    caption="Actions"
                    cell-template="action-cell"
                    width="80" 
                  >
               
                  </DxColumn>
                  <template #action-cell="{ data }">
                    <v-btn variant="solo" density="compact" @click="deleteRole(data.data)"> <v-icon color="red">mdi-delete</v-icon></v-btn>

                  </template>
                </DxDataGrid>
              </v-container>
            </v-row>
          </v-container>
        </v-card-text>
        <v-card-actions class="justify-center align-center">
          <v-btn
            v-if="insertBool"
            class="ma-2"
            variant="tonal"
            color="green"
            @click="clickFunc(data)"
          >
            <v-icon left>mdi-content-save</v-icon>{{ buttonText }}
          </v-btn>
          <v-btn class="ma-2" variant="tonal" color="red" @click="onCloseClick">
            <v-icon left>mdi-close-octagon-outline</v-icon>Cancel
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-row>
  <user-role-dialog  ref="userRoleDialogRef" @saveRoles="fillGrid"/>
</template>

<script>
import {
  DxDataGrid,
  DxPager,
  DxPaging,
  DxColumn,
} from "devextreme-vue/data-grid";
import UserRoleDialog from "./UserRoleDialog.vue";

const dataSource = null;

export default {
  inject: ["toggleLoadingOverlay"],
  components: {
    DxDataGrid,
    DxColumn,
    DxPaging,
    DxPager,
    UserRoleDialog
  },
  props: {
    searchUserPost: {
      type: Function,
      default: () => {},
    },
  },
  data: () => ({
    dataSource,
    dialog: false,
    header: "",
    data: {
      FullName: "",
      UserName: "",
      Password: "",
      Email: "",
      Roles: [],
    },
    columns: [
      { dataField: "Name", caption: "Roles Name" },
      { dataField: "AppName", caption: "App Name" },
    ],
    buttonText: "",
    clickFunc: null,
    reqRules: [(v) => !!v || "Required field."],
    dataArray: [],
    insertBool: false,
    validBool: false,
    validateString:"",
    passwordBool:false,
    isAdBool:true,
    userNameKeeper:"",

  }),
  computed: {
    userNameRule() {
      return [
        value => {
        if (!this.validBool && value.trim() != "") { 
            return true; 
        }
        return this.validBool ? this.validateString : "User name is required."; 
        }
      ];
    },
  },
  methods: {
    dialogOpener(param) {
      this.header = param.header;
      this.buttonText = param.buttonText;
      this.data = param.data;
      this.dialog = true;
      this.type = param.type;
      if(param.type == "update"){
        this.insertBool = true;
        this.isAdBool = true;
        this.userNameKeeper = param.data.UserName;
      }
      this.dataSource = [...param.data.Roles];
      this.clickFunc = param.clickFunc;
    },
    onCloseClick() {
      this.dialog = false;
      this.data = {
        FullName: "",
        UserName: "",
        Password: "",
        Email: "",
        Roles: [],
      };
      this.header = null;
      this.buttonText = "";
      this.clickFunc = null;
    },
    async searchUser() {// todo
      if(this.data.UserName == this.userNameKeeper) {
        this.validBool = false;
        this.validateString = "";
        await this.$refs.userNameRef.validate();
        this.insertBool = true
        return;
      }
      const valid = await this.$refs.userNameRef.validate();
      if (valid.length > 0) {
        return;
      }
      const { response } = await this.searchUserPost(this.data.UserName);

      if(response.ResponseCode == "Fail") {
        this.validBool = true;
        this.validateString = response.Message;
        await this.$refs.userNameRef.validate();
        this.validBool = false;
        this.validateString = "";
        return;
      }

      else if(response.ResponseCode == "Success") {
        this.validBool = false;
        this.validateString = "";
        await this.$refs.userNameRef.validate();
        if (!response.Data) {
          this.isAdBool = false;
        }
        else {
          this.isAdBool = true;
        }
      }
      this.insertBool = true;
    },
    roleDialogOpener() {
      this.$refs.userRoleDialogRef.dialogOpener();
    },
    fillGrid(data) {
      const filtereItems = data.filter((item) => {
        const PKey = item.PKey;
        if (this.dataSource.some((obj) => obj.PKey === PKey)) {
          return false;
        }
        return true;
      });
      this.data.Roles = [...this.data.Roles,...filtereItems];
      this.dataSource = [...this.dataSource,...filtereItems];
    },
    deleteRole(data){
  
      this.data.Roles = this.data.Roles.filter((item) => item.PKey !== data.PKey);
      this.dataSource = this.dataSource.filter((item) => item.PKey !== data.PKey); 
    }
  },
};
</script>

<style scoped>
.custom-card-actions {
  display: flex;
  justify-content: center; /* Yatayda ortala */
  align-items: center; /* Dikeyde ortala */
  width: 100%; /* Tam genişlik */
}
.newButtonStyle{
  display: flex;
  margin-bottom: 10px;
  justify-self: end;
}
</style>
