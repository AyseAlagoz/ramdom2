<template>
  <v-row justify="center">
    <v-dialog
      v-model="dialog"
      persistent
      width="500"
      style="z-index: 2"
      no-click-animation
    >
      <v-card>
        <v-toolbar color="white" border>
          <v-chip class="ma-2 ml-2" label>{{ header }}</v-chip>
          <v-spacer></v-spacer>

          <v-icon
            size="small"
            color="red"
            start
            icon="mdi-close-octagon-outline"
            @click="onCloseClick"
          ></v-icon>
        </v-toolbar>
        <v-card-text>
          <v-container>
            <v-row>
              <v-col cols="6">
                <v-btn @click="comboOpener('app')">Add role as app</v-btn>
              </v-col>
              <v-col cols="6">
                <v-btn @click="comboOpener('role')">Add role as role</v-btn>
              </v-col>
            </v-row>
            <v-row v-if="comboBool" class="mt-4">
              <v-container>
                <v-autocomplete
                  v-model="selectedRoles"
                  :items="filteredItems"
                  :item-title="type === 'app' ? 'AppName' : 'Name'"
                  item-value="PKey"
                  label="Role"
                  @update:search="searchEvent"
                  @update:modelValue="selectRoleEvent"
                  multiple
                  variant="outlined"
                  density="compact"
                  ref="roleRef"
                  return-object
                />
              </v-container>
            </v-row>
          </v-container>
        </v-card-text>
        <v-card-actions class="justify-center align-center">
          <v-btn class="ma-2" variant="tonal" color="green" @click="saveRoles">
            <v-icon left>mdi-content-save</v-icon> Save
          </v-btn>
          <v-btn class="ma-2" variant="tonal" color="red" @click="onCloseClick">
            <v-icon left>mdi-close-octagon-outline</v-icon>Cancel
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-row>
</template>

<script>
import {
  DxDataGrid,
  DxPager,
  DxPaging,
  DxColumn,
} from "devextreme-vue/data-grid";
import { apiMethod } from "@/utils/httpServices";
import { BASE_URL } from "@/constants/api";
import { GetRoles, GetRolesByApp } from "@/constants/Domain/Request/Class";

export default {
  inject: ["toggleLoadingOverlay"],
  components: {
    DxDataGrid,
    DxColumn,
    DxPaging,
    DxPager,
  },
  props: {},
  data: () => ({
    dialog: false,
    comboBool: false,
    header: "Role Dialog",
    type: "",
    comboItems: [],
    selectedRoles: [], //for displaying selected roles in the dialog
    realSelecteds: [], //for keeping selected roles
  }),
  computed: {
    filteredItems() {
      if (this.type === "role") return this.comboItems;
      else if (this.type === "app") {
        const seen = new Set();
        return this.comboItems.filter((item) => {
          const name = item.AppName;
          if (seen.has(name)) {
            return false;
          }
          seen.add(name);
          return true;
        });
      }
      return [];
    },
  },
  methods: {
    dialogOpener() {
      this.dialog = true;
    },
    comboOpener(type) {
      this.type = type;
      this.comboBool = true;
      this.selectedRoles = []; 
      this.realSelecteds = []; 
      this.comboItems = [];
    },
    onCloseClick() {
      this.dialog = false;
      this.clickFunc = null;
    },
    async searchEvent(e) {
      if (this.type === "app") {
        this.searchRoleByApp(e);
      } else if (this.type === "role") {
        this.searchRole(e);
      }
    },
    async selectRoleEvent(appNames) {
      if (this.type !== "app") {
        this.realSelecteds = [...appNames]; // Store the selected roles
        this.selectedRoles = [...appNames]; // Update the selected roles for display
        return
      };
      const selectedItems = appNames.map((item) => item.AppName);
      const uniqueItems = [...new Set(selectedItems)];
      const filteredItems = this.comboItems.filter((item) =>
        uniqueItems.includes(item.AppName)
      );
      this.realSelecteds = [...filteredItems]
    },
    async searchRole(e) {
      const { response } = await apiMethod(`${BASE_URL}`, new GetRoles(e));
      this.comboItems = response.Data;
    },
    async searchRoleByApp(e) {
      const { response } = await apiMethod(`${BASE_URL}`, new GetRolesByApp(e));
      this.comboItems = response.Data;
    },
    saveRoles(){
      this.onCloseClick(); 
      this.$emit("saveRoles", this.realSelecteds); 
    },
  },
};
</script>

<style scoped>
.custom-card-actions {
  display: flex;
  justify-content: center; /* Yatayda ortala */
  align-items: center; /* Dikeyde ortala */
  width: 100%; /* Tam genişlik */
}
</style>
