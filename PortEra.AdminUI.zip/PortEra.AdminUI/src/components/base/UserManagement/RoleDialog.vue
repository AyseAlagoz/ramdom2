<template>
  <v-row justify="center">
    <v-dialog
      v-model="dialog"
      persistent
      width="700"
      style="z-index: 1"
      no-click-animation
    >
      <v-card>
        <v-toolbar color="white" border>
          <v-chip class="ma-2 ml-2" label>{{ header }}</v-chip>
          <v-spacer></v-spacer>

          <v-icon
            size="small"
            color="red"
            start
            icon="mdi-close-octagon-outline"
            @click="onCloseClick"
          ></v-icon>
        </v-toolbar>
        <v-card-text>
          <v-container>
            <v-form ref="form">
            <v-row>
                <v-col>
                  <v-text-field
                  variant="outlined"
                  density="compact"
                  label="Role Name"
                  v-model="data.Name"
                  :rules="reqRules"
                  />
                </v-col>
                <v-col>
                  <v-text-field
                  variant="outlined"
                  density="compact"
                  label="App Name"
                  v-model="data.AppName"
                  :rules="reqRules"
                  />
                </v-col>
           
            </v-row>
            </v-form> 
          </v-container>
        </v-card-text>
        <v-card-actions class="justify-center align-center">
          <v-btn
            class="ma-2"
            variant="tonal"
            color="green"
            @click="clickFunc(data)"
          >
            <v-icon left>mdi-content-save</v-icon>{{ buttonText }}
          </v-btn>
          <v-btn class="ma-2" variant="tonal" color="red" @click="onCloseClick">
            <v-icon left>mdi-close-octagon-outline</v-icon>Cancel
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-row>
</template>

<script>
export default {
  data: () => ({
    dialog: false,
    header: "",
    data: {
      Name: "",
      AppName: "",
    },
    buttonText: "",
    clickFunc: null,
    reqRules: [(v) => !!v || "Required field."],
  }),
  methods: {
    dialogOpener(param) {
      this.header = param.header;
      this.buttonText = param.buttonText;
      this.data = param.data;
      this.dialog = true;
      this.clickFunc = param.clickFunc;
    },
    onCloseClick() {
      this.dialog = false;
      this.data = {
        Name: "",
        AppName: "",
      };
      this.header = null;
      this.buttonText = "";
      this.clickFunc = null;
    },
  },
};
</script>

<style scoped>
.custom-card-actions {
  display: flex;
  justify-content: center; /* Yatayda ortala */
  align-items: center; /* Dikeyde ortala */
  width: 100%; /* Tam genişlik */
}
</style>
