<template>

    <v-container>

        <span class="customMessage">{{ message }}</span>
        <v-btn
        block
        border
        variant="text"
        rounded
        size="65"
        class="mt-3 customButton"
        @click="closeDialog"><span class="closeButton">Ok</span></v-btn>
    </v-container>

</template>
<script>
export default {
    props: {
        message: {
            type: String,
            default: ''
        },
        closeDialog: {
            type: Function,
            default: () => {}
        }
    },
}

</script>

<style scoped>
.customMessage{
    white-space: pre-wrap;
    font-size: 2rem;
    display: flex;
    justify-content: center;
}
</style>