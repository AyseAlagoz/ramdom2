<template>
  <v-navigation-drawer v-model="drawer" width="325" app>
    <v-list :lines="false" density="compact" nav>
      <v-list-group v-for="(item, i) in items" :key="i" :value="item">
        <template v-slot:activator="{ props }">
          <v-list-item v-bind="props" :to="item.link" :title="item.text" color="teal-darken-1"
            rounded="xl"></v-list-item>
        </template>

        <v-list-item-title v-for="itemdetail in item.subItem" :key="itemdetail.id" :value="itemdetail">
          <template v-if="itemdetail.childItem">
            <v-list-group>
              <template v-slot:activator="{ props }">
                <v-list-item v-bind="props" :title="itemdetail.text" color="teal-darken-1" rounded="xl"></v-list-item>
              </template>
              <v-list-item v-for="childItem in itemdetail.childItem" :key="childItem.id" :title="childItem.text"
                color="teal-darken-1" rounded="xl">
              </v-list-item>
            </v-list-group>
          </template>
          <template v-else>
            <v-list-item :title="itemdetail.text" :to="itemdetail.link" color="teal-darken-1" rounded="xl" nav>
            </v-list-item>
          </template>
        </v-list-item-title>
      </v-list-group>
    </v-list>
  </v-navigation-drawer>
</template>

<script>
export default {
  data: () => ({
    drawer: true,
    items: [
      {
        text: "Auth Management",
        subItem: [
          {
            text: 'User Management', icon: 'mdi-account', id: 1, child: false, link:
              "/usermanagement",
          },
          {
            text: 'Role Management', icon: 'mdi-alpha-r-box-outline', id: 1,  child: false, link:
              "/rolemanagement",
          },
        ]
      },
      {
        text: "CFS Management",
        subItem: [
          // {
          //   text: 'Add Additional Service', icon: 'mdi-warehouse', id: 1, child: false, child: false, link:
          //     "/addAdditionalService",
          // },
          {
            text: 'Commodity - Additional Service', icon: 'mdi-warehouse', id: 1, child: false, child: false, link:
              "/commodityAdditionalService",
          },
        ]

      },
    ],
  }),
  methods: {
    clickNavbar() {
      this.drawer = !this.drawer
    }
  }
};
</script>
