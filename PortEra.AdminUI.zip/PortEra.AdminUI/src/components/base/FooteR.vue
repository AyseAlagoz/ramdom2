<template>
  <v-footer app color="white">
    <v-container>
      <v-row no gutters justify="start">
        <v-col class="text-left" cols="9" sm="10">
        </v-col>
      </v-row>
    </v-container>
  </v-footer>
</template>

<script>

export default {
  components: {
    
  },
  data(){
    return{
    }
  },
  computed:{
  },
};
</script>
