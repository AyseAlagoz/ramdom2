<template>
  <v-card elevation="0">
    <v-card-text class="text--primary" center>
      <span class="message">{{ message }}</span>
    </v-card-text>
    <v-card-actions>
      <v-row
        ><v-col cols="6">
          <v-btn
            size="60"
            variant="flat"
            color="green"
            block
            @click="confirmCallBack"
            >Yes</v-btn
          ></v-col
        >
        <v-col cols="6">
          <v-btn
            color="red"
            size="60"
            variant="flat"
            block
            @click="cancelCallBack"
            >No</v-btn
          ></v-col
        >
      </v-row>
    </v-card-actions>
  </v-card>
</template>

<script>
export default {
  name: "ConfirmContent",
  props: {
    confirmCallBack: {
      type: Function,
      default: () => {
   
      },
    },
    cancelCallBack: {
      type: Function,
      default: () => {
       
      },
    },
    message: {
      type: String,
      default: "",
    },
  },
};
</script>

<style scoped>
.confirm-dialog {
  max-width: 90vw;
  width: 320px;
  text-align: center;
  border-radius: 12px;
}

.message {
  font-size: 1.6rem;
  font-weight: bold;
}

.button-row {
  display: flex;
  justify-content: center;
  gap: 8px;
}
</style>
