<template>
  <v-container>
    <v-row
      ><v-col>
        <v-img
          rounded
          height="40px"
          :src="imageSrc"
          @click="goHome"
        ></v-img> </v-col
    ></v-row>
  </v-container>
</template>

<script>
export default {
  data() {
    return {
      imageSrc: process.env.BASE_URL + "img/gemport.jpg",
    };
  },
  methods:{
    goHome(){
      this.$router.push('/roro');
    }
  }
};
</script>
