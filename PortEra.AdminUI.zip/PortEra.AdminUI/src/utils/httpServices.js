import { getItems } from "@/CommonVueCore/src/services/devExtremeService/basicDevExtremeService";
import Operations from "./Operations";
import { post, api } from "@/CommonVueCore/src/services/httpService/JsonServiceClient/basicServiceClient.js";

export async function getData(url) {
    return await getItems(url, Operations.getHeaders());
}

export async function postData(url, data, headers = null) {
    if (headers === null) {
        headers = Operations.getHeaders();
    }

    function getHeader(client) {
        client.bearerToken = Operations.getToken();
    }
    return await post(url, data, headers, getHeader);
}

export async function apiMethod(url, data, headers = null) {
    if (headers === null) {
        headers = Operations.getHeaders();
    }

    function getHeader(client) {
        client.bearerToken = Operations.getToken();
    }
    return await api(url, data, headers,getHeader);
}

export async function logIn(url, data) {
    return await post(url, data);
}