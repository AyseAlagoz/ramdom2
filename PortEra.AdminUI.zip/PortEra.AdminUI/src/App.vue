<template>
  <v-app>
    <v-container
      fluid
      style="
        width: 100%;
        height: 100%;
        padding: 0;
        margin-left: 0;
        margin-right: 0;
        z-index: 1;
      "
    >
      <!-- #265073 -->

      <v-app-bar
        density="compact"
        app
        color="#265073"
        dark
        v-if="isAuthenticated"
      >
        <v-app-bar-nav-icon @click="clickNavbar" fixed>
        </v-app-bar-nav-icon>
        <v-toolbar-title
          style="width: 170px"
          class="hidden-sm-and-down ml-0 pl-4"
        >
          <span @click="goHomepage()" style="cursor: pointer"> PortEra Admin Paneli</span>
        </v-toolbar-title>
        <v-spacer></v-spacer>
        <user-menu @logout="logOut"/>
      </v-app-bar>

      <nav-bar v-if="isAuthenticated" ref="navbarRef"/>

      <v-main>
        <v-container
          style="
            width: 100%;
            height: 100%;
            padding: 0;
            margin-left: 0;
            margin-right: 0;
            max-width: 100%;
          "
        >
          <!-- <router-view v-slot="{ Component }">
            <keep-alive>
              <component :is="Component"></component>
            </keep-alive>
          </router-view> -->
          <router-view @loginSuccess="logIn"></router-view>
        </v-container>
      </v-main>

      <footer-component v-if="isAuthenticated" />
    </v-container>
  </v-app>

  <LoadingOverlay ref="loadingOverlayRef" />
  <DialogComponent ref="dialogRef" />

</template>

<script>
import LoadingOverlay from "@/components/base/LoadingOverlay.vue";
import DialogComponent from "@/components/base/DialogComponent.vue";
import UserMenu from "@/components/base/UserMenu.vue";
import NavBar from "@/components/base/NavBar.vue";
import FooterComponent from "@/components/base/FooterComponent.vue";
import Operation from "@/utils/Operations.js";
export default {
  name: "App",
  emits: ["loginSuccess"],
  components: {
    UserMenu,
    NavBar,
    FooterComponent,
    LoadingOverlay,
    DialogComponent,
  },
  data: () => ({
    drawer: true,
    authenticated: localStorage.getItem("isAuthenticated") === "true",
  }),
  methods: {
    toggleLoadingOverlay() {
      this.$refs.loadingOverlayRef.toggle();
    },
    clickNavbar() {
      this.$refs.navbarRef.clickNavbar();
    },
    openDialog(
      component,
      message = "",
      confirmCallBack = () => {},
      cancelCallBack = () => {}
    ) {
      this.$refs.dialogRef.openDialog(
        component,
        message,
        confirmCallBack,
        cancelCallBack
      );
    },
    closeDialog() {
      this.$refs.dialogRef.closeDialog();
    },
    goHomepage() {
      this.$router.push("/");
    },
    logIn() {
      this.authenticated = true;
    },
    logOut(){
      Operation.logOut();
      this.authenticated = false;
      this.$router.push("/login");
    }
  },
  computed: {
    isAuthenticated() {
      return this.authenticated;
    },
  },
  provide() {
    return {
      toggleLoadingOverlay: this.toggleLoadingOverlay,
      openDialog: this.openDialog,
      closeDialog: this.closeDialog,
    };
  },
};
</script>
