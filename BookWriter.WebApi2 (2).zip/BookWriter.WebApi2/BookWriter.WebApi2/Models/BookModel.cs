﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace BookWriter.WebApi2.Models
{
    public class BookModel
    {
        [Key]
        public int BookId { get; set; }
        public string BookName { get; set; }

        [ForeignKey("WriterModel")]
        public int WriterId { get; set; }

        //[JsonIgnore]
        //[IgnoreDataMember]
        public WriterModel WriterModel { get; set; }
    }
}
