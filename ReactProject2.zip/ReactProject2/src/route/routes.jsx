import { createBrowserRouter } from "react-router-dom";
import Layout from '../global/Layout'
import Home from '../components/Home'
import List from '../components/List'
import About from '../components/About'
import Login from '../components/LoginPage'
import Sub2 from '../components/Sub2'
import React from 'react';
import TreeView from "../components/TreeView";

export const router = createBrowserRouter([
    {
        path: "/",
        element: <Layout />,
        children: [
            { path: "/", element: <Home /> },
            { path: "/list", element: <List /> },
            { path: "/treeview", element: <TreeView /> },
            { path: "/about", element: <About /> },
            { path: "/sub2", element: <Sub2 /> }
        ],
    },
    { path: "/loginPage", element: <Login /> },
]);
