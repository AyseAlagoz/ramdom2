import React, { createContext, useContext, useState } from 'react'

const snackbarContext = createContext();

export const useSnackbar = () => {
    return useContext(snackbarContext)
}

export const SnackbarProvider = ({ children }) => {
    const [snackbar, setSnackbar] = useState({
        isOpen: false,
        message: '',
        severity: ''
    });

    const openSnackbar = (message, severity) => {
        setSnackbar({ isOpen: true, message, severity })
    }

    const closeSnackbar = () => {
        setSnackbar({ ...snackbar, isOpen: false })
    }

    return (
        <snackbarContext.Provider value={({ snackbar, openSnackbar, closeSnackbar })}>
            {children}
        </snackbarContext.Provider>
    )
}