import axios from "axios";


export const login = async (uri, data) => {
    const response = await axios.post(uri, data)
    localStorage.setItem('accessToken', response.data.accessToken);
}

export const post = async (uri, data) => {
    const response = await axios.post(uri, data)
}

export const get = async (uri) => {
    const response = await axios.get(uri)
    return response
}