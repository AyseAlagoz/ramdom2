// import { Routes, Route, useNavigate } from 'react-router-dom';
// import Home from '..//components/Home';
// import About from '..//components/About';
// import Setting from '..//components/Setting';
// import Layout from './Layout';
// import List from '../components/List';
// import Sub2 from '..//components/Sub2';
// import LoginPage from '../components/LoginPage';
// import { useEffect, useState } from 'react';


// function AppRoutes() {

//     return (
//         <Routes>
//             <Route element={<Layout />}>
//                 <Route path="/" element={<Home />} />
//                 <Route path="/about" element={<About />} />
//                 <Route path="/setting" element={<Setting />} />
//                 <Route path="/list" element={<List />} />
//                 <Route path="/sub2" element={<Sub2 />} />
//             </Route>
//             <Route path="/loginPage" element={<LoginPage />} />

//         </Routes>
//     );
// }

// export default AppRoutes;
