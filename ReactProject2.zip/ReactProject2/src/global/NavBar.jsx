import * as React from 'react';
import { styled, useTheme } from '@mui/material/styles';
import Box from '@mui/material/Box';
import MuiDrawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import Divider from '@mui/material/Divider';
import IconButton from '@mui/material/IconButton';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import InboxIcon from '@mui/icons-material/MoveToInbox';
import { CssBaseline } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useAppStore } from '../globalState/appStore';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

const drawerWidth = 240;

const openedMixin = (theme) => ({
    width: drawerWidth,
    transition: theme.transitions.create('width', {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.enteringScreen,
    }),
    overflowX: 'hidden',
});

const closedMixin = (theme) => ({
    transition: theme.transitions.create('width', {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: 'hidden',
    width: `calc(${theme.spacing(7)} + 1px)`,
    [theme.breakpoints.up('sm')]: {
        width: `calc(${theme.spacing(8)} + 1px)`,
    },
});

const DrawerHeader = styled('div')(({ theme }) => ({
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: theme.spacing(0, 1),
    ...theme.mixins.toolbar,
}));

const Drawer = styled(MuiDrawer, { shouldForwardProp: (prop) => prop !== 'open' })(
    ({ theme }) => ({
        width: drawerWidth,
        flexShrink: 0,
        whiteSpace: 'nowrap',
        boxSizing: 'border-box',
        variants: [
            {
                props: ({ open }) => open,
                style: {
                    ...openedMixin(theme),
                    '& .MuiDrawer-paper': openedMixin(theme),
                },
            },
            {
                props: ({ open }) => !open,
                style: {
                    ...closedMixin(theme),
                    '& .MuiDrawer-paper': closedMixin(theme),
                },
            },
        ],
    }),
);

const menuItems = [
    {
        title: "Home",
        icon: <InboxIcon />,
        path: "/",
        submenu: [
            { title: "List", path: "/list", icon: <InboxIcon /> },
            { title: "Submenu 2", path: "/sub2", icon: <InboxIcon /> }
        ]
    },
    {
        title: "About",
        icon: <InboxIcon />,
        path: "/about",
        submenu: []
    },
    {
        title: "TreeView",
        icon: <InboxIcon />,
        path: "/treeview",
        submenu: []
    }
];

export default function NavBar() {
    const theme = useTheme();
    const navigate = useNavigate();
    const open = useAppStore((state) => state.dopen)

    const [expanded, setExpanded] = React.useState({ home: false, about: false });

    const handleExpandClick = (menu) => {
        setExpanded((prev) => ({ ...prev, [menu]: !prev[menu] }));
    };

    return (
        <Box sx={{ display: 'flex' }}>
            <CssBaseline />
            <Drawer variant="permanent" open={open}>
                <DrawerHeader>
                    <IconButton>
                        {theme.direction === 'rtl' ? <ChevronRightIcon /> : <ChevronLeftIcon />}
                    </IconButton>
                </DrawerHeader>
                <Divider />
                <List>
                    {menuItems.map((item, index) => (
                        <React.Fragment key={item.title}>
                            <ListItem disablePadding sx={{ display: 'block' }}>
                                <ListItemButton onClick={() => item.submenu.length > 0 ? handleExpandClick(index) : navigate(item.path)}
                                    sx={{
                                        borderRadius: '30px',
                                        backgroundColor: location.pathname === item.path ? 'rgba(0, 123, 255, 0.3)' : 'transparent',
                                        color: location.pathname === item.path ? 'rgba(0, 123, 255, 1)' : 'inherit',
                                        '& .MuiListItemIcon-root': {
                                            color: location.pathname === item.path ? 'rgba(0, 123, 255, 1)' : 'inherit',
                                        },
                                        '&:hover': {
                                            backgroundColor: 'rgba(0, 123, 255, 0.1)',
                                        },
                                    }}>
                                    <ListItemIcon>{item.icon}</ListItemIcon>
                                    <ListItemText primary={item.title} />
                                    {item.submenu.length > 0 && (
                                        expanded[index] ? <ExpandLessIcon /> : <ExpandMoreIcon />
                                    )}
                                </ListItemButton>
                                {item.submenu.length > 0 && expanded[index] && (
                                    <List component="div" disablePadding>
                                        {item.submenu.map((subItem) => (
                                            <ListItemButton key={subItem.title} onClick={() => navigate(subItem.path)}
                                                sx={{
                                                    pl: 4,
                                                    borderRadius: '30px',
                                                    backgroundColor: location.pathname === subItem.path ? 'rgba(0, 123, 255, 0.1)' : 'transparent',
                                                    color: location.pathname === subItem.path ? 'rgba(0, 123, 255, 1)' : 'inherit',
                                                    '& .MuiListItemIcon-root': {
                                                        color: location.pathname === subItem.path ? 'rgba(0, 123, 255, 1)' : 'inherit',
                                                    },
                                                    '&:hover': {
                                                        backgroundColor: 'rgba(0, 123, 255, 0.1)',
                                                    },
                                                }}>
                                                <ListItemIcon>{item.icon}</ListItemIcon>
                                                <ListItemText primary={subItem.title} />
                                            </ListItemButton>
                                        ))}
                                    </List>
                                )}
                            </ListItem>
                        </React.Fragment>
                    ))}
                </List>
            </Drawer>

        </Box>
    );
}
