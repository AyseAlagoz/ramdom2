import React, { useEffect, useState } from 'react';
import AppBar from './AppBar';
import NavBar from './NavBar';
import { Box } from '@mui/material';
import { Outlet, useNavigate } from 'react-router-dom';

function Layout({ children }) {
    const navigate = useNavigate();
    // localStorage.setItem('accessToken', "")
    const token = localStorage.getItem('accessToken');

    // // const [isAuthenticated, setIsAuthenticated] = useState(null);

    useEffect(() => {
        if (!token || token === "") {
            // setIsAuthenticated(false);
            navigate('/loginPage');
        }
        // } else {
        //     setIsAuthenticated(true);
        // }
    }, []);

    // if (!token || token === "") {
    //     return null;
    // }
    return (
        <>
            <AppBar />
            <Box height={30} />
            <Box sx={{ display: 'flex' }}>
                <NavBar />
                <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
                    <Outlet />
                </Box>
            </Box>
        </>
    );
}

export default Layout;