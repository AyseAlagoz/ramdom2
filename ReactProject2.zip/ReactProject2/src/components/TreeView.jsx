import React, { useEffect, useState, useRef, useMemo } from 'react';
import { TextField, Box } from '@mui/material';
import { TreeItem } from '@mui/x-tree-view/TreeItem';
import { SimpleTreeView as TreeView } from '@mui/x-tree-view/SimpleTreeView';
import AddIcon from '@mui/icons-material/Add';
import CheckIcon from '@mui/icons-material/Check';
import CloseIcon from '@mui/icons-material/Close';
import { styled } from '@mui/material/styles';

function DynamicTreeTextFields() {
  const [fields, setFields] = useState([
    { id: 1, parentId: null, value: 'Maslak', children: [] },
    { id: 2, parentId: null, value: 'Gebze e5', children: [] },
    { id: 3, parentId: null, value: 'Gebze Liman', children: [] },
    { id: 4, parentId: null, value: 'Gemlik Gübre Bursa', children: [{ id: 5, parentId: 1, value: 'Gübre Fabrika', children: [] }] }
  ]);

  const inputRefs = useRef({});

  const getAllIds = (nodes) => {
    return nodes.reduce((acc, node) => {
      acc.push(String(node.id));
      if (node.children) {
        acc.push(...getAllIds(node.children));
      }
      return acc;
    }, []);
  };

  const [expandedItems, setExpandedItems] = useState(() => getAllIds(fields));

  const handleAddField = (parentId) => {
    const newField = {
      id: Math.random(),
      parentId: parentId,
      value: '',
      isNew: true,
      children: []
    };

    // console.log(parentId)
    // console.log(newField)

    const addFieldRecursively = (fields) => {
      return fields.map(field => {
        if (field.id === parentId) {
          return { ...field, children: [...field.children, newField] };
        }
        if (field.children.length > 0) {
          return { ...field, children: addFieldRecursively(field.children) };
        }
        return field;
      });
    };

    setFields(addFieldRecursively(fields));

    // setExpandedItems((prevExpanded) =>
    //   prevExpanded.includes(String(parentId))
    //     ? prevExpanded
    //     : [...prevExpanded, String(parentId)]
    // );

    setExpandedItems((prevExpanded) => {
      const newExpandedItems = new Set(prevExpanded);
      newExpandedItems.add(String(parentId));
      newExpandedItems.add(String(newField.id));
      return Array.from(newExpandedItems);
    });
  };

  const handleFieldChange = (id, value) => {
    const updateFieldRecursively = (fields) => {
      return fields.map(field => {
        if (field.id === id) {
          return { ...field, isNew: true, value };
        }
        if (field.children.length > 0) {
          return { ...field, children: updateFieldRecursively(field.children) };
        }
        return field;
      });
    };

    setFields(updateFieldRecursively(fields));
  };

  const handleSaveField = (id) => {
    const updateFieldRecursively = (fields) => {
      return fields.map(field => {
        if (field.id === id) {
          return { ...field, isNew: false };
        }
        if (field.children.length > 0) {
          return { ...field, children: updateFieldRecursively(field.children) };
        }
        return field;
      });
    };

    setFields(updateFieldRecursively(fields));
  };

  const handleCloseField = (id) => {
    const removeFieldRecursively = (fields) => {
      return fields.filter(field => {
        if (field.id === id) {
          return false;
        }
        if (field.children.length > 0) {
          field.children = removeFieldRecursively(field.children);
        }
        return true;
      });
    };

    setFields(removeFieldRecursively(fields));
  };

  const CustomTreeItem = styled(TreeItem)(({ theme }) => ({
    '& .MuiTreeItem-content': {
      '&.Mui-selected': {
        backgroundColor: '#eeeeee',
        // border: '2px solid #ff4081',
      },
    },
  }));

  const renderFields = (fields) => {
    return fields.map((field) => {
      const isRoot = field.parentId === null;
      console.log(field)
      return (
        <TreeItem
          key={field.id}
          itemId={String(field.id)}
          label={
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <TextField
                label={`TextField ${field.id}`}
                value={field.value}
                onChange={(e) => handleFieldChange(field.id, e.target.value)}
                variant="outlined"
                fullWidth
                inputRef={(ref) => (inputRefs.current[field.id] = ref)}
                onClick={() => {
                  setTimeout(() => {
                    if (inputRefs.current[field.id]) {
                      inputRefs.current[field.id].focus();
                    }
                  }, 0);
                }}
                onKeyDown={(e) => {
                  if (isRoot) e.preventDefault();
                  e.stopPropagation();
                }}
              />
              {field.isNew ? (
                <>
                  <CheckIcon
                    style={{ marginLeft: '8px', color: 'green' }}
                    onClick={() => handleSaveField(field.id)}
                  />
                  <CloseIcon
                    style={{ marginLeft: '8px', color: 'red' }}
                    onClick={() => handleCloseField(field.id)}
                  />
                </>
              ) : (
                <AddIcon
                  style={{ marginLeft: '8px', color: 'green' }}
                  onClick={(e) => {
                    handleAddField(field.id, e);
                  }}
                />
              )}
            </div>
          }
        >
          {field.children.length > 0 && renderFields(field.children)}
        </TreeItem>
      );
    });
  };

  const handleToggle = (event, nodeIds) => {
    const clickedElement = event.target.closest('svg');
    if (clickedElement && clickedElement.getAttribute('data-testid') === 'AddIcon') {
      return;
    }

    setExpandedItems(nodeIds);
  };

  return (
    <Box sx={{ width: '100%' }}>
      <TreeView
        expandedItems={expandedItems} onExpandedItemsChange={handleToggle}>
        {renderFields(fields)}
      </TreeView>
    </Box>
  );
}

export default DynamicTreeTextFields;
