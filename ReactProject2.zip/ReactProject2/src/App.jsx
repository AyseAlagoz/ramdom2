import './App.css'
import GlobalSnackbar from './global/GlobalSnackbar'
import { SnackbarProvider } from './globalState/snackbarContext'
import { router } from './route/routes'
import { RouterProvider } from 'react-router-dom';

function App() {

  return (
    <>
      <SnackbarProvider>
        <GlobalSnackbar />
        <RouterProvider router={router} />
      </SnackbarProvider>

    </>
  )
}

export default App
