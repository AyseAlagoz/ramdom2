﻿namespace BookWriter.WebApi.Models
{
    public class AddWriterModel
    {
        public string WriterName { get; set; }
    }
}
