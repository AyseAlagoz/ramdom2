﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace BookWriter.WebApi.Models
{
    public class BookModel
    {
        [Key]
        public int BookId { get; set; }
        public string BookName { get; set; }

        [ForeignKey("WriterModel")]
        public int WriterId { get; set; }

        //[JsonIgnore]
        //[IgnoreDataMember]
        public WriterModel WriterModel { get; set; }
    }
}
