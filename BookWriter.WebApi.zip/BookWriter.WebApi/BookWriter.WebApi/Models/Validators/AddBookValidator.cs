﻿using FluentValidation;

namespace BookWriter.WebApi.Models.Validators
{
    public class AddBookValidator : AbstractValidator<AddBookModel>
    {
        public AddBookValidator()
        {
            RuleFor(x => x.BookName).MinimumLength(5).WithMessage("Kitap Adı 5 karakterden az olamaz");

        }
    }
}
