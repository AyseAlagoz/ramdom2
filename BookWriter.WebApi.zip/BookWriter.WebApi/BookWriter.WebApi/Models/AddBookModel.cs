﻿namespace BookWriter.WebApi.Models
{
    public class AddBookModel
    {
        public string BookName { get; set; }
        public int WriterId { get; set; }

    }
}
