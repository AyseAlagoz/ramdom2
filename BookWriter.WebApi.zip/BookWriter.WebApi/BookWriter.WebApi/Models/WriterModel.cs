﻿using System.ComponentModel.DataAnnotations;

namespace BookWriter.WebApi.Models
{
    public class WriterModel
    {
        [Key]
        public int WriterId { get; set; }
        public string WriterName { get; set; }

    }
}
