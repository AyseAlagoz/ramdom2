﻿using BookWriter.WebApi.Db;
using BookWriter.WebApi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace BookWriter.WebApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BookController : Controller
    {
        private readonly BWDbContext dbContext;
        public BookController(BWDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddBook(AddBookModel addBookModel)
        {
            var book = new BookModel()
            {
                BookName = addBookModel.BookName,
                WriterId = addBookModel.WriterId,
            };
            await dbContext.BookModels.AddAsync(book);
            await dbContext.SaveChangesAsync();

            return Ok(book);
        }

        [HttpGet]
        [Authorize]
        public async Task<IActionResult> getBooks()
        {
            var result = from b in dbContext.BookModels
                         join w in dbContext.WriterModels
                         on
                         b.WriterId equals w.WriterId
                         into wModels
                         from bw in wModels.DefaultIfEmpty()
                         select new
                         {
                             bookId = b.BookId,
                             bookName = b.BookName,
                             writerName = bw.WriterName,
                             writerId = bw.WriterId
                         };

            return Ok(result);
        }

        [HttpGet]
        [Route("{WriterId}")]
        public async Task<IActionResult> getWriter([FromRoute] int WriterId)
        {
            var deneme = await dbContext.WriterModels.FindAsync(WriterId);
            if (deneme != null)
            {
                var writer = await dbContext.BookModels.Where(b => b.WriterId == WriterId).ToListAsync();
                if (writer != null)
                {
                    return Ok(writer);
                }
            }
            return NotFound();


        }

        [HttpPut]
        [Route("{BookId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> updateBook([FromRoute] int BookId, AddBookModel addBookModel)
        {
            var book = await dbContext.BookModels.FindAsync(BookId);
            if (book != null)
            {
                book.BookName = addBookModel.BookName;
                book.WriterId = addBookModel.WriterId;

                await dbContext.SaveChangesAsync();
                return Ok(book);
            }
            return NotFound();
        }

        [HttpDelete]
        [Route("{BookId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> deleteBook([FromRoute] int BookId)
        {
            var book = await dbContext.BookModels.FindAsync(BookId);
            if (book != null)
            {
                dbContext.Remove(book);
                await dbContext.SaveChangesAsync();
                return Ok(book);
            }
            return NotFound();
        }

    }
}
