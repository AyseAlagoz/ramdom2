﻿using DynamicFields.Domain.Db;
using DynamicFields.Domain.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DynamicFields.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class FormController : Controller
    {
        private readonly DFDbContext dbContext;

        public FormController(DFDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpPost("CreateForm")]
        public async Task<IActionResult> AddForm(Form addForm)
        {
            //var newForm = new Form()
            //{
            //    FormName = addForm.FormName,
            //    Contents = addForm.Contents,
            //};

            await dbContext.Forms.AddAsync(addForm);
            await dbContext.SaveChangesAsync();

            return Ok(addForm);
        }

        [HttpGet("GetForms")]
        public async Task<IActionResult> GetForms()
        {
            return Ok(await dbContext.Forms.ToListAsync());
        }


        [HttpGet("GetFormsName")]
        public async Task<IActionResult> GetFormsName()
        {
            //return Ok(await dbContext.Forms.ToListAsync());
            return Ok(await dbContext.Forms.Select(form => form.FormName).ToListAsync());
        }

        [HttpPost("InsertForm")]
        public async Task<IActionResult> InsertForm(List<FormContent> addFormContents)
        {
            foreach (var addFormContent in addFormContents)
            {
                var newFormRecord = new FormContent()
                {
                    FormPKey = addFormContent.FormPKey,
                    Name = addFormContent.Name,
                    Contents = addFormContent.Contents
                };

                await dbContext.FormContents.AddAsync(newFormRecord);
            }

            await dbContext.SaveChangesAsync();

            return Ok(addFormContents);
        }

        [HttpGet("GetAllFormContents")]
        public async Task<IActionResult> GetAllFormContents()
        {
            return Ok(await dbContext.FormContents.ToListAsync());
        }

        [HttpGet("GetContentOfSelectedForm")]
        //[Route("{FormPKey}")]
        public async Task<IActionResult> GetFormContent(string FormName)
        {
            //var formContent = await dbContext.FormContents.FindAsync(FormPKey);
            var formContent = await dbContext.Forms.Where(x => x.FormName == FormName).ToListAsync();
            var content = formContent.Select(t => t.Contents);
            if (content != null)
            {
                //var formRecords = await dbContext.FormContents.Where(x => x.FormPKey == FormPKey).ToListAsync();
                return Ok(content);
            }
            else
            {
                return NotFound();
            }

        }

    }
}
