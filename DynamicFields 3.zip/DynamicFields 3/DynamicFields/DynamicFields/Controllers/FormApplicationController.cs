﻿using DynamicFields.Domain.Db;
using DynamicFields.Domain.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DynamicFields.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class FormApplicationController : Controller
    {
        private readonly DFDbContext dbContext;

        public FormApplicationController(DFDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpPost("InsertFormApplication")]
        public async Task<IActionResult> InsertForm(FormApplication test)
        {
            await dbContext.FormApplications.AddAsync(test);
            await dbContext.SaveChangesAsync();

            return Ok(test);
        }
    }
}
