﻿using DynamicFields.Domain.Db;
using DynamicFields.Domain.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MongoDB.Driver;
using MongoDB.Driver.Core.Configuration;

namespace DynamicFields.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ParamController : Controller
    {
        private readonly DFDbContext dbContext;

        public ParamController(DFDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpPost("CreateNewParam")]
        public async Task<IActionResult> AddParam(Param param)
        {
            //var movie = dbContext.Params.First();
            //var newParam = new Param()
            //{
            //    Name = param.Name,
            //    Contents = param.Contents,
            // };
            var response = await dbContext.Params.AddAsync(param);
            await dbContext.SaveChangesAsync();

            return Ok(param);

            //var newParam = new Param()
            //{
            //    Name = param.Name,
            //    Contents = param.Contents,
            //    //};
            //    await dbContext.Params.AddAsync(newParam);
            //await dbContext.SaveChangesAsync();

            //return Ok(newParam);

        }

        [HttpGet("GetAllParams")]
        public async Task<IActionResult> GetParams()
        {
            return Ok(await dbContext.Params.ToListAsync());
        }
        [HttpPost("AddParamToExistedData")]
        public async Task<IActionResult> Add(Param param)
        {
            //var movie = dbContext.Params.First();
            //var newParam = new Param()
            //{
            //    Name = param.Name,
            //    Contents = param.Contents,
            // };
            var data = await dbContext.Params.FirstAsync(d =>d.Name == param.Name);
            data.Contents.AddRange(param.Contents);

            await dbContext.SaveChangesAsync();

            return Ok(param);

      

        }


    }
}
