﻿using DynamicFields.Domain.Model;
using Microsoft.EntityFrameworkCore;
using MongoDB.Driver;
using MongoDB.EntityFrameworkCore.Extensions;

namespace DynamicFields.Domain.Db
{
    public class DFDbContext : DbContext
    {
        public DbSet<Param> Params { get; init; }
        public DbSet<FormContent> FormContents { get; init; }
        public DbSet<Form> Forms { get; init; }
        public DbSet<FormApplication> FormApplications { get; init; }


        public static DFDbContext Create(IMongoDatabase database) =>
            new(new DbContextOptionsBuilder<DFDbContext>()
                .UseMongoDB(database.Client, database.DatabaseNamespace.DatabaseName)
                .Options);


        public DFDbContext(DbContextOptions options)
            : base(options)
        {
        }


        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    base.OnModelCreating(modelBuilder);
        //    modelBuilder.Entity<Param>().ToCollection("Params");
        //}
    }
}
