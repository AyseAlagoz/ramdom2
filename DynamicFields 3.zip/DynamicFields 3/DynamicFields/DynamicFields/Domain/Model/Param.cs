﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.ComponentModel.DataAnnotations;


namespace DynamicFields.Domain.Model
{
    public class Param
    {
        // [BsonRepresentation(BsonType.ObjectId)]
        //[BsonElement("ad soyad")]
        //[BsonElement("_id")]
        //[BsonId]
        //[Key]
        public ObjectId _id { get; set; }
        public string Name { get; set; }
        public List<string> Contents { get; set; }
    }
}
