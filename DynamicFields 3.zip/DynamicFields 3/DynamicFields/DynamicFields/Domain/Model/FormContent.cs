﻿using MongoDB.Bson;
using System.ComponentModel.DataAnnotations;

namespace DynamicFields.Domain.Model
{
    public class FormContent
    {

        public ObjectId _id { get; set; }
        public int FormPKey { get; set; }
        public string Name { get; set; }
        public string Contents { get; set; }
    }
}
