﻿namespace DynamicFields.Domain.Model
{
    public class ParamDto
    {
        public string Name { get; set; }
        public List<string> Contents { get; set; }
    }
}
