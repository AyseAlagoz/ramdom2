﻿namespace DynamicFields.Domain.Model.HelperModel
{
    public class ApplicationContent
    {
        public string label { get; set; }
        public string? stringValue { get; set; }
        public bool? boolValue { get; set; }
        public DateTime? dateValue { get; set; }
    }
}
