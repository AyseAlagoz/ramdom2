﻿namespace DynamicFields.Domain.Model.HelperModel
{
    public class FormContents
    {
        public string type { get; set; }
        public string? label { get; set; }
        public int size { get; set; }
        public bool? required { get; set; }
        public string? stringValue { get; set; }
        public DateTime? dateValue { get; set; }
        public bool? boolValue { get; set; }
        public List<string>? items { get; set; }
    }
}
