﻿using DynamicFields.Domain.Model.HelperModel;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.ComponentModel.DataAnnotations;

namespace DynamicFields.Domain.Model
{
    public class Form
    {
        [BsonId]
        public ObjectId _id { get; set; }
        public string FormName { get; set; }
        public List<FormContents> Contents { get; set; }
    }
}
