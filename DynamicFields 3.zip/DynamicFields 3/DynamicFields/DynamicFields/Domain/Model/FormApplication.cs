﻿using DynamicFields.Domain.Model.HelperModel;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace DynamicFields.Domain.Model
{
    public class FormApplication
    {
        [BsonId]
        public ObjectId _id { get; set; }
        public string FormName { get; set; }
        public List<ApplicationContent> ApplicationContents { get; set; }
    }
}
